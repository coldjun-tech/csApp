"""Read workbook metadata only; never execute cell text. Standard library only."""
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(sys.argv[1]) as archive:
    strings = []
    if 'xl/sharedStrings.xml' in archive.namelist():
        strings = [''.join(t.itertext()) for t in ET.fromstring(archive.read('xl/sharedStrings.xml')).findall('m:si', NS)]
    rows = []
    root = ET.fromstring(archive.read('xl/worksheets/sheet1.xml'))
    for row in root.findall('m:sheetData/m:row', NS):
        cells = {}
        for cell in row.findall('m:c', NS):
            v = cell.find('m:v', NS)
            value = v.text if v is not None else ''
            if cell.get('t') == 's':
                value = strings[int(value)]
            elif cell.get('t') == 'inlineStr':
                value = ''.join(cell.find('m:is', NS).itertext())
            cells[''.join(c for c in cell.get('r') if c.isalpha())] = value
        if cells.get('A') and cells['A'] != 'COLUMN_NAME':
            rows.append({'name': cells['A'], 'comment': cells.get('B', '')})

dest = Path(__file__).resolve().parents[1]
dest.joinpath('schema.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
columns = [r['name'] for r in rows]

def numbered(base, ordinal):
    name = f'{base}_{ordinal:03d}'
    if name not in columns:
        raise ValueError('Missing expected workbook column: ' + name)
    return name

groups = []
temp = [('Time', 'sTmp{}Tim', 17), ('Temperature', 'iTmp{}Get', 18),
        ('NgFlag', 'iTmp{}Flg', 19), ('Power', 'iTmp{}Wxx', 20)]
groups.append(('Measurements', [(name, [numbered(base.format(s), start + (s - 1) * 4) for s in range(1, 6)]) for name, base, start in temp]))
stops = [('Code', 'iStp{}Cod', 'iSt10Cod', 85), ('StartTime', 'sStp{}StT', 'sSt10StT', 86),
         ('EndTime', 'sStp{}EnT', 'sSt10EnT', 87), ('Duration', 'iStp{}Tim', 'iSt10Tim', 88),
         ('Status', 'iStp{}Sta', 'iSt10Sta', 89), ('Step', 'iStp{}Ste', 'iSt10Ste', 90)]
groups.append(('Stops', [(name, [numbered(base.format(s) if s < 10 else tenth, start + (s - 1) * 6) for s in range(1, 11)]) for name, base, tenth, start in stops]))
q = lambda s: json.dumps(s, ensure_ascii=False)
lines = ['// Generated from the supplied workbook. Physical column names are preserved.',
         'namespace FlatMasterDetail', '{', '    public static class LfHeatMapping', '    {',
         '        public static FlatMapping Create() => new FlatMapping(new string[]', '        {']
lines += ['            ' + q(c) + ',' for c in columns]
lines += ['        },']
for gi, (group, fields) in enumerate(groups):
    lines.append('        new DetailGroup(' + q(group) + ',')
    for fi, (field, names) in enumerate(fields):
        suffix = ',' if fi < len(fields) - 1 else ')' + (',' if gi < len(groups) - 1 else ');')
        lines.append('            new DetailField(' + ', '.join(map(q, [field] + names)) + ')' + suffix)
lines += ['    }', '}']
dest.joinpath('FlatMasterDetail/LfHeatMapping.cs').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(f'Imported {len(columns)} columns; Measurements=5 slots; Stops=10 slots.')
