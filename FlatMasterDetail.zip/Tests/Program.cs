using System.Data;
using FlatMasterDetail;

int passed = 0;
void Check(bool condition, string message)
{
    if (!condition) throw new Exception(message);
    passed++;
    Console.WriteLine("PASS " + message);
}
void Throws<T>(Action action, string message) where T : Exception
{
    try { action(); } catch (T) { Check(true, message); return; }
    throw new Exception("Expected " + typeof(T).Name + ": " + message);
}
async Task ThrowsAsync<T>(Func<Task> action, string message) where T : Exception
{
    try { await action(); } catch (T) { Check(true, message); return; }
    throw new Exception("Expected " + typeof(T).Name + ": " + message);
}

var mapping = LfHeatMapping.Create();
Check(mapping.Columns.Count == 179 && mapping.MasterColumns.Count == 99, "179 physical / 99 master columns");
var wide = DemoData.CreateSchema(mapping);
var row = wide.NewRow();
for (int i = 0; i < wide.Columns.Count; i++)
    row[i] = wide.Columns[i].DataType == typeof(string) ? (object)("value_'_" + i) : i * 7;
row["sTmp2Tim_021"] = DBNull.Value;
row["iTmp3Get_026"] = 0;
wide.Rows.Add(row);
var record = FlatRecord.FromRow(mapping, row);
var roundTrip = record.ToWideTable().Rows[0];
Check(mapping.Columns.All(c => Equals(row[c], roundTrip[c])), "all columns round-trip including NULL and zero");
Check(record.Details["Measurements"].Rows.Count == 5 && record.Details["Stops"].Rows.Count == 10, "fixed detail capacities");
record.Details["Stops"].Rows[9]["Code"] = 900;
Check((int)record.ToWideTable().Rows[0]["iSt10Cod_139"] == 900, "irregular slot-10 physical names");
record.Details["Measurements"].DefaultView.Sort = "Slot DESC";
record.Details["Measurements"].Rows[0]["Temperature"] = 1700;
Check((int)record.ToWideTable().Rows[0]["iTmp1Get_018"] == 1700, "sorting does not change slot mapping");
Check((int)row["iTmp1Get_018"] != 1700, "editing is detached from source");
var copy = record.CopyForEditing();
copy.Master.Rows[0]["sSteelxx_003"] = "COPY";
Check((string)record.Master.Rows[0]["sSteelxx_003"] != "COPY", "editing copy is independent");
Check(Equals(copy.OriginalValues()!.Rows[0]["sSteelxx_003"], row["sSteelxx_003"]), "copy preserves original concurrency snapshot");
record.ClearDetail("Measurements", 2);
Check(record.ToWideTable().Rows[0]["iTmp2Get_022"] == DBNull.Value &&
      (int)record.ToWideTable().Rows[0]["iTmp1Get_018"] == 1700, "clear detail leaves neighboring slots unchanged");
record.ClearDetail("Measurements", 2, new Dictionary<string, object?> { ["Time"] = "", ["Temperature"] = 0, ["NgFlag"] = 0, ["Power"] = 0 });
Check((int)record.ToWideTable().Rows[0]["iTmp2Get_022"] == 0, "configurable empty-slot values");
Throws<ArgumentOutOfRangeException>(() => record.ClearDetail("Stops", 11), "capacity overflow rejected");
var invalid = record.CopyForEditing();
invalid.Details["Stops"].Rows[0].Delete();
Throws<InvalidOperationException>(() => invalid.ToWideTable(), "physical detail row deletion rejected");
invalid = record.CopyForEditing();
invalid.Details["Stops"].Rows.Add(11, 1, "", "", 0, 0, 0);
Throws<InvalidOperationException>(() => invalid.ToWideTable(), "extra slot rejected");

var seed = DemoData.CreateSeed(mapping);
var store = new InMemoryFlatStore(mapping, seed, "sHeatNum_001", "iRtryCnt_002");
var key = new Dictionary<string, object?> { ["sHeatNum_001"] = "S79307", ["iRtryCnt_002"] = 0 };
var first = (await store.FindAsync(key))!;
var stale = (await store.FindAsync(key))!;
first.Details["Measurements"].Rows[4]["Temperature"] = 1600;
first = await store.UpdateAsync(first);
Check((int)(await store.FindAsync(key))!.Details["Measurements"].Rows[4]["Temperature"] == 1600, "update and reload");
await ThrowsAsync<DBConcurrencyException>(() => store.UpdateAsync(stale), "stale update rejected");
await ThrowsAsync<DBConcurrencyException>(() => store.DeleteAsync(stale), "stale delete rejected");
first.Master.Rows[0]["sHeatNum_001"] = "CHANGED";
await ThrowsAsync<InvalidOperationException>(() => store.UpdateAsync(first), "key edits rejected");
first.Master.Rows[0]["sHeatNum_001"] = "S79307";
var fresh = FlatRecord.Create(mapping, seed);
fresh.Master.Rows[0]["sHeatNum_001"] = "NEW'HEAT";
fresh.Master.Rows[0]["iRtryCnt_002"] = 1;
fresh.Details["Stops"].Rows[9]["Code"] = 99;
var saved = await store.InsertAsync(fresh);
Check(!saved.IsNew && (int)saved.Details["Stops"].Rows[9]["Code"] == 99, "insert with last detail slot");
await ThrowsAsync<ConstraintException>(() => store.InsertAsync(fresh), "duplicate composite key rejected");
var savedKey = new Dictionary<string, object?> { ["sHeatNum_001"] = "NEW'HEAT", ["iRtryCnt_002"] = 1 };
await store.DeleteAsync(saved);
Check(await store.FindAsync(savedKey) == null, "delete removes full wide row");
using var cancelled = new CancellationTokenSource();
cancelled.Cancel();
await ThrowsAsync<OperationCanceledException>(() => store.QueryAsync(null, cancelled.Token), "cancellation honored");

// Constructor validation is provider independent and must happen before opening connections.
Throws<ArgumentException>(() => new FlatRepository(mapping, () => throw new Exception("must not connect"),
    new StoreOptions { TableName = "Heat", KeyColumns = new[] { "unknown" } }), "unknown SQL key rejected");
Throws<ArgumentException>(() => new FlatRepository(mapping, () => throw new Exception("must not connect"),
    new StoreOptions { TableName = "Heat", KeyColumns = new[] { "sHeatNum_001" }, ConcurrencyColumns = Array.Empty<string>() }), "empty concurrency configuration rejected");
// Test the actual repository command path; this does not replace live DB integration testing.
var db = new RecordingConnection { Results = seed.Copy() };
var sql = new FlatRepository(mapping, () => db, new StoreOptions
{
    TableName = "dbo.Heat", KeyColumns = new[] { "sHeatNum_001", "iRtryCnt_002" }
});
var sqlRecord = FlatRecord.FromRow(mapping, seed.Rows[0]);
sqlRecord.Master.Rows[0]["sSteelxx_003"] = "x'; DELETE FROM Heat; --";
await sql.UpdateAsync(sqlRecord);
var updateSql = db.Statements[0];
Check(updateSql.Sql.StartsWith("UPDATE [dbo].[Heat] SET ") && !updateSql.Sql.Contains("DELETE FROM Heat"), "SQL values are parameterized");
Check(updateSql.Values.Values.Contains("x'; DELETE FROM Heat; --"), "input text remains a parameter value");
Check(updateSql.Sql.Contains("[iSt10Cod_139]") && updateSql.Sql.Contains(" IS NULL"), "all slots and NULL concurrency values are represented");
Check(db.Committed && db.TransactionDisposed, "successful write reloads and commits");
db.Committed = false; db.TransactionDisposed = false; db.Affected = 0;
await ThrowsAsync<DBConcurrencyException>(() => sql.UpdateAsync(sqlRecord), "SQL stale update rejected");
Check(!db.Committed && db.TransactionDisposed, "conflicting SQL transaction is disposed without commit");
db.Affected = 2;
await ThrowsAsync<DBConcurrencyException>(() => sql.DeleteAsync(sqlRecord), "SQL multiple affected rows rejected");
db.Affected = 1;
await sql.InsertAsync(fresh);
Check(db.Statements.Any(s => s.Sql.StartsWith("INSERT INTO [dbo].[Heat]")), "SQL insert is generated");
await sql.DeleteAsync(sqlRecord);
Check(db.Statements.Last().Sql.StartsWith("DELETE FROM [dbo].[Heat] WHERE "), "SQL delete has a concurrency predicate");
Console.WriteLine($"Completed: {passed} assertions.");
