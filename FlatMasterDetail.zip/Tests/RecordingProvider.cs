using System.Collections;
using System.Data;
using System.Data.Common;

// Records SQL without a database server. Row results and affected counts are controlled by tests.
internal sealed class RecordingConnection : DbConnection
{
    public List<(string Sql, Dictionary<string, object?> Values)> Statements { get; } = new();
    public DataTable Results { get; set; } = new();
    public int Affected { get; set; } = 1;
    public bool Committed { get; set; }
    public bool TransactionDisposed { get; set; }
    private ConnectionState state;
    [System.Diagnostics.CodeAnalysis.AllowNull] public override string ConnectionString { get; set; } = "";
    public override string Database => "Test";
    public override string DataSource => "Test";
    public override string ServerVersion => "1";
    public override ConnectionState State => state;
    public override void Open() => state = ConnectionState.Open;
    public override void Close() => state = ConnectionState.Closed;
    public override void ChangeDatabase(string databaseName) => throw new NotSupportedException();
    protected override DbCommand CreateDbCommand() => new RecordingCommand(this);
    protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel) => new RecordingTransaction(this, isolationLevel);
    private sealed class RecordingTransaction(RecordingConnection connection, IsolationLevel isolation) : DbTransaction
    {
        public override IsolationLevel IsolationLevel => isolation;
        protected override DbConnection DbConnection => connection;
        public override void Commit() => connection.Committed = true;
        public override void Rollback() => connection.Committed = false;
        protected override void Dispose(bool disposing) { connection.TransactionDisposed = true; base.Dispose(disposing); }
    }
    private sealed class RecordingCommand(RecordingConnection connection) : DbCommand
    {
        private readonly RecordingParameters parameters = new();
        [System.Diagnostics.CodeAnalysis.AllowNull] public override string CommandText { get; set; } = "";
        public override int CommandTimeout { get; set; }
        public override CommandType CommandType { get; set; }
        public override bool DesignTimeVisible { get; set; }
        public override UpdateRowSource UpdatedRowSource { get; set; }
        protected override DbConnection? DbConnection { get; set; } = connection;
        protected override DbTransaction? DbTransaction { get; set; }
        protected override DbParameterCollection DbParameterCollection => parameters;
        protected override DbParameter CreateDbParameter() => new RecordingParameter();
        public override void Cancel() { }
        public override void Prepare() { }
        private void Record() => connection.Statements.Add((CommandText, parameters.Cast<DbParameter>().ToDictionary(p => p.ParameterName, p => p.Value)));
        public override int ExecuteNonQuery() { Record(); return connection.Affected; }
        public override object? ExecuteScalar() => throw new NotSupportedException();
        protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior) { Record(); return connection.Results.CreateDataReader(); }
    }
    private sealed class RecordingParameter : DbParameter
    {
        public override DbType DbType { get; set; }
        public override ParameterDirection Direction { get; set; } = ParameterDirection.Input;
        public override bool IsNullable { get; set; }
        [System.Diagnostics.CodeAnalysis.AllowNull] public override string ParameterName { get; set; } = "";
        [System.Diagnostics.CodeAnalysis.AllowNull] public override string SourceColumn { get; set; } = "";
        public override DataRowVersion SourceVersion { get; set; } = DataRowVersion.Current;
        public override object? Value { get; set; }
        public override bool SourceColumnNullMapping { get; set; }
        public override int Size { get; set; }
        public override void ResetDbType() { }
    }
    private sealed class RecordingParameters : DbParameterCollection
    {
        private readonly List<DbParameter> items = new();
        public override int Count => items.Count;
        public override object SyncRoot => this;
        public override int Add(object value) { items.Add((DbParameter)value); return items.Count - 1; }
        public override void AddRange(Array values) { foreach (var value in values) Add(value!); }
        public override void Clear() => items.Clear();
        public override bool Contains(object value) => items.Contains((DbParameter)value);
        public override bool Contains(string value) => IndexOf(value) >= 0;
        public override void CopyTo(Array array, int index) => ((ICollection)items).CopyTo(array, index);
        public override IEnumerator GetEnumerator() => items.GetEnumerator();
        public override int IndexOf(object value) => items.IndexOf((DbParameter)value);
        public override int IndexOf(string parameterName) => items.FindIndex(p => p.ParameterName == parameterName);
        public override void Insert(int index, object value) => items.Insert(index, (DbParameter)value);
        public override void Remove(object value) => items.Remove((DbParameter)value);
        public override void RemoveAt(int index) => items.RemoveAt(index);
        public override void RemoveAt(string parameterName) => RemoveAt(IndexOf(parameterName));
        protected override DbParameter GetParameter(int index) => items[index];
        protected override DbParameter GetParameter(string parameterName) => items[IndexOf(parameterName)];
        protected override void SetParameter(int index, DbParameter value) => items[index] = value;
        protected override void SetParameter(string parameterName, DbParameter value)
        {
            int index = IndexOf(parameterName); if (index < 0) items.Add(value); else items[index] = value;
        }
    }
}
