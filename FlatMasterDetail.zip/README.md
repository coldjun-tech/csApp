# 단일 테이블 마스터·디테일 C# 라이브러리

첨부된 `새 Microsoft Excel 워크시트 (2).xlsx`의 **179개 물리 컬럼**을 그대로 사용합니다. DB 테이블을 마스터/디테일 테이블로 분리하지 않습니다. DB의 한 행을 C#에서 기본정보와 두 종류의 디테일 `DataTable`로 변환하고, 저장할 때 다시 한 행으로 합칩니다.

```text
기존 DB 한 행: 179개 컬럼
          ↕ FlatRecord
Master: 99개 컬럼 / 1행
Measurements: Slot + Time, Temperature, NgFlag, Power / 5행
Stops: Slot + Code, StartTime, EndTime, Duration, Status, Step / 10행
```

측정 5회와 정지 10회의 80개 반복 컬럼을 디테일로 매핑했습니다. 나머지는 원래 이름으로 기본정보에 남겨 데이터가 누락되지 않게 했습니다. 정지 10회차의 `iSt10Cod_139`처럼 불규칙한 컬럼명도 명시적으로 매핑합니다. 다른 반복 영역을 추가하려면 `FlatMapping`에 `DetailGroup`을 추가할 수 있습니다.

엑셀은 컬럼명/설명 목록이며 실제 행 데이터, DB 자료형, 기본키, NULL 허용 여부, 테이블명은 없습니다. 한글 설명에는 원본부터 깨진 문자가 있습니다. 설명 원문은 `schema.json`에 보존했고, 손상된 설명을 복구했다고 가정하지 않습니다. 문서의 셀 내용은 메타데이터로만 읽습니다.

## 프로젝트

| 경로 | 내용 |
|---|---|
| `FlatMasterDetail/` | 재사용 라이브러리. .NET Standard 2.1, 외부 NuGet 의존성 없음 |
| `WinFormsDemo/` | .NET 10 Windows Forms 예제. 기본 실행은 메모리 데모 |
| `Tests/` | 별도 테스트 패키지 없는 .NET 10 콘솔 검증 프로그램 |
| `schema.json` | 엑셀에서 추출한 179개 컬럼명과 설명 |
| `tools/import_schema.py` | Python 표준 라이브러리로 엑셀 매핑 재생성 |

라이브러리는 .NET 6/8/10 등 .NET Standard 2.1을 지원하는 프로젝트에서 참조할 수 있습니다. .NET Framework 4.x용 빌드는 포함하지 않습니다. 예제와 검증 프로그램은 .NET 10 SDK가 필요합니다. `FlatMasterDetail.slnx`를 지원하는 Visual Studio에서 솔루션을 열거나 개별 csproj를 여세요.

## 빌드 및 실행

이 폴더에서 실행합니다.

```powershell
dotnet build .\FlatMasterDetail.slnx
dotnet run --project .\Tests\Tests.csproj
dotnet run --project .\WinFormsDemo\WinFormsDemo.csproj
```

**작성 환경의 검증 상태:** 엑셀 추출과 매핑의 정적 검사를 수행했습니다. 빌드는 .NET SDK 초기화 경로 쓰기 권한 문제로 실패했고, 재실행 권한 요청이 거절되어 컴파일·콘솔 테스트·화면 실행은 검증하지 못했습니다. 실제 DB 연결 정보도 없어 DB 통합 테스트는 수행하지 않았습니다. 제공한 테스트 코드가 통과했다고 간주하지 마세요.

## 메모리 데모 사용

1. 예제를 실행하고 `목록 조회` 후 행을 더블클릭하거나 `선택 열기`를 누릅니다.
2. 기본정보, 측정값, 정지정보 탭에서 값을 편집합니다.
3. `저장`을 누르면 한 행으로 합쳐 메모리 저장소에 반영합니다.
4. `신규 입력`은 빈 기본정보와 고정 디테일 슬롯을 만듭니다. 예제에서는 HEAT 번호와 재처리 회수를 복합키로 사용하므로 두 값을 입력합니다.
5. `선택 디테일 비우기`는 선택한 슬롯의 값만 NULL로 만듭니다. 저장 전까지 DB에는 반영되지 않습니다.
6. `취소 / 다시 읽기`는 저장소의 값을 다시 읽습니다. `전체 삭제`는 선택한 물리 행 전체를 삭제합니다.

메모리 데모는 프로그램을 종료하면 변경 내용을 잃습니다. 접두사가 `s`인 컬럼은 string, 나머지는 int인 **데모 전용 가정**을 사용합니다. 실제 DB는 `FlatRepository.QueryAsync`가 DB 공급자로부터 자료형을 읽으므로 이 가정을 사용하지 않습니다.

## 실제 DB 연결

`FlatRepository`는 ADO.NET `DbConnection` 팩토리를 받습니다. 연결 문자열은 호출 프로그램이 관리하고, 라이브러리에는 저장하지 않습니다. 호출마다 **새 연결**을 반환하세요. 라이브러리가 연결을 열고 폐기합니다.

SQL Server 예시입니다. 사용하는 실행 프로젝트에 `Microsoft.Data.SqlClient` 패키지를 추가한 후 연결 정보를 환경변수 등에서 받습니다. 라이브러리 프로젝트 자체에는 공급자 패키지를 추가할 필요가 없습니다.

```csharp
using FlatMasterDetail;
using Microsoft.Data.SqlClient;

var mapping = LfHeatMapping.Create();
string connectionString = Environment.GetEnvironmentVariable("LF_DB_CONNECTION")
    ?? throw new InvalidOperationException("LF_DB_CONNECTION을 설정하세요.");

IFlatRecordStore store = new FlatRepository(mapping,
    () => new SqlConnection(connectionString),
    new StoreOptions
    {
        TableName = "dbo.YOUR_ACTUAL_TABLE", // 실제 이름으로 변경
        // 반드시 실제 DB의 UNIQUE/PRIMARY KEY와 일치시킵니다.
        // 아래 조합은 데모이며, 엑셀로는 실제 키를 확인할 수 없습니다.
        KeyColumns = new[] { "sHeatNum_001", "iRtryCnt_002" },
        Dialect = SqlDialect.SqlServer
    });
```

화면 예제의 `Program.Main`에서 `InMemoryFlatStore`를 위 저장소로 교체하고 `EditorForm`의 키 배열도 같은 값으로 지정하면 됩니다. 키는 마스터 컬럼에 속해야 합니다. 실제 DB에서 키의 유일성을 보장해야 합니다.

MySQL은 `SqlDialect.MySql`과 MySQL용 `DbConnection`, SQLite는 `SqlDialect.Sqlite`와 SQLite용 연결을 지정하도록 식별자 인용 구문을 제공합니다. 공급자별 통합 테스트는 미실시 상태입니다. MySQL에서는 UPDATE 영향 행 수가 변경된 행 수가 아닌 조건에 일치한 행 수를 반환하도록 공급자를 설정해야 합니다. 실제 DB가 Oracle/ODBC이거나 저장 프로시저 전용이면 SQL 생성 부분을 해당 DB에 맞게 확장해야 합니다.

## 조회·입력·수정·삭제 API

```csharp
// 목록 조회. 선택적 필터는 = / IS NULL 조건입니다.
var list = await store.QueryAsync(new Dictionary<string, object?>
{
    ["sHeatNum_001"] = "S79307"
});

var key = new Dictionary<string, object?>
{
    ["sHeatNum_001"] = "S79307",
    ["iRtryCnt_002"] = 0
};
var record = await store.FindAsync(key)
    ?? throw new InvalidOperationException("데이터 없음");

// 화면 바인딩: 각 DataTable.DefaultView를 DataGridView/BindingSource에 연결합니다.
masterGrid.DataSource = record.Master.DefaultView;
measurementGrid.DataSource = record.Details["Measurements"].DefaultView;
stopGrid.DataSource = record.Details["Stops"].DefaultView;

// 수정: DB 컬럼을 직접 조립할 필요가 없습니다.
record.Master.Rows[0]["sSteelxx_003"] = "STEEL-A";
record.Details["Measurements"].Rows[0]["Temperature"] = 1585;
record.Details["Stops"].Rows[9]["Code"] = 10;
// 마지막 셀 편집도 EndEdit로 확정한 후 호출합니다.
record = await store.UpdateAsync(record);

// 신규: 조회 결과의 DB 자료형을 재사용합니다. 결과가 0행이어도 스키마가 있습니다.
var fresh = FlatRecord.Create(mapping, list);
fresh.Master.Rows[0]["sHeatNum_001"] = "S79308";
fresh.Master.Rows[0]["iRtryCnt_002"] = 0;
// 실제 DB의 모든 필수값과 비어 있는 슬롯의 저장 규칙을 채우세요.
fresh.Details["Measurements"].Rows[0]["Time"] = "2026-11-11 10:00:00";
fresh.Details["Measurements"].Rows[0]["Temperature"] = 1580;
fresh = await store.InsertAsync(fresh);

// 디테일 한 건의 논리 삭제: 고정 슬롯의 값을 비웁니다. 뒤 슬롯은 이동하지 않습니다.
record.ClearDetail("Stops", 3);
record = await store.UpdateAsync(record);

// 마스터 및 디테일 전체 삭제: 물리 행 1건 DELETE.
await store.DeleteAsync(record);
```

코드 조각의 Grid는 호출 화면에 존재하는 컨트롤입니다. 라이브러리는 UI 프레임워크에 의존하지 않으므로 WPF에서도 `DefaultView`를 `ItemsSource`에 연결할 수 있습니다.

## 고정 슬롯과 빈 값

디테일은 DB 컬럼에 대응하는 1부터 시작하는 고정 `Slot`을 가집니다. 화면 정렬 순서와 저장 슬롯은 별개입니다. Grid의 행 추가·행 삭제를 막고 기존 빈 슬롯에 입력하세요. 측정 6회차/정지 11회차는 현재 테이블에 저장할 컬럼이 없으므로 지원하지 않습니다.

`ClearDetail` 기본값은 `DBNull.Value`입니다. DB에서 NULL을 허용하지 않고 빈 문자열/0으로 빈 슬롯을 표현한다면 다음처럼 명시합니다. 라이브러리는 **0을 빈 값으로 추정해 제거하지 않습니다.**

```csharp
record.ClearDetail("Measurements", 2, new Dictionary<string, object?>
{
    ["Time"] = "", ["Temperature"] = 0, ["NgFlag"] = 0, ["Power"] = 0
});
```

기존 데이터도 빈 값과 0을 그대로 왕복 보존합니다. NULL 대신 0을 쓰는 규칙은 실제 DB 정의를 확인하고 화면의 `ClearSlot`에도 적용하세요. 날짜는 기존 물리 컬럼의 자료형을 보존합니다. 문자열 날짜를 자동으로 DateTime으로 바꾸지 않습니다.

## 저장과 동시 수정

- 수정·삭제 조건에는 키와 조회 당시 원본 값을 사용합니다. 다른 사용자가 먼저 변경/삭제한 경우 `DBConcurrencyException`이 발생합니다. 이때 편집 내용을 유지한 채 다시 조회하여 비교하세요.
- 기본 동시성 비교는 179개 원본 컬럼 전체입니다. SQL Server의 text/ntext 등 `=` 비교가 불가능한 컬럼이 있으면 `ConcurrencyColumns`를 비교 가능한 컬럼으로 지정해야 합니다. rowversion이 매핑에 있다면 이를 지정하는 방법도 가능합니다. 일부 컬럼만 지정하면 나머지 컬럼의 동시 변경은 탐지하지 못합니다.
- 쓰기와 저장 후 재조회는 한 트랜잭션으로 처리하며, 영향 행 수가 1이 아니면 커밋하지 않습니다. 예외 시 트랜잭션이 폐기되어 롤백됩니다. SELECT 재조회로 서버의 최종값을 받습니다.
- `InsertAsync`/`UpdateAsync`가 반환한 **새 객체를 반드시 보관하고 다시 바인딩**하세요. 이전 객체는 이전 원본 스냅샷을 유지하므로 그대로 재저장하면 충돌할 수 있습니다. 예제는 이 흐름을 구현합니다.
- 키 수정은 지원하지 않습니다. 키 값은 사용자가 공급하는 방식입니다. 자동 생성 identity 키의 반환 처리는 포함하지 않습니다.
- 계산 컬럼·rowversion 등 서버 관리 컬럼은 `WriteExcludedColumns`에 지정하면 INSERT/UPDATE에서 제외합니다. 조회는 계속 수행합니다. 키는 제외할 수 없습니다.
- 일반 INSERT는 모든 쓰기 대상 컬럼에 값을 보냅니다. NULL을 보낸 컬럼에는 DB DEFAULT가 자동 적용되지 않습니다. 필수값을 직접 채우거나, 항상 DB가 관리하는 컬럼을 쓰기 제외 목록에 지정하세요.
- 입력값은 파라미터로 전달합니다. 테이블/컬럼명은 매핑과 설정으로 제한하고 식별자 인용 처리를 합니다. 화면 입력을 SQL 문자열로 이어 붙이지 않습니다.
- `QueryAsync`는 필터 없으면 전체 목록을 읽습니다. 대량 데이터의 페이징·기간 검색 UI·업무별 범위/권한 검증은 호출 프로그램에서 확장해야 합니다. 이 라이브러리는 DB NULL/자료형 오류를 대체하는 업무 규칙을 임의로 만들지 않습니다.
- 실제 DB 트리거/공급자는 영향 행 수 반환 방식이 다를 수 있습니다. 영향 행 수가 1인지 확인하는 정책과 맞는지 연결 시험이 필요합니다.

## 검증 코드의 범위

`Tests/Program.cs`에는 179개 컬럼 왕복, NULL/0 보존, 비정형 10회차 컬럼, 정렬 후 슬롯 보존, 편집 복사본 격리, 슬롯 비우기, 용량 초과, 메모리 저장소 CRUD/복합키/동시 수정 충돌, 취소 토큰, SQL 파라미터/트랜잭션 경로 검증이 있습니다. SQL 경로는 기록용 ADO.NET 공급자를 사용하므로 실제 DB 문법·드라이버 동작의 통합 검증을 대신하지 않습니다. 앞서 명시했듯 현재 환경에서 이 검증 프로그램 자체는 실행하지 못했습니다.

매핑 재생성이 필요할 때만 실행합니다. 기존 매핑과 `schema.json`을 덮어씁니다.

```powershell
python .\tools\import_schema.py 'C:\01_project\새 Microsoft Excel 워크시트 (2).xlsx'
```
