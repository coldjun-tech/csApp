using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace FlatMasterDetail
{
    // One logical detail field maps to a different physical column in each slot.
    public sealed class DetailField
    {
        public string Name { get; }
        public IReadOnlyList<string> Columns { get; }
        public DetailField(string name, params string[] columns)
        {
            Name = name;
            Columns = Array.AsReadOnly((string[])columns.Clone());
        }
    }

    public sealed class DetailGroup
    {
        public string Name { get; }
        public IReadOnlyList<DetailField> Fields { get; }
        public int Capacity => Fields[0].Columns.Count;
        public DetailGroup(string name, params DetailField[] fields)
        {
            if (string.IsNullOrWhiteSpace(name) || fields.Length == 0 ||
                fields[0].Columns.Count == 0 || fields.Any(f => f.Columns.Count != fields[0].Columns.Count) ||
                fields.Select(f => f.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count() != fields.Length ||
                fields.Any(f => string.Equals(f.Name, "Slot", StringComparison.OrdinalIgnoreCase)))
                throw new ArgumentException("Invalid detail group or inconsistent slot counts.");
            Name = name;
            Fields = Array.AsReadOnly((DetailField[])fields.Clone());
        }
    }

    public sealed class FlatMapping
    {
        public IReadOnlyList<string> Columns { get; }
        public IReadOnlyList<DetailGroup> Groups { get; }
        public IReadOnlyList<string> MasterColumns { get; }
        public FlatMapping(IEnumerable<string> columns, params DetailGroup[] groups)
        {
            var all = columns.ToArray();
            var detail = groups.SelectMany(g => g.Fields).SelectMany(f => f.Columns).ToArray();
            if (all.Length == 0 || all.Any(string.IsNullOrWhiteSpace) ||
                all.Distinct(StringComparer.OrdinalIgnoreCase).Count() != all.Length ||
                detail.Distinct(StringComparer.OrdinalIgnoreCase).Count() != detail.Length ||
                detail.Except(all, StringComparer.Ordinal).Any() ||
                groups.Select(g => g.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count() != groups.Length)
                throw new ArgumentException("Duplicate or unknown mapped columns/groups.");
            Columns = Array.AsReadOnly(all);
            Groups = Array.AsReadOnly((DetailGroup[])groups.Clone());
            MasterColumns = Array.AsReadOnly(all.Except(detail).ToArray());
        }

        public void ValidateSchema(DataTable table)
        {
            foreach (var name in Columns)
                if (!table.Columns.Contains(name)) throw new ArgumentException("Missing DB column: " + name);
            foreach (var group in Groups)
                foreach (var field in group.Fields)
                    if (field.Columns.Select(c => table.Columns[c]!.DataType).Distinct().Count() != 1)
                        throw new ArgumentException("Slot types differ: " + group.Name + "." + field.Name);
        }
    }
}
