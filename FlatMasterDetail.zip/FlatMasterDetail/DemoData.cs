using System.Data;

namespace FlatMasterDetail
{
    public static class DemoData
    {
        /// <summary>Illustrative types inferred from prefixes; production MUST use actual DB schema.</summary>
        public static DataTable CreateSchema(FlatMapping mapping)
        {
            var table = new DataTable("DemoHeat");
            foreach (var column in mapping.Columns)
                table.Columns.Add(column, column.StartsWith("s") ? typeof(string) : typeof(int));
            return table;
        }

        public static DataTable CreateSeed(FlatMapping mapping)
        {
            var table = CreateSchema(mapping);
            var row = table.NewRow();
            row["sHeatNum_001"] = "S79307";
            row["iRtryCnt_002"] = 0;
            row["sSteelxx_003"] = "DEMO";
            row["sTmp1Tim_017"] = "2026-11-11 10:00:00";
            row["iTmp1Get_018"] = 1580;
            row["iTmp1Flg_019"] = 0;
            row["iTmp1Wxx_020"] = 1200;
            row["iSt10Cod_139"] = 10;
            table.Rows.Add(row);
            table.AcceptChanges();
            return table;
        }
    }
}
