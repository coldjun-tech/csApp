using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace FlatMasterDetail
{
    /// <summary>Thread-safe demonstration store. Not persistent; no SQL provider is needed.</summary>
    public sealed class InMemoryFlatStore : IFlatRecordStore
    {
        private readonly object gate = new object();
        private readonly FlatMapping mapping;
        private readonly DataTable data;
        private readonly string[] keys;
        public InMemoryFlatStore(FlatMapping mapping, DataTable seed, params string[] keys)
        {
            mapping.ValidateSchema(seed);
            if (keys.Length == 0 || keys.Except(mapping.MasterColumns).Any() || keys.Distinct().Count() != keys.Length)
                throw new ArgumentException("Supply unique master key columns.");
            this.mapping = mapping;
            this.keys = (string[])keys.Clone();
            data = seed.Copy();
            data.PrimaryKey = keys.Select(k => data.Columns[k]!).ToArray();
            data.AcceptChanges();
        }

        public Task<DataTable> QueryAsync(IReadOnlyDictionary<string, object?>? filters = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (filters != null && filters.Keys.Except(mapping.Columns).Any()) throw new ArgumentException("Unknown filter.");
            lock (gate)
            {
                var result = data.Clone();
                foreach (DataRow row in data.Rows)
                    if (filters == null || filters.All(f => FlatRepository.ValueEquals(row[f.Key], f.Value ?? DBNull.Value))) result.ImportRow(row);
                return Task.FromResult(result);
            }
        }

        public async Task<FlatRecord?> FindAsync(IReadOnlyDictionary<string, object?> key, CancellationToken cancellationToken = default)
        {
            if (key.Count != keys.Length || keys.Except(key.Keys).Any() || key.Values.Any(v => v == null || v == DBNull.Value))
                throw new ArgumentException("Supply all non-null keys.");
            var result = await QueryAsync(key, cancellationToken).ConfigureAwait(false);
            return result.Rows.Count == 0 ? null : FlatRecord.FromRow(mapping, result.Rows[0]);
        }

        public Task<FlatRecord> InsertAsync(FlatRecord record, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            lock (gate)
            {
                CheckMapping(record);
                if (!record.IsNew) throw new InvalidOperationException("Record is already stored.");
                var row = record.ToWideTable().Rows[0];
                var key = Key(row);
                if (data.Rows.Find(key) != null) throw new ConstraintException("Duplicate key.");
                data.ImportRow(row);
                data.AcceptChanges();
                return Task.FromResult(FlatRecord.FromRow(mapping, data.Rows.Find(key)!));
            }
        }

        public Task<FlatRecord> UpdateAsync(FlatRecord record, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            lock (gate)
            {
                CheckMapping(record);
                var original = record.OriginalValues() ?? throw new InvalidOperationException("Record has not been inserted.");
                var current = record.ToWideTable().Rows[0];
                if (keys.Any(k => !FlatRepository.ValueEquals(current[k], original.Rows[0][k]))) throw new InvalidOperationException("Cannot change keys.");
                var stored = Unchanged(original.Rows[0]);
                foreach (var c in mapping.Columns) stored[c] = current[c];
                data.AcceptChanges();
                return Task.FromResult(FlatRecord.FromRow(mapping, stored));
            }
        }

        public Task DeleteAsync(FlatRecord record, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            lock (gate)
            {
                CheckMapping(record);
                var original = record.OriginalValues() ?? throw new InvalidOperationException("Record has not been inserted.");
                data.Rows.Remove(Unchanged(original.Rows[0]));
                return Task.CompletedTask;
            }
        }

        private void CheckMapping(FlatRecord record)
        {
            if (!ReferenceEquals(record.Mapping, mapping)) throw new ArgumentException("Different mapping instance.");
        }
        private object[] Key(DataRow row)
        {
            var values = keys.Select(k => row[k]).ToArray();
            if (values.Any(v => v == DBNull.Value)) throw new ArgumentException("Keys cannot be NULL.");
            return values;
        }
        private DataRow Unchanged(DataRow original)
        {
            var stored = data.Rows.Find(Key(original));
            if (stored == null || mapping.Columns.Any(c => !FlatRepository.ValueEquals(stored[c], original[c])))
                throw new DBConcurrencyException("Record was changed/deleted. Reload it.");
            return stored;
        }
    }
}
