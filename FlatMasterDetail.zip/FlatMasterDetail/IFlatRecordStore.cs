using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace FlatMasterDetail
{
    public interface IFlatRecordStore
    {
        Task<DataTable> QueryAsync(IReadOnlyDictionary<string, object?>? filters = null, CancellationToken cancellationToken = default);
        Task<FlatRecord?> FindAsync(IReadOnlyDictionary<string, object?> key, CancellationToken cancellationToken = default);
        Task<FlatRecord> InsertAsync(FlatRecord record, CancellationToken cancellationToken = default);
        Task<FlatRecord> UpdateAsync(FlatRecord record, CancellationToken cancellationToken = default);
        Task DeleteAsync(FlatRecord record, CancellationToken cancellationToken = default);
    }
}
