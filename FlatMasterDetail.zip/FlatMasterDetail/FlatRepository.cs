using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace FlatMasterDetail
{
    public enum SqlDialect { SqlServer, MySql, Sqlite }

    public sealed class StoreOptions
    {
        public string TableName { get; set; } = "";
        public string[] KeyColumns { get; set; } = Array.Empty<string>();
        public SqlDialect Dialect { get; set; } = SqlDialect.SqlServer;
        /// <summary>Computed, identity, rowversion or other server-managed columns.</summary>
        public string[] WriteExcludedColumns { get; set; } = Array.Empty<string>();
        /// <summary>NULL means compare all mapped original columns. Configure for non-comparable DB types.</summary>
        public string[]? ConcurrencyColumns { get; set; }
        public int CommandTimeoutSeconds { get; set; } = 30;
    }

    /// <summary>Parameterized SQL against one existing wide table. A factory must return a new connection per call.</summary>
    public sealed class FlatRepository : IFlatRecordStore
    {
        private readonly Func<DbConnection> connectionFactory;
        private readonly FlatMapping mapping;
        private readonly string table;
        private readonly string[] keys, writable, concurrency;
        private readonly SqlDialect dialect;
        private readonly int timeout;
        public FlatRepository(FlatMapping mapping, Func<DbConnection> connectionFactory, StoreOptions options)
        {
            this.mapping = mapping;
            this.connectionFactory = connectionFactory;
            dialect = options.Dialect;
            timeout = options.CommandTimeoutSeconds;
            keys = (string[])options.KeyColumns.Clone();
            if (string.IsNullOrWhiteSpace(options.TableName) || keys.Length == 0 ||
                keys.Distinct().Count() != keys.Length || keys.Except(mapping.MasterColumns).Any())
                throw new ArgumentException("Specify a table and its actual unique master key columns.");
            if (options.WriteExcludedColumns.Except(mapping.Columns).Any() || keys.Intersect(options.WriteExcludedColumns).Any())
                throw new ArgumentException("Unknown excluded columns or generated keys. Supply explicit non-generated keys.");
            concurrency = (options.ConcurrencyColumns ?? mapping.Columns.ToArray()).Distinct().ToArray();
            if (concurrency.Length == 0 || concurrency.Except(mapping.Columns).Any())
                throw new ArgumentException("Specify at least one valid concurrency column.");
            writable = mapping.Columns.Except(options.WriteExcludedColumns).ToArray();
            table = string.Join(".", options.TableName.Split('.').Select(Quote));
        }

        private string Quote(string identifier)
        {
            if (string.IsNullOrWhiteSpace(identifier)) throw new ArgumentException("Empty SQL identifier.");
            if (dialect == SqlDialect.SqlServer) return "[" + identifier.Replace("]", "]]") + "]";
            if (dialect == SqlDialect.MySql) return "`" + identifier.Replace("`", "``") + "`";
            return "\"" + identifier.Replace("\"", "\"\"") + "\"";
        }

        private DbCommand Command(DbConnection connection, DbTransaction? transaction)
        {
            var command = connection.CreateCommand();
            command.Transaction = transaction;
            command.CommandTimeout = timeout;
            return command;
        }

        private string Parameter(DbCommand command, object? value)
        {
            var p = command.CreateParameter();
            p.ParameterName = "@p" + command.Parameters.Count;
            p.Value = value ?? DBNull.Value;
            command.Parameters.Add(p);
            return p.ParameterName;
        }

        private string Predicate(DbCommand command, IEnumerable<KeyValuePair<string, object?>> values)
        {
            return string.Join(" AND ", values.Select(v => v.Value == null || v.Value == DBNull.Value
                ? Quote(v.Key) + " IS NULL"
                : Quote(v.Key) + " = " + Parameter(command, v.Value)));
        }

        /// <summary>Returns a typed wide table, including schema even when no rows match. Filters use equality/IS NULL.</summary>
        public async Task<DataTable> QueryAsync(IReadOnlyDictionary<string, object?>? filters = null, CancellationToken cancellationToken = default)
        {
            if (filters != null && filters.Keys.Except(mapping.Columns).Any()) throw new ArgumentException("Unknown filter column.");
            using var connection = connectionFactory();
            await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
            return await ReadAsync(connection, null, filters, cancellationToken).ConfigureAwait(false);
        }

        private async Task<DataTable> ReadAsync(DbConnection connection, DbTransaction? transaction,
            IReadOnlyDictionary<string, object?>? filters, CancellationToken token)
        {
            using var command = Command(connection, transaction);
            command.CommandText = "SELECT " + string.Join(", ", mapping.Columns.Select(Quote)) + " FROM " + table;
            if (filters != null && filters.Count > 0) command.CommandText += " WHERE " + Predicate(command, filters);
            using var reader = await command.ExecuteReaderAsync(token).ConfigureAwait(false);
            var result = new DataTable();
            for (int i = 0; i < reader.FieldCount; i++) result.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
            while (await reader.ReadAsync(token).ConfigureAwait(false))
            {
                var values = new object[reader.FieldCount];
                reader.GetValues(values);
                result.Rows.Add(values);
            }
            result.AcceptChanges();
            mapping.ValidateSchema(result);
            return result;
        }

        public async Task<FlatRecord?> FindAsync(IReadOnlyDictionary<string, object?> key, CancellationToken cancellationToken = default)
        {
            ValidateKey(key);
            var rows = await QueryAsync(key, cancellationToken).ConfigureAwait(false);
            if (rows.Rows.Count > 1) throw new InvalidOperationException("Configured keys are not unique.");
            return rows.Rows.Count == 0 ? null : FlatRecord.FromRow(mapping, rows.Rows[0]);
        }

        public Task<FlatRecord> InsertAsync(FlatRecord record, CancellationToken cancellationToken = default)
        {
            if (!record.IsNew) throw new InvalidOperationException("Use Create for insertion.");
            return SaveAsync(record, true, cancellationToken);
        }

        public Task<FlatRecord> UpdateAsync(FlatRecord record, CancellationToken cancellationToken = default)
        {
            if (record.IsNew) throw new InvalidOperationException("Insert the new record first.");
            return SaveAsync(record, false, cancellationToken);
        }

        private void CheckMapping(FlatRecord record)
        {
            if (!ReferenceEquals(record.Mapping, mapping)) throw new ArgumentException("Record belongs to a different mapping instance.");
        }

        private Dictionary<string, object?> ReadKey(DataRow row) => keys.ToDictionary(k => k, k => (object?)row[k]);
        private void ValidateKey(IReadOnlyDictionary<string, object?> key)
        {
            if (key.Count != keys.Length || keys.Except(key.Keys).Any() || key.Values.Any(v => v == null || v == DBNull.Value))
                throw new ArgumentException("All configured key values must be supplied and non-null.");
        }

        private string OriginalPredicate(DbCommand command, DataRow original) => Predicate(command,
            keys.Concat(concurrency).Distinct().Select(c => new KeyValuePair<string, object?>(c, original[c])));

        private async Task<FlatRecord> SaveAsync(FlatRecord record, bool insert, CancellationToken token)
        {
            CheckMapping(record);
            var row = record.ToWideTable().Rows[0];
            var key = ReadKey(row);
            ValidateKey(key);
            var original = record.OriginalValues();
            if (!insert && keys.Any(k => !ValueEquals(original!.Rows[0][k], row[k])))
                throw new InvalidOperationException("Changing a primary key is not supported.");
            using var connection = connectionFactory();
            await connection.OpenAsync(token).ConfigureAwait(false);
            using var transaction = connection.BeginTransaction(IsolationLevel.Serializable);
            using var command = Command(connection, transaction);
            if (insert)
                command.CommandText = "INSERT INTO " + table + " (" + string.Join(", ", writable.Select(Quote)) +
                    ") VALUES (" + string.Join(", ", writable.Select(c => Parameter(command, row[c]))) + ")";
            else
            {
                var setColumns = writable.Except(keys).ToArray();
                if (setColumns.Length == 0) throw new InvalidOperationException("No writable non-key columns.");
                command.CommandText = "UPDATE " + table + " SET " +
                    string.Join(", ", setColumns.Select(c => Quote(c) + " = " + Parameter(command, row[c]))) +
                    " WHERE " + OriginalPredicate(command, original!.Rows[0]);
            }
            var affected = await command.ExecuteNonQueryAsync(token).ConfigureAwait(false);
            if (affected != 1) throw new DBConcurrencyException("Expected one affected row; found " + affected + ". Reload the record.");
            var saved = await ReadAsync(connection, transaction, key, token).ConfigureAwait(false);
            if (saved.Rows.Count != 1) throw new DBConcurrencyException("Saved row could not be uniquely reloaded.");
            var result = FlatRecord.FromRow(mapping, saved.Rows[0]);
            transaction.Commit();
            return result;
        }

        /// <summary>Deletes the entire physical row, including every detail slot.</summary>
        public async Task DeleteAsync(FlatRecord record, CancellationToken cancellationToken = default)
        {
            CheckMapping(record);
            var original = record.OriginalValues() ?? throw new InvalidOperationException("New records are not stored.");
            ValidateKey(ReadKey(original.Rows[0]));
            using var connection = connectionFactory();
            await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
            using var transaction = connection.BeginTransaction(IsolationLevel.Serializable);
            using var command = Command(connection, transaction);
            command.CommandText = "DELETE FROM " + table + " WHERE " + OriginalPredicate(command, original.Rows[0]);
            if (await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false) != 1)
                throw new DBConcurrencyException("Record was changed/deleted or keys are not unique. Reload it.");
            transaction.Commit();
        }

        internal static bool ValueEquals(object a, object b) => a is byte[] x && b is byte[] y ? x.SequenceEqual(y) : Equals(a, b);
    }
}
