using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace FlatMasterDetail
{
    /// <summary>Editable detached master/detail tables for a single physical DB row.</summary>
    public sealed class FlatRecord
    {
        public FlatMapping Mapping { get; }
        public DataTable Master { get; }
        public IReadOnlyDictionary<string, DataTable> Details { get; }
        private readonly DataTable schema;
        private readonly DataTable? original;
        public bool IsNew => original == null;

        private FlatRecord(FlatMapping mapping, DataTable source, DataRow? row)
        {
            mapping.ValidateSchema(source);
            Mapping = mapping;
            // Intentionally keep types, not DB constraints: editing may be incomplete until save.
            schema = TypedTable(source, mapping.Columns, "Wide");
            if (row != null)
            {
                original = schema.Clone();
                original.Rows.Add(mapping.Columns.Select(c => row[c]).ToArray());
                original.AcceptChanges();
            }
            Master = TypedTable(source, mapping.MasterColumns, "Master");
            Master.Rows.Add(mapping.MasterColumns.Select(c => row == null ? DBNull.Value : row[c]).ToArray());
            var tables = new Dictionary<string, DataTable>(StringComparer.Ordinal);
            foreach (var group in mapping.Groups)
            {
                var table = new DataTable(group.Name);
                table.Columns.Add("Slot", typeof(int));
                foreach (var field in group.Fields)
                    table.Columns.Add(field.Name, source.Columns[field.Columns[0]]!.DataType);
                for (int slot = 0; slot < group.Capacity; slot++)
                {
                    var values = new object[group.Fields.Count + 1];
                    values[0] = slot + 1;
                    for (int f = 0; f < group.Fields.Count; f++)
                        values[f + 1] = row == null ? DBNull.Value : row[group.Fields[f].Columns[slot]];
                    table.Rows.Add(values);
                }
                table.AcceptChanges();
                table.Columns["Slot"]!.ReadOnly = true;
                tables.Add(group.Name, table);
            }
            Details = new System.Collections.ObjectModel.ReadOnlyDictionary<string, DataTable>(tables);
            Master.AcceptChanges();
        }

        private static DataTable TypedTable(DataTable source, IEnumerable<string> names, string name)
        {
            var result = new DataTable(name);
            foreach (var n in names) result.Columns.Add(n, source.Columns[n]!.DataType);
            return result;
        }

        public static FlatRecord FromRow(FlatMapping mapping, DataRow row) => new FlatRecord(mapping, row.Table, row);
        public static FlatRecord Create(FlatMapping mapping, DataTable databaseSchema) => new FlatRecord(mapping, databaseSchema, null);

        /// <summary>Clears a fixed slot. Defaults to NULL; provide zero/empty values if the DB requires them.</summary>
        public void ClearDetail(string groupName, int slot, IReadOnlyDictionary<string, object?>? emptyValues = null)
        {
            var group = Mapping.Groups.Single(g => g.Name == groupName);
            if (slot < 1 || slot > group.Capacity) throw new ArgumentOutOfRangeException(nameof(slot));
            var row = Details[groupName].Rows.Cast<DataRow>().Single(r => r.RowState != DataRowState.Deleted && (int)r["Slot"] == slot);
            foreach (var field in group.Fields)
                row[field.Name] = emptyValues != null && emptyValues.TryGetValue(field.Name, out var v) ? v ?? DBNull.Value : DBNull.Value;
        }

        public DataTable ToWideTable()
        {
            if (Master.Rows.Count != 1 || Master.Rows[0].RowState == DataRowState.Deleted)
                throw new InvalidOperationException("Exactly one master row is required.");
            Master.Rows[0].EndEdit();
            var output = schema.Clone();
            var row = output.NewRow();
            foreach (var column in Mapping.MasterColumns) row[column] = Master.Rows[0][column];
            foreach (var group in Mapping.Groups)
            {
                var table = Details[group.Name];
                if (table.Rows.Count != group.Capacity || table.Rows.Cast<DataRow>().Any(r => r.RowState == DataRowState.Deleted))
                    throw new InvalidOperationException("Fixed slots cannot be added/deleted. Use ClearDetail: " + group.Name);
                var slots = new HashSet<int>();
                foreach (DataRow detail in table.Rows)
                {
                    detail.EndEdit();
                    int slot = (int)detail["Slot"];
                    if (slot < 1 || slot > group.Capacity || !slots.Add(slot))
                        throw new InvalidOperationException("Invalid/duplicate slot: " + group.Name);
                    foreach (var field in group.Fields) row[field.Columns[slot - 1]] = detail[field.Name];
                }
            }
            output.Rows.Add(row);
            return output;
        }

        /// <summary>Returns a copy so callers cannot corrupt the concurrency snapshot.</summary>
        public DataTable? OriginalValues() => original?.Copy();
        public FlatRecord CopyForEditing() => new FlatRecord(Mapping, schema, original == null ? null : original.Rows[0]).WithCurrent(ToWideTable().Rows[0]);
        private FlatRecord WithCurrent(DataRow current)
        {
            foreach (var c in Mapping.MasterColumns) Master.Rows[0][c] = current[c];
            foreach (var g in Mapping.Groups)
                for (int s = 0; s < g.Capacity; s++)
                    foreach (var f in g.Fields) Details[g.Name].Rows[s][f.Name] = current[f.Columns[s]];
            return this;
        }
    }
}
