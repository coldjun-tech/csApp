using System.Data;
using FlatMasterDetail;

namespace WinFormsDemo;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        var mapping = LfHeatMapping.Create();
        // DEMO ONLY: replaced with FlatRepository for persistent DB storage (see README).
        IFlatRecordStore store = new InMemoryFlatStore(mapping, DemoData.CreateSeed(mapping), "sHeatNum_001", "iRtryCnt_002");
        Application.Run(new EditorForm(mapping, store, new[] { "sHeatNum_001", "iRtryCnt_002" }));
    }
}

public sealed class EditorForm : Form
{
    private readonly FlatMapping mapping;
    private readonly IFlatRecordStore store;
    private readonly string[] keys;
    private readonly DataGridView list = Grid();
    private readonly TabControl tabs = new() { Dock = DockStyle.Fill };
    private readonly FlowLayoutPanel toolbar = new() { Dock = DockStyle.Top, Height = 46 };
    private readonly Label status = new() { Dock = DockStyle.Bottom, Height = 26 };
    private readonly Dictionary<string, BindingSource> detailSources = new();
    private BindingSource? masterSource;
    private DataTable? schema;
    private FlatRecord? current;
    private Dictionary<string, object?>? loadedKey;

    public EditorForm(FlatMapping mapping, IFlatRecordStore store, string[] keys)
    {
        this.mapping = mapping;
        this.store = store;
        this.keys = keys;
        Text = "단일 테이블 마스터·디테일 편집 — 기본 실행은 메모리 데모";
        Width = 1350; Height = 850;
        var split = new SplitContainer { Dock = DockStyle.Fill, Size = new Size(1300, 750), Orientation = Orientation.Horizontal, SplitterDistance = 240 };
        split.Panel1.Controls.Add(list);
        split.Panel2.Controls.Add(tabs);
        Controls.Add(split); Controls.Add(toolbar); Controls.Add(status);
        list.ReadOnly = true; list.MultiSelect = false; list.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        AddButton("목록 조회", ReloadList);
        AddButton("선택 열기", OpenSelected);
        AddButton("신규 입력", NewRecord);
        AddButton("저장", Save);
        AddButton("취소 / 다시 읽기", Cancel);
        AddButton("선택 디테일 비우기", ClearSlot);
        AddButton("전체 삭제", Delete);
        Shown += async (_, _) => await Run(ReloadList);
        list.CellDoubleClick += async (_, e) => { if (e.RowIndex >= 0) await Run(OpenSelected); };
    }

    private static DataGridView Grid() => new()
    {
        Dock = DockStyle.Fill, AutoGenerateColumns = true, AllowUserToAddRows = false,
        AllowUserToDeleteRows = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells
    };
    private void AddButton(string text, Func<Task> action)
    {
        var button = new Button { Text = text, AutoSize = true, Height = 32 };
        button.Click += async (_, _) => await Run(action);
        toolbar.Controls.Add(button);
    }
    private async Task Run(Func<Task> action)
    {
        toolbar.Enabled = false; list.Enabled = false; tabs.Enabled = false;
        try { await action(); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "처리 실패", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        finally { toolbar.Enabled = true; list.Enabled = true; tabs.Enabled = true; }
    }
    private async Task ReloadList()
    {
        var rows = await store.QueryAsync();
        schema = rows.Clone();
        // Show just master columns in the record list, not the 80 repeated physical columns.
        list.DataSource = new DataView(rows).ToTable(false, mapping.MasterColumns.ToArray());
        status.Text = $"{rows.Rows.Count}건 조회. 저장 전 편집 내용은 목록 조회 후에도 유지됩니다.";
    }
    private async Task OpenSelected()
    {
        if (list.CurrentRow?.DataBoundItem is not DataRowView selected) return;
        if (!ConfirmDiscard()) return;
        var key = keys.ToDictionary(k => k, k => (object?)selected[k]);
        var found = await store.FindAsync(key) ?? throw new InvalidOperationException("이미 삭제된 데이터입니다.");
        loadedKey = key;
        Bind(found);
    }
    private async Task NewRecord()
    {
        if (!ConfirmDiscard()) return;
        if (schema == null) await ReloadList();
        loadedKey = null;
        Bind(FlatRecord.Create(mapping, schema!));
    }
    private void Bind(FlatRecord record)
    {
        foreach (TabPage page in tabs.TabPages.Cast<TabPage>().ToArray()) { tabs.TabPages.Remove(page); page.Dispose(); }
        masterSource?.Dispose();
        foreach (var source in detailSources.Values) source.Dispose();
        detailSources.Clear(); current = record;
        masterSource = new BindingSource { DataSource = record.Master };
        var masterGrid = Grid();
        masterGrid.DataBindingComplete += (_, _) =>
        {
            foreach (var key in keys)
                if (masterGrid.Columns.Contains(key)) masterGrid.Columns[key].ReadOnly = !record.IsNew;
        };
        masterGrid.DataSource = masterSource;
        AddTab("기본정보", masterGrid);
        foreach (var group in mapping.Groups)
        {
            var source = new BindingSource { DataSource = record.Details[group.Name] };
            detailSources.Add(group.Name, source);
            var grid = Grid();
            grid.DataBindingComplete += (_, _) =>
            {
                if (grid.Columns.Contains("Slot")) grid.Columns["Slot"].ReadOnly = true;
            };
            grid.DataSource = source;
            var page = AddTab(group.Name == "Measurements" ? "측정값 (5회)" : "정지정보 (10회)", grid);
            page.Tag = group.Name;
        }
        status.Text = record.IsNew ? "신규: 기본키와 필수값을 입력한 후 저장하세요." : "편집 후 저장하세요. 전체 삭제는 기본정보와 모든 디테일을 삭제합니다.";
    }
    private TabPage AddTab(string name, Control control)
    {
        var page = new TabPage(name); page.Controls.Add(control); tabs.TabPages.Add(page); return page;
    }
    private void EndEdits()
    {
        foreach (TabPage page in tabs.TabPages)
            if (page.Controls[0] is DataGridView grid && !grid.EndEdit()) throw new InvalidOperationException("셀 입력값을 확인하세요.");
        masterSource?.EndEdit();
        foreach (var source in detailSources.Values) source.EndEdit();
    }
    private bool ConfirmDiscard()
    {
        if (current == null) return true;
        return MessageBox.Show(this, "현재 편집을 닫고 다른 데이터를 여시겠습니까? 저장하지 않은 내용은 사라집니다.", "편집 종료", MessageBoxButtons.YesNo) == DialogResult.Yes;
    }
    private async Task Save()
    {
        if (current == null) return;
        EndEdits();
        var saved = current.IsNew ? await store.InsertAsync(current) : await store.UpdateAsync(current);
        loadedKey = keys.ToDictionary(k => k, k => (object?)saved.Master.Rows[0][k]);
        Bind(saved); await ReloadList(); status.Text = "저장 완료";
    }
    private async Task Cancel()
    {
        if (current == null || !ConfirmDiscard()) return;
        if (loadedKey == null) { Bind(FlatRecord.Create(mapping, schema!)); return; }
        var record = await store.FindAsync(loadedKey) ?? throw new InvalidOperationException("다른 사용자가 삭제했습니다.");
        Bind(record);
    }
    private Task ClearSlot()
    {
        if (current == null || tabs.SelectedTab?.Tag is not string group) return Task.CompletedTask;
        EndEdits();
        var grid = (DataGridView)tabs.SelectedTab.Controls[0];
        if (grid.CurrentRow?.DataBoundItem is DataRowView view) current.ClearDetail(group, (int)view["Slot"]);
        return Task.CompletedTask;
    }
    private async Task Delete()
    {
        if (current == null || current.IsNew) return;
        if (MessageBox.Show(this, "이 마스터와 모든 디테일을 DB에서 삭제하시겠습니까?", "전체 삭제", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        await store.DeleteAsync(current);
        current = null; loadedKey = null;
        foreach (TabPage page in tabs.TabPages.Cast<TabPage>().ToArray()) { tabs.TabPages.Remove(page); page.Dispose(); }
        await ReloadList(); status.Text = "삭제 완료";
    }
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (!ConfirmDiscard()) e.Cancel = true;
        base.OnFormClosing(e);
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) { masterSource?.Dispose(); foreach (var source in detailSources.Values) source.Dispose(); }
        base.Dispose(disposing);
    }
}
