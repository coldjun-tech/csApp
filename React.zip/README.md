# InspData React MVVM

기존 C# WinForms의 InspData만 React로 이식했습니다. Scpatrg, Group1/Group2, 마스터·디테일 매퍼와 화면은 포함하지 않습니다. 목록과 편집 폼은 동일한 `tb_insp_data` 레코드 하나를 다룹니다.

## 실행

Node.js 22.12 이상을 사용하세요. PowerShell에서는 실행 정책에 영향을 받지 않는 `npm.cmd`로 실행할 수 있습니다.

```powershell
cd C:\01_project\src\L2SystemAdmin\React
npm.cmd install
npm.cmd run dev
```

터미널에 표시된 로컬 주소로 접속합니다(기본 `http://127.0.0.1:5173`).

```powershell
npm.cmd test
npm.cmd run build
npm.cmd run preview
```

기본 실행은 **브라우저 로컬 저장소**를 사용하며 빈 목록으로 시작합니다. 추가 → 입력 → 저장 순서로 등록하세요. 같은 브라우저/주소에서는 새로고침 후에도 데이터가 유지됩니다. 브라우저 저장공간이 부족하면 오류가 표시되며 편집본을 유지합니다. 개발 서버와 preview 서버는 포트가 달라 저장소도 별개입니다.

## C# 대응 구조

| 기존 C# | React | 역할 |
| --- | --- | --- |
| `Using/ucsDataModels.cs` / `TModel_InspData` | `src/models/InspData.js` | 전체 속성, 기본값, 복합키, 검증, DTO 변환 |
| `Using/ucsDataRepositorys.cs` / `TRepoInspData` | `src/repositories/InspDataRepository.js` | 조회·추가·수정·삭제, 저장소 구현 |
| `Using/ucsDataViewModels.cs` / `TViewModel_InspData` | `src/viewmodels/InspDataViewModel.js` | Items, EditItem, IsInsert, IsBusy 및 작업 흐름 |
| `SYS/SYS101L.cs` / BindingSource | `src/views/InspDataView.jsx` | 목록, 편집 폼, 버튼, 오류 표시 |
| `INotifyPropertyChanged` | `subscribe`, `getSnapshot`, `useSyncExternalStore` | 화면 상태 변경 구독 |

View는 Repository를 직접 호출하지 않습니다. ViewModel은 React에 의존하지 않으므로 저장 실패, 편집본 분리, 상태 전환을 Node 테스트로 검증할 수 있습니다. 상태 구독은 [React 공식 문서](https://react.dev/reference/react/useSyncExternalStore)를 따르며 빌드는 [Vite](https://vite.dev/guide/build)를 사용합니다.

## 이식 내용

- C# 모델의 모든 DB 매핑 속성과 `PresValues1/PresValues2` 배열을 보존합니다. 배열은 C#과 같이 메모리 데이터로 유지하며, 직접 편집하는 압력 문자열은 `PressVals1/PressVals2`입니다.
- 신규 기본값은 현재 C# `BeforeInsert()`와 같은 발주번호 빈 문자열, 발주순번 `100`, 검사일자 당일입니다.
- 발주번호 필수, 순번 양의 정수, 유효한 검사일자, 신규 복합키 중복을 검증합니다. 수정 중에는 복합키를 잠급니다.
- 편집본은 목록과 별도로 복제합니다. 취소 시 원복하고, 저장소 호출이 성공한 후에만 목록을 갱신합니다. 오류 시 목록·선택·편집본을 유지합니다.
- 수정 후 조회·선택·추가·취소할 때 변경사항 폐기 확인을 표시합니다. 삭제는 대상 복합키를 보여 주고 확인합니다.
- 검색, UTF-8 BOM CSV 내보내기, 압력 차트 이미지 첨부/삭제/미리보기를 지원합니다. 이미지는 PNG/JPG/WebP, 최대 2MB입니다.
- C# 모델에서 `ProcStat`의 표시명이 검사일자로 되어 있는 부분은 진행 상태로 표시했습니다. `ChkUppRing` 표시명 오타도 수정했습니다.
- 기존 SYS101L의 신규 저장 시 현재 그리드 행을 전달하던 동작을 이식하지 않고, 현재 `EditItem`을 저장하도록 연결했습니다.
- C# Repository 조회 매핑에 빠진 TestDate, TestRslt, InspRemk, 압력·재질·이미지 등의 속성도 React에서는 보존합니다.

## 서버 연결

**기존 C# 프로그램은 WinForms 내부에서 MySQL을 호출하며, 현재 저장소에는 InspData HTTP API가 없습니다. 이 React 앱만으로 기존 MySQL에 연결되지는 않습니다.** DB 연결정보를 프런트엔드에 넣지 않습니다.

별도 백엔드가 아래 계약을 제공하면 `.env.example`을 `.env.local`로 복사하고 `VITE_INSPDATA_API_URL`을 설정한 뒤 개발 서버를 다시 시작하세요. 설정 시 Local Repository 대신 HTTP Repository를 사용합니다.

| 메서드 | 경로 | 요청 / 응답 |
| --- | --- | --- |
| GET | `/api/inspdata` | 전체 모델 JSON 배열 |
| POST | `/api/inspdata` | 모델 JSON → 저장된 모델 JSON 또는 204 |
| PUT | `/api/inspdata/{OrderNo}/{OrderSeq}` | 모델 JSON → 저장된 모델 JSON 또는 204 |
| DELETE | `/api/inspdata/{OrderNo}/{OrderSeq}` | 204 권장 |

JSON 속성명은 C#과 같은 PascalCase입니다. `TestDate`는 `YYYY-MM-DD`로 전송하며 조회 시 ISO 날짜·시간도 지원합니다. `PresChtImg`는 C# `byte[]` JSON 표현인 Base64로 전송합니다. 조회 시 DB 컬럼명인 `PressChtImg`와 바이트 배열도 허용합니다. 다른 속성은 원래 string 형식을 유지합니다. 서버는 복합키 유일성과 입력값을 다시 검증해야 합니다. 서버 주소가 다른 경우 백엔드의 CORS 설정이 필요합니다. 인증·페이징 등 실제 서버 계약이 다르면 HTTP Repository만 조정하세요.

테스트는 로컬 가짜 저장소와 가짜 HTTP 응답만 사용하며 기존 DB에 접근하지 않습니다.
