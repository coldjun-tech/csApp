import { clone, createInspData, fromDto, keyOf, toDto } from '../models/InspData.js';

const STORAGE_KEY = 'l2.inspdata.v1';

// Repository 계약: load(): item[], insert(item), update(item), delete(item).
// 모든 쓰기 메서드는 성공 후 저장된 item(삭제는 반환값 없음)을 반환합니다.
export class LocalInspDataRepository {
  constructor(storage = globalThis.localStorage) { this.storage = storage; }
  async load() {
    const raw = this.storage.getItem(STORAGE_KEY);
    if (raw === null) return [];
    const rows = JSON.parse(raw);
    if (!Array.isArray(rows)) throw new Error('저장 데이터 형식이 올바르지 않습니다.');
    return rows.map(fromDto);
  }
  async insert(item) {
    const rows = await this.load();
    if (rows.some(row => keyOf(row) === keyOf(item))) throw new Error('동일한 복합키의 데이터가 있습니다.');
    this.storage.setItem(STORAGE_KEY, JSON.stringify([...rows, item]));
    return clone(item);
  }
  async update(item) {
    const rows = await this.load();
    const index = rows.findIndex(row => keyOf(row) === keyOf(item));
    if (index < 0) throw new Error('수정할 데이터가 없습니다. 다시 조회하세요.');
    rows[index] = clone(item);
    this.storage.setItem(STORAGE_KEY, JSON.stringify(rows));
    return clone(item);
  }
  async delete(item) {
    const rows = await this.load();
    if (!rows.some(row => keyOf(row) === keyOf(item))) throw new Error('삭제할 데이터가 없습니다.');
    this.storage.setItem(STORAGE_KEY, JSON.stringify(rows.filter(row => keyOf(row) !== keyOf(item))));
  }
}

export class HttpInspDataRepository {
  constructor(baseUrl, fetcher = globalThis.fetch) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.fetcher = fetcher;
  }
  path(item) { return `/${encodeURIComponent(item.OrderNo)}/${item.OrderSeq}`; }
  async request(path = '', method = 'GET', item) {
    const response = await this.fetcher(`${this.baseUrl}${path}`, {
      method, headers: { 'Content-Type': 'application/json' },
      body: item ? JSON.stringify(toDto(item)) : undefined,
    });
    if (!response.ok) throw new Error(`서버 요청 실패 (${response.status}). 저장소와 서버 상태를 확인하세요.`);
    if (response.status === 204) return undefined;
    const text = await response.text();
    return text ? JSON.parse(text) : undefined;
  }
  async load() {
    const rows = await this.request();
    if (!Array.isArray(rows)) throw new Error('API 조회 응답은 JSON 배열이어야 합니다.');
    return rows.map(fromDto);
  }
  async insert(item) { return fromDto(await this.request('', 'POST', item) ?? createInspData(item)); }
  async update(item) { return fromDto(await this.request(this.path(item), 'PUT', item) ?? item); }
  async delete(item) { await this.request(this.path(item), 'DELETE'); }
}
