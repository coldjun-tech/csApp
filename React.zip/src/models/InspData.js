// C# TModel_InspData의 속성명 및 저장 형식을 유지합니다.
export const fieldGroups = [
  { title: '기본 정보', fields: [
    ['OrderNo', '발주번호'], ['OrderSeq', '발주순번', 'number'],
    ['ProcStat', '진행 상태'], ['TestDate', '검사일자', 'date'],
    ['CustCode', '거래처코드'], ['ItemNo', '품목번호'], ['Plant', '설비 / Plant'],
    ['Maker', '제조사'], ['Model', '모델'], ['Serial', '제조번호'], ['Type', '형식'],
  ] },
  { title: '밸브 및 시험 조건', fields: [
    ['Inlet', '입구 / Inlet'], ['Outlet', '출구 / Outlet'],
    ['Capct', '용량'], ['CapctUnit', '용량 단위'], ['Fluid', '사용 유체'],
    ['SetPress', '설정 압력'], ['BackPress', '배압'], ['TestPress', '시험 압력'],
    ['CDS', 'CDS'], ['Unit', '압력 단위'], ['Reglt', '적용 규격'],
    ['TestFluid', '시험 유체'], ['TestRslt', '시험 결과'],
    ['BodyMatl', '몸체 재질'], ['DiscMatl', '디스크 재질'],
  ] },
  { title: '압력 측정', fields: [
    ['PoppPress1', '1차 개방 압력'], ['ClosPress1', '1차 닫힘 압력'],
    ['PoppPress2', '2차 개방 압력'], ['ClosPress2', '2차 닫힘 압력'],
  ] },
  { title: '부품 검사', fields: [
    ['ChkCap', '캡'], ['ChkBonnet', '보닛'], ['ChkBody', '몸체'],
    ['ChkNozz', '노즐'], ['ChkNozzSeat', '노즐 시트'], ['ChkDisc', '디스크'],
    ['ChkDiscSeat', '디스크 시트'], ['ChkBellows', '벨로즈'],
    ['ChkSpring', '스프링'], ['ChkSpindle', '스핀들'],
    ['ChkLowRing', '하부 링'], ['ChkUppRing', '상부 링'],
  ] },
  { title: '측정 데이터 및 비고', fields: [
    ['PressVals1', '1차 압력 데이터', 'textarea'],
    ['PressVals2', '2차 압력 데이터', 'textarea'],
    ['InspRemk', '검사 비고', 'textarea'],
  ] },
];

export const fields = fieldGroups.flatMap(group => group.fields);
export const localDate = (date = new Date()) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
export const clone = value => structuredClone(value);
export const keyOf = item => JSON.stringify([item.OrderNo, Number(item.OrderSeq)]);

export function createInspData(values = {}) {
  const item = Object.fromEntries(fields.map(([name]) => [name, '']));
  return { ...item, OrderSeq: 100, TestDate: localDate(), PresChtImg: null,
    PresValues1: [], PresValues2: [], ...clone(values) };
}

// DB 컬럼은 PressChtImg, C# 속성은 PresChtImg입니다.
// 브라우저의 이미지 표현은 data URL, API의 byte[] JSON 표현은 Base64입니다.
export function fromDto(dto) {
  const { PressChtImg, ...rest } = dto;
  const item = createInspData(rest);
  item.TestDate = String(item.TestDate ?? '').slice(0, 10);
  const image = item.PresChtImg ?? PressChtImg;
  if (image) {
    const base64 = Array.isArray(image) ? btoa(image.map(byte => String.fromCharCode(byte)).join('')) : image;
    item.PresChtImg = base64.startsWith('data:') ? base64 : `data:image/png;base64,${base64}`;
  }
  return item;
}

export function toDto(item) {
  const dto = clone(item);
  if (dto.PresChtImg?.startsWith('data:')) dto.PresChtImg = dto.PresChtImg.split(',')[1];
  return dto;
}

export function validateInspData(item, items, isInsert, selectedKey) {
  const errors = {};
  if (!item) return { _form: '편집할 데이터를 선택하세요.' };
  if (!item.OrderNo.trim()) errors.OrderNo = '발주번호를 입력하세요.';
  if (!Number.isSafeInteger(Number(item.OrderSeq)) || Number(item.OrderSeq) < 1)
    errors.OrderSeq = '발주순번은 1 이상의 정수여야 합니다.';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(item.TestDate) ||
      !Number.isFinite(Date.parse(item.TestDate)) ||
      new Date(item.TestDate).toISOString().slice(0, 10) !== item.TestDate)
    errors.TestDate = '올바른 검사일자를 입력하세요.';
  if (isInsert && items.some(row => keyOf(row) === keyOf(item)))
    errors.OrderSeq = '동일한 발주번호와 발주순번이 있습니다.';
  if (!isInsert && keyOf(item) !== selectedKey)
    errors.OrderNo = '기존 데이터의 발주번호와 발주순번은 변경할 수 없습니다.';
  return errors;
}
