import React from 'react';
import { createRoot } from 'react-dom/client';
import { InspDataViewModel } from './viewmodels/InspDataViewModel.js';
import { HttpInspDataRepository, LocalInspDataRepository } from './repositories/InspDataRepository.js';
import { InspDataView } from './views/InspDataView.jsx';
import './styles.css';

const apiUrl = import.meta.env.VITE_INSPDATA_API_URL;
const repository = apiUrl ? new HttpInspDataRepository(apiUrl) : new LocalInspDataRepository();
const viewModel = new InspDataViewModel(repository);
createRoot(document.getElementById('root')).render(
  <InspDataView viewModel={viewModel} storageLabel={apiUrl ? '서버 API' : '브라우저 로컬 저장소'} />,
);
