import React, { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { fieldGroups, keyOf, localDate } from '../models/InspData.js';
import { toCsv } from '../utils/csv.js';

const columns = [
  ['OrderNo', '발주번호'], ['OrderSeq', '순번'], ['TestDate', '검사일자'],
  ['CustCode', '거래처'], ['ItemNo', '품목번호'], ['Plant', '설비'],
  ['Model', '모델'], ['SetPress', '설정 압력'], ['TestRslt', '시험 결과'],
];

export function InspDataView({ viewModel: vm, storageLabel }) {
  const state = useSyncExternalStore(vm.subscribe, vm.getSnapshot);
  const [query, setQuery] = useState('');
  const [imageError, setImageError] = useState('');
  const imageReader = useRef(0);
  const { Items, EditItem, SelectedKey, IsInsert, IsBusy, IsDirty, Errors, Message, Failure } = state;
  useEffect(() => { void vm.load(); }, [vm]);
  useEffect(() => { imageReader.current++; setImageError(''); }, [SelectedKey, IsInsert]);
  useEffect(() => {
    const beforeUnload = event => { if (IsDirty) { event.preventDefault(); event.returnValue = ''; } };
    window.addEventListener('beforeunload', beforeUnload);
    return () => window.removeEventListener('beforeunload', beforeUnload);
  }, [IsDirty]);

  const visible = Items.filter(item => columns.some(([name]) =>
    String(item[name] ?? '').toLowerCase().includes(query.trim().toLowerCase())));
  const canLeave = () => !IsDirty || window.confirm('저장하지 않은 변경사항을 버리시겠습니까?');
  const move = action => { if (canLeave()) { imageReader.current++; setImageError(''); action(); } };
  const exportCsv = () => {
    const url = URL.createObjectURL(new Blob([toCsv(visible)], { type: 'text/csv;charset=utf-8;' }));
    const anchor = document.createElement('a');
    anchor.href = url; anchor.download = `InspData_${localDate()}.csv`; anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const upload = event => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 2 * 1024 * 1024) {
      setImageError('PNG, JPG, WebP 이미지를 2MB 이하로 선택하세요.'); return;
    }
    const version = ++imageReader.current;
    const draft = vm.getSnapshot().EditItem;
    const reader = new FileReader();
    reader.onload = () => {
      if (version !== imageReader.current || draft !== vm.getSnapshot().EditItem) return;
      setImageError(''); vm.setField('PresChtImg', reader.result);
    };
    reader.onerror = () => setImageError('이미지를 읽을 수 없습니다.');
    reader.readAsDataURL(file);
  };

  return <div className="app-shell">
    <header className="app-header">
      <div className="brand"><span className="brand-icon">L2</span><div><strong>System Admin</strong><span>검사 데이터 관리 시스템</span></div></div>
      <span className="storage"><i />{storageLabel}</span>
    </header>
    <main aria-busy={IsBusy}>
      <div className="page-heading"><div><p className="eyebrow">QUALITY MANAGEMENT / SYS101L</p><h1>검사 데이터 <span>InspData</span></h1><p>발주별 검사 정보와 시험 결과를 관리합니다.</p></div><span className="count-chip">전체 {Items.length}건</span></div>
      <div className="toolbar" aria-label="데이터 작업">
        <div className="toolbar-actions">
          <button disabled={IsBusy} onClick={() => move(() => vm.load())}>↻ 조회</button>
          <button disabled={IsBusy} onClick={() => move(() => vm.beforeInsert())}>＋ 추가</button>
          <button className="primary" disabled={IsBusy || !EditItem} onClick={() => { imageReader.current++; void vm.save(); }}>저장</button>
          <button disabled={IsBusy || !EditItem} onClick={() => move(() => vm.cancel())}>취소</button>
          <button className="danger" disabled={IsBusy || IsInsert || !SelectedKey} onClick={() => {
            if (window.confirm(`${EditItem.OrderNo} / ${EditItem.OrderSeq} 데이터를 삭제하시겠습니까?`)) {
              imageReader.current++; void vm.deleteSelected();
            }
          }}>삭제</button>
        </div>
        <button disabled={IsBusy || !visible.length} onClick={exportCsv}>↓ CSV 내보내기</button>
      </div>
      <div className="feedback" aria-live="polite">
        {IsBusy ? '처리 중입니다…' : Failure ? <span role="alert" className="error-text">{Failure}</span> :
          Object.keys(Errors).length ? <span role="alert" className="error-text">{Object.values(Errors).join(' ')}</span> : Message || '조회 또는 추가 버튼으로 시작하세요.'}
      </div>
      <section className="panel list-panel" aria-labelledby="list-title">
        <div className="panel-heading"><div><h2 id="list-title">검사 목록 <span>{visible.length}</span></h2><p>행을 선택하면 아래에서 같은 검사 데이터를 편집할 수 있습니다.</p></div>
          <label className="search"><span className="sr-only">검사 목록 검색</span><input type="search" placeholder="발주번호, 거래처, 품목 검색" value={query} onChange={e => setQuery(e.target.value)} /></label>
        </div>
        <div className="table-wrap"><table><thead><tr>{columns.map(([name, label]) => <th key={name} scope="col">{label}</th>)}</tr></thead>
          <tbody>{visible.map(item => <tr key={keyOf(item)} className={keyOf(item) === SelectedKey ? 'selected' : ''}>
            {columns.map(([name], index) => <td key={name}>{index === 0 ? <button className="row-link" aria-pressed={keyOf(item) === SelectedKey} disabled={IsBusy} onClick={() => move(() => vm.select(item))}>{item[name]}</button> :
              name === 'TestRslt' && item[name] ? <span className={`result ${item[name] === 'PASS' ? 'pass' : item[name] === 'FAIL' ? 'fail' : ''}`}>{item[name]}</span> : item[name] || '—'}</td>)}
          </tr>)}</tbody></table>
          {!visible.length && <div className="empty"><span>▤</span><strong>{Items.length ? '검색 결과가 없습니다.' : '등록된 검사 데이터가 없습니다.'}</strong><p>{Items.length ? '검색어를 변경해 보세요.' : '추가 버튼을 눌러 첫 검사 데이터를 등록하세요.'}</p></div>}
        </div>
      </section>
      <section className="panel editor-panel" aria-labelledby="editor-title">
        <div className="panel-heading"><div><h2 id="editor-title">검사 데이터 편집</h2><p>{EditItem ? `${IsInsert ? '신규 등록' : `${EditItem.OrderNo} / ${EditItem.OrderSeq}`} · * 필수 입력` : '목록에서 데이터를 선택하거나 새로 추가하세요.'}</p></div>
          {EditItem && <span className={`edit-chip ${IsDirty ? 'dirty' : ''}`}>{IsDirty ? '저장 전 변경사항' : IsInsert ? '신규' : '저장됨'}</span>}
        </div>
        {EditItem ? <form noValidate onSubmit={event => { event.preventDefault(); imageReader.current++; void vm.save(); }}>
          <fieldset disabled={IsBusy} className="editor-fields">
            {fieldGroups.map(group => <section className="field-section" key={group.title}><h3>{group.title}</h3><div className="field-grid">
              {group.fields.map(([name, label, type = 'text']) => {
                const locked = !IsInsert && ['OrderNo', 'OrderSeq'].includes(name);
                const props = { id: name, name, value: EditItem[name] ?? '', readOnly: locked,
                  'aria-invalid': !!Errors[name], 'aria-describedby': Errors[name] ? `${name}-error` : undefined,
                  onChange: event => vm.setField(name, event.target.value) };
                return <div className={`field ${type === 'textarea' ? 'wide' : ''}`} key={name}>
                  <label htmlFor={name}>{label}{['OrderNo', 'OrderSeq', 'TestDate'].includes(name) && <span className="required"> *</span>}<small>{name}</small></label>
                  {type === 'textarea' ? <textarea {...props} rows={name === 'InspRemk' ? 3 : 2} /> : <input {...props} type={type} min={type === 'number' ? 1 : undefined} step={type === 'number' ? 1 : undefined} required={['OrderNo', 'OrderSeq', 'TestDate'].includes(name)} />}
                  {Errors[name] && <span className="field-error" id={`${name}-error`}>{Errors[name]}</span>}
                </div>;
              })}
            </div></section>)}
            <section className="field-section"><h3>압력 차트 이미지</h3><div className="image-tools"><label className="upload-button">이미지 선택<input type="file" accept="image/png,image/jpeg,image/webp" onChange={upload} /></label><span>PNG · JPG · WebP / 최대 2MB</span>
              {EditItem.PresChtImg && <button type="button" onClick={() => { imageReader.current++; vm.setField('PresChtImg', null); }}>이미지 제거</button>}</div>
              {imageError && <p role="alert" className="error-text">{imageError}</p>}
              {EditItem.PresChtImg && <img className="chart-image" src={EditItem.PresChtImg} alt="검사 압력 차트" />}
            </section>
          </fieldset>
          <footer className="editor-footer"><span>{IsDirty ? '변경한 내용을 저장하세요.' : '검사 정보를 확인하세요.'}</span><button type="submit" className="primary" disabled={IsBusy}>검사 데이터 저장</button></footer>
        </form> : <div className="empty editor-empty"><span>✎</span><strong>선택된 검사 데이터가 없습니다.</strong><p>신규 검사 정보를 등록할 수 있습니다.</p><button className="primary" disabled={IsBusy} onClick={() => vm.beforeInsert()}>＋ 검사 데이터 추가</button></div>}
      </section>
      <footer className="page-footer">L2 System Admin <span>InspData · 검사 정보 관리</span></footer>
    </main>
  </div>;
}
