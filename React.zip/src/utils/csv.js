import { fields } from '../models/InspData.js';

// Excel 수식 실행을 방지하면서 쉼표, 따옴표, 줄바꿈을 보존합니다.
const cell = value => {
  let text = String(value ?? '');
  if (/^[\s]*[=+\-@]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
};
export function toCsv(items) {
  return '\uFEFF' + [fields.map(([, label]) => cell(label)).join(','),
    ...items.map(item => fields.map(([name]) => cell(item[name])).join(','))].join('\r\n');
}
