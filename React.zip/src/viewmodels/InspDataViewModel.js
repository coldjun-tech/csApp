import { clone, createInspData, keyOf, validateInspData } from '../models/InspData.js';

// React에 의존하지 않는 ViewModel. INotifyPropertyChanged → subscribe/getSnapshot.
export class InspDataViewModel {
  constructor(repository) {
    this.repository = repository;
    this.listeners = new Set();
    this.state = { Items: [], SelectedKey: null, EditItem: null, IsInsert: false,
      IsBusy: false, IsDirty: false, Errors: {}, Message: '', Failure: '' };
  }
  subscribe = listener => { this.listeners.add(listener); return () => this.listeners.delete(listener); };
  getSnapshot = () => this.state;
  publish(patch) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach(listener => listener());
  }
  get SelectedItem() { return this.state.Items.find(row => keyOf(row) === this.state.SelectedKey) ?? null; }
  select(item) {
    if (this.state.IsBusy) return;
    this.publish({ SelectedKey: item ? keyOf(item) : null, EditItem: item ? clone(item) : null,
      IsInsert: false, IsDirty: false, Errors: {}, Failure: '', Message: '' });
  }
  beforeInsert() {
    if (this.state.IsBusy) return;
    this.publish({ SelectedKey: null, EditItem: createInspData(), IsInsert: true,
      IsDirty: false, Errors: {}, Failure: '', Message: '새 검사 데이터를 입력하세요.' });
  }
  setField(name, value) {
    if (this.state.IsBusy || !this.state.EditItem) return;
    const errors = { ...this.state.Errors };
    delete errors[name];
    this.publish({ EditItem: { ...this.state.EditItem, [name]: value }, IsDirty: true,
      Errors: errors, Message: '', Failure: '' });
  }
  cancel() {
    if (this.state.IsBusy) return;
    this.select(this.SelectedItem ?? this.state.Items[0] ?? null);
  }
  async run(operation) {
    if (this.state.IsBusy) return false;
    this.publish({ IsBusy: true, Failure: '', Message: '' });
    try { await operation(); return true; }
    catch (error) {
      this.publish({ Failure: error instanceof Error ? error.message : '작업에 실패했습니다.' });
      return false;
    } finally { this.publish({ IsBusy: false }); }
  }
  async load() {
    return this.run(async () => {
      const items = await this.repository.load();
      const selected = items.find(item => keyOf(item) === this.state.SelectedKey) ?? items[0] ?? null;
      this.publish({ Items: clone(items), SelectedKey: selected ? keyOf(selected) : null,
        EditItem: selected ? clone(selected) : null, IsInsert: false, IsDirty: false,
        Errors: {}, Message: `${items.length}건을 조회했습니다.` });
    });
  }
  async save() {
    if (this.state.IsBusy) return false;
    const item = this.state.EditItem ? clone(this.state.EditItem) : null;
    if (item) { item.OrderNo = item.OrderNo.trim(); item.OrderSeq = Number(item.OrderSeq); }
    const errors = validateInspData(item, this.state.Items, this.state.IsInsert, this.state.SelectedKey);
    if (Object.keys(errors).length) { this.publish({ Errors: errors, Message: '', Failure: '' }); return false; }
    return this.run(async () => {
      const saved = this.state.IsInsert ? await this.repository.insert(item) : await this.repository.update(item);
      const items = this.state.IsInsert ? [...this.state.Items, clone(saved)] :
        this.state.Items.map(row => keyOf(row) === this.state.SelectedKey ? clone(saved) : row);
      this.publish({ Items: items, SelectedKey: keyOf(saved), EditItem: clone(saved),
        IsInsert: false, IsDirty: false, Errors: {}, Message: '저장했습니다.' });
    });
  }
  async deleteSelected() {
    if (this.state.IsInsert || !this.SelectedItem) return false;
    return this.run(async () => {
      const selected = this.SelectedItem;
      await this.repository.delete(clone(selected));
      const index = this.state.Items.findIndex(row => keyOf(row) === keyOf(selected));
      const items = this.state.Items.filter(row => keyOf(row) !== keyOf(selected));
      const next = items[Math.min(index, items.length - 1)] ?? null;
      this.publish({ Items: items, SelectedKey: next ? keyOf(next) : null,
        EditItem: next ? clone(next) : null, IsInsert: false, IsDirty: false,
        Errors: {}, Message: '삭제했습니다.' });
    });
  }
}
