import test from 'node:test';
import assert from 'node:assert/strict';
import { createInspData, fields, fromDto, keyOf, toDto } from '../src/models/InspData.js';
import { InspDataViewModel } from '../src/viewmodels/InspDataViewModel.js';
import { HttpInspDataRepository, LocalInspDataRepository } from '../src/repositories/InspDataRepository.js';
import { toCsv } from '../src/utils/csv.js';

function setup() {
  const data = new Map();
  const storage = { getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, value) };
  const repo = new LocalInspDataRepository(storage);
  return { repo, vm: new InspDataViewModel(repo) };
}
const sample = () => createInspData({ OrderNo: 'ORD001', OrderSeq: 1, CustCode: 'C001',
  PresValues1: [1.2], PresChtImg: 'data:image/png;base64,AQID' });

test('new draft uses C# defaults and does not persist before save', async () => {
  const { vm, repo } = setup();
  vm.beforeInsert();
  assert.equal(vm.state.EditItem.OrderSeq, 100);
  assert.equal(vm.state.IsInsert, true);
  assert.deepEqual(await repo.load(), []);
  assert.equal(await vm.save(), false);
  assert.ok(vm.state.Errors.OrderNo);
  vm.setField('OrderNo', ' ORD001 ');
  assert.equal(await vm.save(), true);
  assert.equal(vm.state.EditItem.OrderNo, 'ORD001');
  assert.equal((await repo.load()).length, 1);
  assert.equal(vm.state.IsInsert, false);
});

test('editor, nested lists and image are isolated; cancel restores original', async () => {
  const { vm, repo } = setup();
  await repo.insert(sample()); await vm.load();
  vm.setField('CustCode', 'C002');
  vm.state.EditItem.PresValues1[0] = 9;
  assert.equal(vm.state.Items[0].CustCode, 'C001');
  assert.equal(vm.state.Items[0].PresValues1[0], 1.2);
  vm.cancel();
  assert.equal(vm.state.EditItem.CustCode, 'C001');
  assert.equal(vm.state.IsDirty, false);
});

test('update commits only after persistence and keeps all model fields', async () => {
  const { vm, repo } = setup();
  const item = sample();
  for (const [name] of fields) if (!['OrderNo', 'OrderSeq', 'TestDate'].includes(name)) item[name] = `${name} value`;
  await repo.insert(item); await vm.load();
  vm.setField('CustCode', 'C002');
  assert.equal(await vm.save(), true);
  assert.equal(vm.state.Items[0].CustCode, 'C002');
  assert.notEqual(vm.state.EditItem, vm.state.Items[0]);
  assert.deepEqual(vm.state.Items, await repo.load());
});

test('duplicate composite keys, changed existing keys and invalid sequences are rejected', async () => {
  const { vm, repo } = setup();
  await repo.insert(sample()); await vm.load();
  vm.setField('OrderNo', 'CHANGED');
  assert.equal(await vm.save(), false);
  vm.beforeInsert(); vm.setField('OrderNo', 'ORD001'); vm.setField('OrderSeq', 1);
  assert.equal(await vm.save(), false);
  for (const value of [0, -1, 1.5, '', 'abc']) {
    vm.setField('OrderSeq', value); assert.equal(await vm.save(), false);
  }
  vm.setField('OrderSeq', 2);
  assert.equal(await vm.save(), true);
  assert.equal((await repo.load()).length, 2);
});

test('invalid calendar date is rejected', async () => {
  const { vm } = setup(); vm.beforeInsert(); vm.setField('OrderNo', 'DATE');
  vm.setField('TestDate', '2026-02-30');
  assert.equal(await vm.save(), false); assert.ok(vm.state.Errors.TestDate);
});

test('write, load and delete failures preserve original data and unsaved input', async () => {
  const { vm, repo } = setup(); await repo.insert(sample()); await vm.load();
  vm.setField('CustCode', 'DRAFT');
  repo.update = async () => { throw new Error('write failed'); };
  assert.equal(await vm.save(), false);
  assert.equal(vm.state.IsBusy, false);
  assert.equal(vm.state.IsDirty, true);
  assert.equal(vm.state.Items[0].CustCode, 'C001');
  assert.equal(vm.state.EditItem.CustCode, 'DRAFT');
  repo.load = async () => { throw new Error('load failed'); };
  assert.equal(await vm.load(), false);
  assert.equal(vm.state.EditItem.CustCode, 'DRAFT');
  repo.delete = async () => { throw new Error('delete failed'); };
  assert.equal(await vm.deleteSelected(), false);
  assert.equal(vm.state.Items.length, 1);
  assert.equal(vm.state.EditItem.CustCode, 'DRAFT');
});

test('failed insert preserves new draft and clears busy state', async () => {
  const { vm, repo } = setup(); vm.beforeInsert(); vm.setField('OrderNo', 'NEW');
  repo.insert = async () => { throw new Error('quota exceeded'); };
  assert.equal(await vm.save(), false);
  assert.equal(vm.state.IsInsert, true);
  assert.equal(vm.state.IsBusy, false);
  assert.equal(vm.state.EditItem.OrderNo, 'NEW');
  assert.equal(vm.state.Items.length, 0);
});

test('delete selects remaining item and clears editor when last row is deleted', async () => {
  const { vm, repo } = setup(); await repo.insert(sample());
  await repo.insert(createInspData({ OrderNo: 'ORD002', OrderSeq: 1 }));
  await vm.load(); await vm.deleteSelected();
  assert.equal(vm.state.EditItem.OrderNo, 'ORD002');
  await vm.deleteSelected();
  assert.equal(vm.state.SelectedKey, null); assert.equal(vm.state.EditItem, null);
  assert.deepEqual(await repo.load(), []); assert.equal(await vm.save(), false);
});

test('busy operation prevents duplicate save and edit mutations', async () => {
  const { vm, repo } = setup(); vm.beforeInsert(); vm.setField('OrderNo', 'NEW');
  let release;
  repo.insert = item => new Promise(resolve => { release = () => resolve(item); });
  const first = vm.save();
  assert.equal(vm.state.IsBusy, true);
  assert.equal(await vm.save(), false);
  vm.setField('OrderNo', 'OTHER'); vm.beforeInsert();
  assert.equal(vm.state.EditItem.OrderNo, 'NEW');
  release(); assert.equal(await first, true);
});

test('HTTP adapter handles DTO date, image, encoded keys and empty 204 responses', async () => {
  const calls = [];
  const repo = new HttpInspDataRepository('/api/inspdata/', async (url, options) => {
    calls.push({ url, options });
    return options.method === 'GET' ? { ok: true, status: 200,
      text: async () => JSON.stringify([{ OrderNo: 'A/B', OrderSeq: 2, TestDate: '2026-11-27T00:00:00', PressChtImg: [1, 2, 3] }]) } :
      { ok: true, status: 204 };
  });
  const item = (await repo.load())[0];
  assert.equal(item.TestDate, '2026-11-27');
  assert.equal(item.PresChtImg, 'data:image/png;base64,AQID');
  assert.deepEqual(await repo.update(item), item);
  assert.equal(calls[1].url, '/api/inspdata/A%2FB/2');
  assert.equal(JSON.parse(calls[1].options.body).PresChtImg, 'AQID');
  await repo.delete(item);
  assert.equal(toDto(fromDto(sample())).PresChtImg, 'AQID');
});

test('HTTP failure does not silently succeed', async () => {
  const repo = new HttpInspDataRepository('/api', async () => ({ ok: false, status: 409 }));
  await assert.rejects(repo.insert(sample()), /409/);
});

test('CSV includes BOM and escapes quotes, newlines, delimiters and spreadsheet formulas', () => {
  const csv = toCsv([createInspData({ OrderNo: '=1+1', InspRemk: 'a,"b"\nc' })]);
  assert.equal(csv.charCodeAt(0), 0xfeff);
  assert.ok(csv.includes('"\'=1+1"'));
  assert.ok(csv.includes('"a,""b""\nc"'));
  assert.equal(keyOf({ OrderNo: 'A', OrderSeq: '1' }), keyOf({ OrderNo: 'A', OrderSeq: 1 }));
});
