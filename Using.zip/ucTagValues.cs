﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

namespace pcms
{
    public class TagItem
    {
        public string TagName;
        public string TagCapt;
        public double TagValue;
        public double ValueScale;

        public TagItem()
        {
            TagName = "";
            TagCapt = "";
            TagValue = 0.0;
            ValueScale = 0.0;
        }

        public TagItem(string asTagname, string asTagCapt, double afTagValue, double afValueScale)
        {
            TagName = asTagname;
            TagCapt = asTagCapt;
            TagValue = afTagValue;
            ValueScale = afValueScale;
        }
    }

    public static class TagValues
    {
        //public static double[] ADAM_Pv = new double[4];
        //public static List<TagItem> OPC_PV = new List<TagItem>(); // 화면모니터링

        //public static DataTable DataTableCount = new DataTable();
        //public static Dictionary<string, int> CountDatas = new Dictionary<string, int>();

        static TagValues()
        {
            //CountDatas.Clear();
        }

        // TagValues.SrcToPulseValue(50, 0.0, 50.0, 100, 1);
        public static double SrcToPulseValue(int piSrcValue, double pdSrcMin, double pdSrcMax, int piResolution, int piDecimals)
        {
            return Math.Round((pdSrcMin + Convert.ToDouble(((pdSrcMax - pdSrcMin) / piResolution) * piSrcValue)), piDecimals);
        }

        // TagValues.PulseValueToSrc(dTemp, 0.0, 50.0, 100)
        public static int PulseValueToSrc(double pdPulseValue, double pdSrcMin, double pdSrcMax, int piResolution)
        {
            return Convert.ToInt32((pdPulseValue - pdSrcMin) * piResolution / (pdSrcMax - pdSrcMin));
        }
    } // public static class TagValues
}
