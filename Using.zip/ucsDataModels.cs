﻿using cnAppUtils;
using Microsoft.Win32;
using Org.BouncyCastle.Ocsp;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace cnData
{
    /* ---------------------------------------------------------------------------------------------- *
     * 설명  : - Model class 에서 사용하는 AttributeUsage 를 정의
     * TO_DO : 
     * ---------------------------------------------------------------------------------------------- *
     *   일  자   | 개발자 | 작  업  내  용
     * ---------------------------------------------------------------------------------------------- *
     * 2026.11.24 |        | 초기개발
     * ---------------------------------------------------------------------------------------------- */
    [AttributeUsage(AttributeTargets.Class)]
    public class DbTableAttribute : Attribute
    {
        public string TableName { get; set; }
        public DbTableAttribute(string tableName) { TableName = tableName; }
    }

    [AttributeUsage(AttributeTargets.Property)]
    public class DbColumnAttribute : Attribute
    {
        public string ColumnName { get; set; }
        public bool IsPrimaryKey { get; set; }
        public DbColumnAttribute(string columnName) { ColumnName = columnName; }
    }

    [AttributeUsage(AttributeTargets.Property)]
    public class DbRepeatListAttribute : Attribute
    {
        public int StartIndex { get; set; }
        public int EndIndex { get; set; }
        public DbRepeatListAttribute(int start, int end) { StartIndex = start; EndIndex = end; }
    }

    [AttributeUsage(AttributeTargets.Property)]
    public class DbRepeatColumnAttribute : Attribute
    {
        public string ColumnPattern { get; set; }
        public bool IsSequenceProperty { get; set; }
        public DbRepeatColumnAttribute(string pattern, bool isSequence = false)
        {
            ColumnPattern = pattern;
            IsSequenceProperty = isSequence;
        }
    }

    /* ---------------------------------------------------------------------------------------------- *
     * 설명  : - MVVM 모델에서 Model 역할
     *         - PropertyChange 를 구현 ( 다른 부분에서 하는것보다 구조가 쉬워짐 )
     * TO_DO : 
     * ---------------------------------------------------------------------------------------------- *
     *   일  자   | 개발자 | 작  업  내  용
     * ---------------------------------------------------------------------------------------------- *
     * 2026.11.24 |        | 초기개발
     * ---------------------------------------------------------------------------------------------- */
    public abstract class TBaseModel<T> : INotifyPropertyChanged where T : TBaseModel<T>, new()
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        // 값 비교와 이벤트 호출을 한 번에 처리하는 헬퍼 메서드
        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(field, value)) return false;

            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }

    [DbTable("tb_insp_data")]
    public class TModel_InspData : TBaseModel<TModel_InspData>
    {   
        private string _orderNo;
        [DbColumn("OrderNo", IsPrimaryKey = true)]
        [DisplayName("발주번호")]
        public string OrderNo
        {
            get => _orderNo;
            set => SetProperty(ref _orderNo, value);
        }

        private int _orderSeq;
        [DbColumn("OrderSeq", IsPrimaryKey = true)]
        [DisplayName("발주순번")]
        public int OrderSeq
        {
            get => _orderSeq;
            set => SetProperty(ref _orderSeq, value);
        }

        private string _procStat;
        [DbColumn("ProcStat")]
        [DisplayName("검사일자")]
        public string ProcStat
        {
            get => _procStat;
            set => SetProperty(ref _procStat, value);
        }

        private DateTime _testDate;
        [DbColumn("TestDate")]
        [DisplayName("검사일자")]
        public DateTime TestDate
        {
            get => _testDate;
            set => SetProperty(ref _testDate, value);
        }

        private string _cstCode;
        [DbColumn("CustCode")]
        [DisplayName("거래처코드")]
        public string CustCode
        {
            get => _cstCode;
            set => SetProperty(ref _cstCode, value);
        }

        private string _itemNo;
        [DbColumn("ItemNo")]
        [DisplayName("ItemNo")]
        public string ItemNo
        {
            get => _itemNo;
            set => SetProperty(ref _itemNo, value);
        }

        private string _plant;
        [DbColumn("Plant")]
        [DisplayName("Plant")]
        public string Plant
        {
            get => _plant;
            set => SetProperty(ref _plant, value);
        }

        private string _inlet;
        [DbColumn("Inlet")]
        [DisplayName("Inlet")]
        public string Inlet
        {
            get => _inlet;
            set => SetProperty(ref _inlet, value);
        }

        private string _outlet;
        [DbColumn("Outlet")]
        [DisplayName("Outlet")]
        public string Outlet
        {
            get => _outlet;
            set => SetProperty(ref _outlet, value);
        }

        private string _capct;
        [DbColumn("Capct")]
        [DisplayName("Capct")]
        public string Capct
        {
            get => _capct;
            set => SetProperty(ref _capct, value);
        }

        private string _capctUnit;
        [DbColumn("CapctUnit")]
        [DisplayName("CapctUnit")]
        public string CapctUnit
        {
            get => _capctUnit;
            set => SetProperty(ref _capctUnit, value);
        }

        private string _fluid;
        [DbColumn("Fluid")]
        [DisplayName("Fluid")]
        public string Fluid
        {
            get => _fluid;
            set => SetProperty(ref _fluid, value);
        }

        private string _maker;
        [DbColumn("Maker")]
        [DisplayName("Maker")]
        public string Maker
        {
            get => _maker;
            set => SetProperty(ref _maker, value);
        }

        private string _model;
        [DbColumn("Model")]
        [DisplayName("Model")]
        public string Model
        {
            get => _model;
            set => SetProperty(ref _model, value);
        }

        private string _serial;
        [DbColumn("Serial")]
        [DisplayName("Serial")]
        public string Serial
        {
            get => _serial;
            set => SetProperty(ref _serial, value);
        }

        private string _type;
        [DbColumn("Type")]
        [DisplayName("Type")]
        public string Type
        {
            get => _type;
            set => SetProperty(ref _type, value);
        }

        private string _setPress;
        [DbColumn("SetPress")]
        [DisplayName("SetPress")]
        public string SetPress
        {
            get => _setPress;
            set => SetProperty(ref _setPress, value);
        }

        private string _backPress;
        [DbColumn("BackPress")]
        [DisplayName("BackPress")]
        public string BackPress
        {
            get => _backPress;
            set => SetProperty(ref _backPress, value);
        }

        private string _testPress;
        [DbColumn("TestPress")]
        [DisplayName("TestPress")]
        public string TestPress
        {
            get => _testPress;
            set => SetProperty(ref _testPress, value);
        }

        private string _cds;
        [DbColumn("CDS")]
        [DisplayName("CDS")]
        public string CDS
        {
            get => _cds;
            set => SetProperty(ref _cds, value);
        }

        private string _unit;
        [DbColumn("Unit")]
        [DisplayName("Unit")]
        public string Unit
        {
            get => _unit;
            set => SetProperty(ref _unit, value);
        }

        private string _reglt;
        [DbColumn("Reglt")]
        [DisplayName("Reglt")]
        public string Reglt
        {
            get => _reglt;
            set => SetProperty(ref _reglt, value);
        }

        private string _testFluid;
        [DbColumn("TestFluid")]
        [DisplayName("TestFluid")]
        public string TestFluid
        {
            get => _testFluid;
            set => SetProperty(ref _testFluid, value);
        }

        private string _testRslt;
        [DbColumn("TestRslt")]
        [DisplayName("TestRslt")]
        public string TestRslt
        {
            get => _testRslt;
            set => SetProperty(ref _testRslt, value);
        }

        private string _bodyMatl;
        [DbColumn("BodyMatl")]
        [DisplayName("BodyMatl")]
        public string BodyMatl
        {
            get => _bodyMatl;
            set => SetProperty(ref _bodyMatl, value);
        }

        private string _discMatl;
        [DbColumn("DiscMatl")]
        [DisplayName("DiscMatl")]
        public string DiscMatl
        {
            get => _discMatl;
            set => SetProperty(ref _discMatl, value);
        }

        private string _poppPress1;
        [DbColumn("PoppPress1")]
        [DisplayName("PoppPress1")]
        public string PoppPress1
        {
            get => _poppPress1;
            set => SetProperty(ref _poppPress1, value);
        }

        private string _closPress1;
        [DbColumn("ClosPress1")]
        [DisplayName("ClosPress1")]
        public string ClosPress1
        {
            get => _closPress1;
            set => SetProperty(ref _closPress1, value);
        }

        private string _poppPress2;
        [DbColumn("PoppPress2")]
        [DisplayName("PoppPress2")]
        public string PoppPress2
        {
            get => _poppPress2;
            set => SetProperty(ref _poppPress2, value);
        }

        private string _closPress2;
        [DbColumn("ClosPress2")]
        [DisplayName("ClosPress2")]
        public string ClosPress2
        {
            get => _closPress2;
            set => SetProperty(ref _closPress2, value);
        }

        private string _chkCap;
        [DbColumn("ChkCap")]
        [DisplayName("ChkCap")]
        public string ChkCap
        {
            get => _chkCap;
            set => SetProperty(ref _chkCap, value);
        }

        private string _chkBonnet;
        [DbColumn("ChkBonnet")]
        [DisplayName("ChkBonnet")]
        public string ChkBonnet
        {
            get => _chkBonnet;
            set => SetProperty(ref _chkBonnet, value);
        }

        private string _chkBody;
        [DbColumn("ChkBody")]
        [DisplayName("ChkBody")]
        public string ChkBody
        {
            get => _chkBody;
            set => SetProperty(ref _chkBody, value);
        }

        private string _chkNozz;
        [DbColumn("ChkNozz")]
        [DisplayName("ChkNozz")]
        public string ChkNozz
        {
            get => _chkNozz;
            set => SetProperty(ref _chkNozz, value);
        }

        private string _chkNozzSeat;
        [DbColumn("ChkNozzSeat")]
        [DisplayName("ChkNozzSeat")]
        public string ChkNozzSeat
        {
            get => _chkNozzSeat;
            set => SetProperty(ref _chkNozzSeat, value);
        }

        private string _chkDisc;
        [DbColumn("ChkDisc")]
        [DisplayName("ChkDisc")]
        public string ChkDisc
        {
            get => _chkDisc;
            set => SetProperty(ref _chkDisc, value);
        }

        private string _chkDiscSeat;
        [DbColumn("ChkDiscSeat")]
        [DisplayName("ChkDiscSeat")]
        public string ChkDiscSeat
        {
            get => _chkDiscSeat;
            set => SetProperty(ref _chkDiscSeat, value);
        }

        private string _chkBellows;
        [DbColumn("ChkBellows")]
        [DisplayName("ChkBellows")]
        public string ChkBellows
        {
            get => _chkBellows;
            set => SetProperty(ref _chkBellows, value);
        }

        private string _chkSpring;
        [DbColumn("ChkSpring")]
        [DisplayName("ChkSpring")]
        public string ChkSpring
        {
            get => _chkSpring;
            set => SetProperty(ref _chkSpring, value);
        }

        private string _chkSpindle;
        [DbColumn("ChkSpindle")]
        [DisplayName("ChkSpindle")]
        public string ChkSpindle
        {
            get => _chkSpindle;
            set => SetProperty(ref _chkSpindle, value);
        }

        private string _chkLowRing;
        [DbColumn("ChkLowRing")]
        [DisplayName("ChkLowRing")]
        public string ChkLowRing
        {
            get => _chkLowRing;
            set => SetProperty(ref _chkLowRing, value);
        }

        private string _chkUppRing;
        [DbColumn("ChkUppRing")]
        [DisplayName("DatChkUppRinga15")]
        public string ChkUppRing
        {
            get => _chkUppRing;
            set => SetProperty(ref _chkUppRing, value);
        }

        private string _inspRemk;
        [DbColumn("InspRemk")]
        [DisplayName("InspRemk")]
        public string InspRemk
        {
            get => _inspRemk;
            set => SetProperty(ref _inspRemk, value);
        }

        private string _pressVals1;
        [DbColumn("PressVals1")]
        [DisplayName("PressVals1")]
        public string PressVals1
        {
            get => _pressVals1;
            set => SetProperty(ref _pressVals1, value);
        }

        private string _pressVals2;
        [DbColumn("PressVals2")]
        [DisplayName("PressVals2")]
        public string PressVals2
        {
            get => _pressVals2;
            set => SetProperty(ref _pressVals2, value);
        }

        private byte[] _presChtImg;
        [DbColumn("PressChtImg")]
        [DisplayName("PressChtImg")]
        public byte[] PresChtImg
        {
            get => _presChtImg;
            set => SetProperty(ref _presChtImg, value);
        }

        //private string _measValues1;
        public List<double> PresValues1 = new List<double>();
        public List<double> PresValues2 = new List<double>();
        //{
        //    get => _measValues1;
        //    set => SetProperty(ref _chkLowRing, value);
        //}

    } // class TModel_InspData

    //[DbTable("tb_insp_data")]
    //public class TModel_Scrap : TBaseModel<TModel_Scrap>
    //{
    //    [DbColumn("sScrapno_001")]
    //    public string ScrapNo { get; set; }

    //    [DbColumn("iPuttotX_002")]
    //    public int Total { get; set; }

    //    [DbColumn("sContent_411")]
    //    public string Content { get; set; }

    //    //[DbRepeatGroup(1, 2)]
    //    public BindingList<TModel_Charge> Charges { get; } = new BindingList<TModel_Charge>();
    //}

    //public class TModel_Charge : TBaseModel<TModel_Charge>
    //{
    //    public int ChargeNo { get; set; }
    //}

    [DbTable("te_scpatrg")]
    public class TModel_Scpatrg : TBaseModel<TModel_Scpatrg>
    {
        private string _sScrapno_001;
        [DbColumn("sScrapno_001")]
        [DisplayName("sScrapno_001")]
        public string sScrapno_001
        {
            get => _sScrapno_001;
            set => SetProperty(ref _sScrapno_001, value);
        }

        private int? _iPuttotX_002;
        [DbColumn("iPuttotX_002")]
        [DisplayName("iPuttotX_002")]
        public int? iPuttotX_002
        {
            get => _iPuttotX_002;
            set => SetProperty(ref _iPuttotX_002, value);
        }

        private int? _iPuttot1_003;
        [DbColumn("iPuttot1_003")]
        [DisplayName("iPuttot1_003")]
        public int? iPuttot1_003
        {
            get => _iPuttot1_003;
            set => SetProperty(ref _iPuttot1_003, value);
        }

        private string _sScNo101_004;
        [DbColumn("sScNo101_004")]
        [DisplayName("sScNo101_004")]
        public string sScNo101_004
        {
            get => _sScNo101_004;
            set => SetProperty(ref _sScNo101_004, value);
        }

        private string _sScDv101_005;
        [DbColumn("sScDv101_005")]
        [DisplayName("sScDv101_005")]
        public string sScDv101_005
        {
            get => _sScDv101_005;
            set => SetProperty(ref _sScDv101_005, value);
        }

        private int? _iCode101_006;
        [DbColumn("iCode101_006")]
        [DisplayName("iCode101_006")]
        public int? iCode101_006
        {
            get => _iCode101_006;
            set => SetProperty(ref _iCode101_006, value);
        }

        private string _sName101_007;
        [DbColumn("sName101_007")]
        [DisplayName("sName101_007")]
        public string sName101_007
        {
            get => _sName101_007;
            set => SetProperty(ref _sName101_007, value);
        }

        private int? _iPlan101_008;
        [DbColumn("iPlan101_008")]
        [DisplayName("iPlan101_008")]
        public int? iPlan101_008
        {
            get => _iPlan101_008;
            set => SetProperty(ref _iPlan101_008, value);
        }

        private string _sScNo102_009;
        [DbColumn("sScNo102_009")]
        [DisplayName("sScNo102_009")]
        public string sScNo102_009
        {
            get => _sScNo102_009;
            set => SetProperty(ref _sScNo102_009, value);
        }

        private string _sScDv102_010;
        [DbColumn("sScDv102_010")]
        [DisplayName("sScDv102_010")]
        public string sScDv102_010
        {
            get => _sScDv102_010;
            set => SetProperty(ref _sScDv102_010, value);
        }

        private int? _iCode102_011;
        [DbColumn("iCode102_011")]
        [DisplayName("iCode102_011")]
        public int? iCode102_011
        {
            get => _iCode102_011;
            set => SetProperty(ref _iCode102_011, value);
        }

        private string _sName102_012;
        [DbColumn("sName102_012")]
        [DisplayName("sName102_012")]
        public string sName102_012
        {
            get => _sName102_012;
            set => SetProperty(ref _sName102_012, value);
        }

        private int? _iPlan102_013;
        [DbColumn("iPlan102_013")]
        [DisplayName("iPlan102_013")]
        public int? iPlan102_013
        {
            get => _iPlan102_013;
            set => SetProperty(ref _iPlan102_013, value);
        }

        private string _sScNo103_014;
        [DbColumn("sScNo103_014")]
        [DisplayName("sScNo103_014")]
        public string sScNo103_014
        {
            get => _sScNo103_014;
            set => SetProperty(ref _sScNo103_014, value);
        }

        private string _sScDv103_015;
        [DbColumn("sScDv103_015")]
        [DisplayName("sScDv103_015")]
        public string sScDv103_015
        {
            get => _sScDv103_015;
            set => SetProperty(ref _sScDv103_015, value);
        }

        private int? _iCode103_016;
        [DbColumn("iCode103_016")]
        [DisplayName("iCode103_016")]
        public int? iCode103_016
        {
            get => _iCode103_016;
            set => SetProperty(ref _iCode103_016, value);
        }

        private string _sName103_017;
        [DbColumn("sName103_017")]
        [DisplayName("sName103_017")]
        public string sName103_017
        {
            get => _sName103_017;
            set => SetProperty(ref _sName103_017, value);
        }

        private int? _iPlan103_018;
        [DbColumn("iPlan103_018")]
        [DisplayName("iPlan103_018")]
        public int? iPlan103_018
        {
            get => _iPlan103_018;
            set => SetProperty(ref _iPlan103_018, value);
        }

        private string _sScNo104_019;
        [DbColumn("sScNo104_019")]
        [DisplayName("sScNo104_019")]
        public string sScNo104_019
        {
            get => _sScNo104_019;
            set => SetProperty(ref _sScNo104_019, value);
        }

        private string _sScDv104_020;
        [DbColumn("sScDv104_020")]
        [DisplayName("sScDv104_020")]
        public string sScDv104_020
        {
            get => _sScDv104_020;
            set => SetProperty(ref _sScDv104_020, value);
        }

        private int? _iCode104_021;
        [DbColumn("iCode104_021")]
        [DisplayName("iCode104_021")]
        public int? iCode104_021
        {
            get => _iCode104_021;
            set => SetProperty(ref _iCode104_021, value);
        }

        private string _sName104_022;
        [DbColumn("sName104_022")]
        [DisplayName("sName104_022")]
        public string sName104_022
        {
            get => _sName104_022;
            set => SetProperty(ref _sName104_022, value);
        }

        private int? _iPlan104_023;
        [DbColumn("iPlan104_023")]
        [DisplayName("iPlan104_023")]
        public int? iPlan104_023
        {
            get => _iPlan104_023;
            set => SetProperty(ref _iPlan104_023, value);
        }

        private string _sScNo105_024;
        [DbColumn("sScNo105_024")]
        [DisplayName("sScNo105_024")]
        public string sScNo105_024
        {
            get => _sScNo105_024;
            set => SetProperty(ref _sScNo105_024, value);
        }

        private string _sScDv105_025;
        [DbColumn("sScDv105_025")]
        [DisplayName("sScDv105_025")]
        public string sScDv105_025
        {
            get => _sScDv105_025;
            set => SetProperty(ref _sScDv105_025, value);
        }

        private int? _iCode105_026;
        [DbColumn("iCode105_026")]
        [DisplayName("iCode105_026")]
        public int? iCode105_026
        {
            get => _iCode105_026;
            set => SetProperty(ref _iCode105_026, value);
        }

        private string _sName105_027;
        [DbColumn("sName105_027")]
        [DisplayName("sName105_027")]
        public string sName105_027
        {
            get => _sName105_027;
            set => SetProperty(ref _sName105_027, value);
        }

        private int? _iPlan105_028;
        [DbColumn("iPlan105_028")]
        [DisplayName("iPlan105_028")]
        public int? iPlan105_028
        {
            get => _iPlan105_028;
            set => SetProperty(ref _iPlan105_028, value);
        }

        private string _sScNo106_029;
        [DbColumn("sScNo106_029")]
        [DisplayName("sScNo106_029")]
        public string sScNo106_029
        {
            get => _sScNo106_029;
            set => SetProperty(ref _sScNo106_029, value);
        }

        private string _sScDv106_030;
        [DbColumn("sScDv106_030")]
        [DisplayName("sScDv106_030")]
        public string sScDv106_030
        {
            get => _sScDv106_030;
            set => SetProperty(ref _sScDv106_030, value);
        }

        private int? _iCode106_031;
        [DbColumn("iCode106_031")]
        [DisplayName("iCode106_031")]
        public int? iCode106_031
        {
            get => _iCode106_031;
            set => SetProperty(ref _iCode106_031, value);
        }

        private string _sName106_032;
        [DbColumn("sName106_032")]
        [DisplayName("sName106_032")]
        public string sName106_032
        {
            get => _sName106_032;
            set => SetProperty(ref _sName106_032, value);
        }

        private int? _iPlan106_033;
        [DbColumn("iPlan106_033")]
        [DisplayName("iPlan106_033")]
        public int? iPlan106_033
        {
            get => _iPlan106_033;
            set => SetProperty(ref _iPlan106_033, value);
        }

        private string _sScNo107_034;
        [DbColumn("sScNo107_034")]
        [DisplayName("sScNo107_034")]
        public string sScNo107_034
        {
            get => _sScNo107_034;
            set => SetProperty(ref _sScNo107_034, value);
        }

        private string _sScDv107_035;
        [DbColumn("sScDv107_035")]
        [DisplayName("sScDv107_035")]
        public string sScDv107_035
        {
            get => _sScDv107_035;
            set => SetProperty(ref _sScDv107_035, value);
        }

        private int? _iCode107_036;
        [DbColumn("iCode107_036")]
        [DisplayName("iCode107_036")]
        public int? iCode107_036
        {
            get => _iCode107_036;
            set => SetProperty(ref _iCode107_036, value);
        }

        private string _sName107_037;
        [DbColumn("sName107_037")]
        [DisplayName("sName107_037")]
        public string sName107_037
        {
            get => _sName107_037;
            set => SetProperty(ref _sName107_037, value);
        }

        private int? _iPlan107_038;
        [DbColumn("iPlan107_038")]
        [DisplayName("iPlan107_038")]
        public int? iPlan107_038
        {
            get => _iPlan107_038;
            set => SetProperty(ref _iPlan107_038, value);
        }

        private string _sScNo108_039;
        [DbColumn("sScNo108_039")]
        [DisplayName("sScNo108_039")]
        public string sScNo108_039
        {
            get => _sScNo108_039;
            set => SetProperty(ref _sScNo108_039, value);
        }

        private string _sScDv108_040;
        [DbColumn("sScDv108_040")]
        [DisplayName("sScDv108_040")]
        public string sScDv108_040
        {
            get => _sScDv108_040;
            set => SetProperty(ref _sScDv108_040, value);
        }

        private int? _iCode108_041;
        [DbColumn("iCode108_041")]
        [DisplayName("iCode108_041")]
        public int? iCode108_041
        {
            get => _iCode108_041;
            set => SetProperty(ref _iCode108_041, value);
        }

        private string _sName108_042;
        [DbColumn("sName108_042")]
        [DisplayName("sName108_042")]
        public string sName108_042
        {
            get => _sName108_042;
            set => SetProperty(ref _sName108_042, value);
        }

        private int? _iPlan108_043;
        [DbColumn("iPlan108_043")]
        [DisplayName("iPlan108_043")]
        public int? iPlan108_043
        {
            get => _iPlan108_043;
            set => SetProperty(ref _iPlan108_043, value);
        }

        private string _sScNo109_044;
        [DbColumn("sScNo109_044")]
        [DisplayName("sScNo109_044")]
        public string sScNo109_044
        {
            get => _sScNo109_044;
            set => SetProperty(ref _sScNo109_044, value);
        }

        private string _sScDv109_045;
        [DbColumn("sScDv109_045")]
        [DisplayName("sScDv109_045")]
        public string sScDv109_045
        {
            get => _sScDv109_045;
            set => SetProperty(ref _sScDv109_045, value);
        }

        private int? _iCode109_046;
        [DbColumn("iCode109_046")]
        [DisplayName("iCode109_046")]
        public int? iCode109_046
        {
            get => _iCode109_046;
            set => SetProperty(ref _iCode109_046, value);
        }

        private string _sName109_047;
        [DbColumn("sName109_047")]
        [DisplayName("sName109_047")]
        public string sName109_047
        {
            get => _sName109_047;
            set => SetProperty(ref _sName109_047, value);
        }

        private int? _iPlan109_048;
        [DbColumn("iPlan109_048")]
        [DisplayName("iPlan109_048")]
        public int? iPlan109_048
        {
            get => _iPlan109_048;
            set => SetProperty(ref _iPlan109_048, value);
        }

        private string _sScNo110_049;
        [DbColumn("sScNo110_049")]
        [DisplayName("sScNo110_049")]
        public string sScNo110_049
        {
            get => _sScNo110_049;
            set => SetProperty(ref _sScNo110_049, value);
        }

        private string _sScDv110_050;
        [DbColumn("sScDv110_050")]
        [DisplayName("sScDv110_050")]
        public string sScDv110_050
        {
            get => _sScDv110_050;
            set => SetProperty(ref _sScDv110_050, value);
        }

        private int? _iCode110_051;
        [DbColumn("iCode110_051")]
        [DisplayName("iCode110_051")]
        public int? iCode110_051
        {
            get => _iCode110_051;
            set => SetProperty(ref _iCode110_051, value);
        }

        private string _sName110_052;
        [DbColumn("sName110_052")]
        [DisplayName("sName110_052")]
        public string sName110_052
        {
            get => _sName110_052;
            set => SetProperty(ref _sName110_052, value);
        }

        private int? _iPlan110_053;
        [DbColumn("iPlan110_053")]
        [DisplayName("iPlan110_053")]
        public int? iPlan110_053
        {
            get => _iPlan110_053;
            set => SetProperty(ref _iPlan110_053, value);
        }

        private string _sScNo111_054;
        [DbColumn("sScNo111_054")]
        [DisplayName("sScNo111_054")]
        public string sScNo111_054
        {
            get => _sScNo111_054;
            set => SetProperty(ref _sScNo111_054, value);
        }

        private string _sScDv111_055;
        [DbColumn("sScDv111_055")]
        [DisplayName("sScDv111_055")]
        public string sScDv111_055
        {
            get => _sScDv111_055;
            set => SetProperty(ref _sScDv111_055, value);
        }

        private int? _iCode111_056;
        [DbColumn("iCode111_056")]
        [DisplayName("iCode111_056")]
        public int? iCode111_056
        {
            get => _iCode111_056;
            set => SetProperty(ref _iCode111_056, value);
        }

        private string _sName111_057;
        [DbColumn("sName111_057")]
        [DisplayName("sName111_057")]
        public string sName111_057
        {
            get => _sName111_057;
            set => SetProperty(ref _sName111_057, value);
        }

        private int? _iPlan111_058;
        [DbColumn("iPlan111_058")]
        [DisplayName("iPlan111_058")]
        public int? iPlan111_058
        {
            get => _iPlan111_058;
            set => SetProperty(ref _iPlan111_058, value);
        }

        private string _sScNo112_059;
        [DbColumn("sScNo112_059")]
        [DisplayName("sScNo112_059")]
        public string sScNo112_059
        {
            get => _sScNo112_059;
            set => SetProperty(ref _sScNo112_059, value);
        }

        private string _sScDv112_060;
        [DbColumn("sScDv112_060")]
        [DisplayName("sScDv112_060")]
        public string sScDv112_060
        {
            get => _sScDv112_060;
            set => SetProperty(ref _sScDv112_060, value);
        }

        private int? _iCode112_061;
        [DbColumn("iCode112_061")]
        [DisplayName("iCode112_061")]
        public int? iCode112_061
        {
            get => _iCode112_061;
            set => SetProperty(ref _iCode112_061, value);
        }

        private string _sName112_062;
        [DbColumn("sName112_062")]
        [DisplayName("sName112_062")]
        public string sName112_062
        {
            get => _sName112_062;
            set => SetProperty(ref _sName112_062, value);
        }

        private int? _iPlan112_063;
        [DbColumn("iPlan112_063")]
        [DisplayName("iPlan112_063")]
        public int? iPlan112_063
        {
            get => _iPlan112_063;
            set => SetProperty(ref _iPlan112_063, value);
        }

        private string _sScNo113_064;
        [DbColumn("sScNo113_064")]
        [DisplayName("sScNo113_064")]
        public string sScNo113_064
        {
            get => _sScNo113_064;
            set => SetProperty(ref _sScNo113_064, value);
        }

        private string _sScDv113_065;
        [DbColumn("sScDv113_065")]
        [DisplayName("sScDv113_065")]
        public string sScDv113_065
        {
            get => _sScDv113_065;
            set => SetProperty(ref _sScDv113_065, value);
        }

        private int? _iCode113_066;
        [DbColumn("iCode113_066")]
        [DisplayName("iCode113_066")]
        public int? iCode113_066
        {
            get => _iCode113_066;
            set => SetProperty(ref _iCode113_066, value);
        }

        private string _sName113_067;
        [DbColumn("sName113_067")]
        [DisplayName("sName113_067")]
        public string sName113_067
        {
            get => _sName113_067;
            set => SetProperty(ref _sName113_067, value);
        }

        private int? _iPlan113_068;
        [DbColumn("iPlan113_068")]
        [DisplayName("iPlan113_068")]
        public int? iPlan113_068
        {
            get => _iPlan113_068;
            set => SetProperty(ref _iPlan113_068, value);
        }

        private string _sScNo114_069;
        [DbColumn("sScNo114_069")]
        [DisplayName("sScNo114_069")]
        public string sScNo114_069
        {
            get => _sScNo114_069;
            set => SetProperty(ref _sScNo114_069, value);
        }

        private string _sScDv114_070;
        [DbColumn("sScDv114_070")]
        [DisplayName("sScDv114_070")]
        public string sScDv114_070
        {
            get => _sScDv114_070;
            set => SetProperty(ref _sScDv114_070, value);
        }

        private int? _iCode114_071;
        [DbColumn("iCode114_071")]
        [DisplayName("iCode114_071")]
        public int? iCode114_071
        {
            get => _iCode114_071;
            set => SetProperty(ref _iCode114_071, value);
        }

        private string _sName114_072;
        [DbColumn("sName114_072")]
        [DisplayName("sName114_072")]
        public string sName114_072
        {
            get => _sName114_072;
            set => SetProperty(ref _sName114_072, value);
        }

        private int? _iPlan114_073;
        [DbColumn("iPlan114_073")]
        [DisplayName("iPlan114_073")]
        public int? iPlan114_073
        {
            get => _iPlan114_073;
            set => SetProperty(ref _iPlan114_073, value);
        }

        private string _sScNo115_074;
        [DbColumn("sScNo115_074")]
        [DisplayName("sScNo115_074")]
        public string sScNo115_074
        {
            get => _sScNo115_074;
            set => SetProperty(ref _sScNo115_074, value);
        }

        private string _sScDv115_075;
        [DbColumn("sScDv115_075")]
        [DisplayName("sScDv115_075")]
        public string sScDv115_075
        {
            get => _sScDv115_075;
            set => SetProperty(ref _sScDv115_075, value);
        }

        private int? _iCode115_076;
        [DbColumn("iCode115_076")]
        [DisplayName("iCode115_076")]
        public int? iCode115_076
        {
            get => _iCode115_076;
            set => SetProperty(ref _iCode115_076, value);
        }

        private string _sName115_077;
        [DbColumn("sName115_077")]
        [DisplayName("sName115_077")]
        public string sName115_077
        {
            get => _sName115_077;
            set => SetProperty(ref _sName115_077, value);
        }

        private int? _iPlan115_078;
        [DbColumn("iPlan115_078")]
        [DisplayName("iPlan115_078")]
        public int? iPlan115_078
        {
            get => _iPlan115_078;
            set => SetProperty(ref _iPlan115_078, value);
        }

        private string _sScNo116_079;
        [DbColumn("sScNo116_079")]
        [DisplayName("sScNo116_079")]
        public string sScNo116_079
        {
            get => _sScNo116_079;
            set => SetProperty(ref _sScNo116_079, value);
        }

        private string _sScDv116_080;
        [DbColumn("sScDv116_080")]
        [DisplayName("sScDv116_080")]
        public string sScDv116_080
        {
            get => _sScDv116_080;
            set => SetProperty(ref _sScDv116_080, value);
        }

        private int? _iCode116_081;
        [DbColumn("iCode116_081")]
        [DisplayName("iCode116_081")]
        public int? iCode116_081
        {
            get => _iCode116_081;
            set => SetProperty(ref _iCode116_081, value);
        }

        private string _sName116_082;
        [DbColumn("sName116_082")]
        [DisplayName("sName116_082")]
        public string sName116_082
        {
            get => _sName116_082;
            set => SetProperty(ref _sName116_082, value);
        }

        private int? _iPlan116_083;
        [DbColumn("iPlan116_083")]
        [DisplayName("iPlan116_083")]
        public int? iPlan116_083
        {
            get => _iPlan116_083;
            set => SetProperty(ref _iPlan116_083, value);
        }

        private string _sScNo117_084;
        [DbColumn("sScNo117_084")]
        [DisplayName("sScNo117_084")]
        public string sScNo117_084
        {
            get => _sScNo117_084;
            set => SetProperty(ref _sScNo117_084, value);
        }

        private string _sScDv117_085;
        [DbColumn("sScDv117_085")]
        [DisplayName("sScDv117_085")]
        public string sScDv117_085
        {
            get => _sScDv117_085;
            set => SetProperty(ref _sScDv117_085, value);
        }

        private int? _iCode117_086;
        [DbColumn("iCode117_086")]
        [DisplayName("iCode117_086")]
        public int? iCode117_086
        {
            get => _iCode117_086;
            set => SetProperty(ref _iCode117_086, value);
        }

        private string _sName117_087;
        [DbColumn("sName117_087")]
        [DisplayName("sName117_087")]
        public string sName117_087
        {
            get => _sName117_087;
            set => SetProperty(ref _sName117_087, value);
        }

        private int? _iPlan117_088;
        [DbColumn("iPlan117_088")]
        [DisplayName("iPlan117_088")]
        public int? iPlan117_088
        {
            get => _iPlan117_088;
            set => SetProperty(ref _iPlan117_088, value);
        }

        private string _sScNo118_089;
        [DbColumn("sScNo118_089")]
        [DisplayName("sScNo118_089")]
        public string sScNo118_089
        {
            get => _sScNo118_089;
            set => SetProperty(ref _sScNo118_089, value);
        }

        private string _sScDv118_090;
        [DbColumn("sScDv118_090")]
        [DisplayName("sScDv118_090")]
        public string sScDv118_090
        {
            get => _sScDv118_090;
            set => SetProperty(ref _sScDv118_090, value);
        }

        private int? _iCode118_091;
        [DbColumn("iCode118_091")]
        [DisplayName("iCode118_091")]
        public int? iCode118_091
        {
            get => _iCode118_091;
            set => SetProperty(ref _iCode118_091, value);
        }

        private string _sName118_092;
        [DbColumn("sName118_092")]
        [DisplayName("sName118_092")]
        public string sName118_092
        {
            get => _sName118_092;
            set => SetProperty(ref _sName118_092, value);
        }

        private int? _iPlan118_093;
        [DbColumn("iPlan118_093")]
        [DisplayName("iPlan118_093")]
        public int? iPlan118_093
        {
            get => _iPlan118_093;
            set => SetProperty(ref _iPlan118_093, value);
        }

        private string _sScNo119_094;
        [DbColumn("sScNo119_094")]
        [DisplayName("sScNo119_094")]
        public string sScNo119_094
        {
            get => _sScNo119_094;
            set => SetProperty(ref _sScNo119_094, value);
        }

        private string _sScDv119_095;
        [DbColumn("sScDv119_095")]
        [DisplayName("sScDv119_095")]
        public string sScDv119_095
        {
            get => _sScDv119_095;
            set => SetProperty(ref _sScDv119_095, value);
        }

        private int? _iCode119_096;
        [DbColumn("iCode119_096")]
        [DisplayName("iCode119_096")]
        public int? iCode119_096
        {
            get => _iCode119_096;
            set => SetProperty(ref _iCode119_096, value);
        }

        private string _sName119_097;
        [DbColumn("sName119_097")]
        [DisplayName("sName119_097")]
        public string sName119_097
        {
            get => _sName119_097;
            set => SetProperty(ref _sName119_097, value);
        }

        private int? _iPlan119_098;
        [DbColumn("iPlan119_098")]
        [DisplayName("iPlan119_098")]
        public int? iPlan119_098
        {
            get => _iPlan119_098;
            set => SetProperty(ref _iPlan119_098, value);
        }

        private string _sScNo120_099;
        [DbColumn("sScNo120_099")]
        [DisplayName("sScNo120_099")]
        public string sScNo120_099
        {
            get => _sScNo120_099;
            set => SetProperty(ref _sScNo120_099, value);
        }

        private string _sScDv120_100;
        [DbColumn("sScDv120_100")]
        [DisplayName("sScDv120_100")]
        public string sScDv120_100
        {
            get => _sScDv120_100;
            set => SetProperty(ref _sScDv120_100, value);
        }

        private int? _iCode120_101;
        [DbColumn("iCode120_101")]
        [DisplayName("iCode120_101")]
        public int? iCode120_101
        {
            get => _iCode120_101;
            set => SetProperty(ref _iCode120_101, value);
        }

        private string _sName120_102;
        [DbColumn("sName120_102")]
        [DisplayName("sName120_102")]
        public string sName120_102
        {
            get => _sName120_102;
            set => SetProperty(ref _sName120_102, value);
        }

        private int? _iPlan120_103;
        [DbColumn("iPlan120_103")]
        [DisplayName("iPlan120_103")]
        public int? iPlan120_103
        {
            get => _iPlan120_103;
            set => SetProperty(ref _iPlan120_103, value);
        }

        private string _sScNo121_104;
        [DbColumn("sScNo121_104")]
        [DisplayName("sScNo121_104")]
        public string sScNo121_104
        {
            get => _sScNo121_104;
            set => SetProperty(ref _sScNo121_104, value);
        }

        private string _sScDv121_105;
        [DbColumn("sScDv121_105")]
        [DisplayName("sScDv121_105")]
        public string sScDv121_105
        {
            get => _sScDv121_105;
            set => SetProperty(ref _sScDv121_105, value);
        }

        private int? _iCode121_106;
        [DbColumn("iCode121_106")]
        [DisplayName("iCode121_106")]
        public int? iCode121_106
        {
            get => _iCode121_106;
            set => SetProperty(ref _iCode121_106, value);
        }

        private string _sName121_107;
        [DbColumn("sName121_107")]
        [DisplayName("sName121_107")]
        public string sName121_107
        {
            get => _sName121_107;
            set => SetProperty(ref _sName121_107, value);
        }

        private int? _iPlan121_108;
        [DbColumn("iPlan121_108")]
        [DisplayName("iPlan121_108")]
        public int? iPlan121_108
        {
            get => _iPlan121_108;
            set => SetProperty(ref _iPlan121_108, value);
        }

        private string _sScNo122_109;
        [DbColumn("sScNo122_109")]
        [DisplayName("sScNo122_109")]
        public string sScNo122_109
        {
            get => _sScNo122_109;
            set => SetProperty(ref _sScNo122_109, value);
        }

        private string _sScDv122_110;
        [DbColumn("sScDv122_110")]
        [DisplayName("sScDv122_110")]
        public string sScDv122_110
        {
            get => _sScDv122_110;
            set => SetProperty(ref _sScDv122_110, value);
        }

        private int? _iCode122_111;
        [DbColumn("iCode122_111")]
        [DisplayName("iCode122_111")]
        public int? iCode122_111
        {
            get => _iCode122_111;
            set => SetProperty(ref _iCode122_111, value);
        }

        private string _sName122_112;
        [DbColumn("sName122_112")]
        [DisplayName("sName122_112")]
        public string sName122_112
        {
            get => _sName122_112;
            set => SetProperty(ref _sName122_112, value);
        }

        private int? _iPlan122_113;
        [DbColumn("iPlan122_113")]
        [DisplayName("iPlan122_113")]
        public int? iPlan122_113
        {
            get => _iPlan122_113;
            set => SetProperty(ref _iPlan122_113, value);
        }

        private string _sScNo123_114;
        [DbColumn("sScNo123_114")]
        [DisplayName("sScNo123_114")]
        public string sScNo123_114
        {
            get => _sScNo123_114;
            set => SetProperty(ref _sScNo123_114, value);
        }

        private string _sScDv123_115;
        [DbColumn("sScDv123_115")]
        [DisplayName("sScDv123_115")]
        public string sScDv123_115
        {
            get => _sScDv123_115;
            set => SetProperty(ref _sScDv123_115, value);
        }

        private int? _iCode123_116;
        [DbColumn("iCode123_116")]
        [DisplayName("iCode123_116")]
        public int? iCode123_116
        {
            get => _iCode123_116;
            set => SetProperty(ref _iCode123_116, value);
        }

        private string _sName123_117;
        [DbColumn("sName123_117")]
        [DisplayName("sName123_117")]
        public string sName123_117
        {
            get => _sName123_117;
            set => SetProperty(ref _sName123_117, value);
        }

        private int? _iPlan123_118;
        [DbColumn("iPlan123_118")]
        [DisplayName("iPlan123_118")]
        public int? iPlan123_118
        {
            get => _iPlan123_118;
            set => SetProperty(ref _iPlan123_118, value);
        }

        private string _sScNo124_119;
        [DbColumn("sScNo124_119")]
        [DisplayName("sScNo124_119")]
        public string sScNo124_119
        {
            get => _sScNo124_119;
            set => SetProperty(ref _sScNo124_119, value);
        }

        private string _sScDv124_120;
        [DbColumn("sScDv124_120")]
        [DisplayName("sScDv124_120")]
        public string sScDv124_120
        {
            get => _sScDv124_120;
            set => SetProperty(ref _sScDv124_120, value);
        }

        private int? _iCode124_121;
        [DbColumn("iCode124_121")]
        [DisplayName("iCode124_121")]
        public int? iCode124_121
        {
            get => _iCode124_121;
            set => SetProperty(ref _iCode124_121, value);
        }

        private string _sName124_122;
        [DbColumn("sName124_122")]
        [DisplayName("sName124_122")]
        public string sName124_122
        {
            get => _sName124_122;
            set => SetProperty(ref _sName124_122, value);
        }

        private int? _iPlan124_123;
        [DbColumn("iPlan124_123")]
        [DisplayName("iPlan124_123")]
        public int? iPlan124_123
        {
            get => _iPlan124_123;
            set => SetProperty(ref _iPlan124_123, value);
        }

        private string _sScNo125_124;
        [DbColumn("sScNo125_124")]
        [DisplayName("sScNo125_124")]
        public string sScNo125_124
        {
            get => _sScNo125_124;
            set => SetProperty(ref _sScNo125_124, value);
        }

        private string _sScDv125_125;
        [DbColumn("sScDv125_125")]
        [DisplayName("sScDv125_125")]
        public string sScDv125_125
        {
            get => _sScDv125_125;
            set => SetProperty(ref _sScDv125_125, value);
        }

        private int? _iCode125_126;
        [DbColumn("iCode125_126")]
        [DisplayName("iCode125_126")]
        public int? iCode125_126
        {
            get => _iCode125_126;
            set => SetProperty(ref _iCode125_126, value);
        }

        private string _sName125_127;
        [DbColumn("sName125_127")]
        [DisplayName("sName125_127")]
        public string sName125_127
        {
            get => _sName125_127;
            set => SetProperty(ref _sName125_127, value);
        }

        private int? _iPlan125_128;
        [DbColumn("iPlan125_128")]
        [DisplayName("iPlan125_128")]
        public int? iPlan125_128
        {
            get => _iPlan125_128;
            set => SetProperty(ref _iPlan125_128, value);
        }

        private string _sScNo126_129;
        [DbColumn("sScNo126_129")]
        [DisplayName("sScNo126_129")]
        public string sScNo126_129
        {
            get => _sScNo126_129;
            set => SetProperty(ref _sScNo126_129, value);
        }

        private string _sScDv126_130;
        [DbColumn("sScDv126_130")]
        [DisplayName("sScDv126_130")]
        public string sScDv126_130
        {
            get => _sScDv126_130;
            set => SetProperty(ref _sScDv126_130, value);
        }

        private int? _iCode126_131;
        [DbColumn("iCode126_131")]
        [DisplayName("iCode126_131")]
        public int? iCode126_131
        {
            get => _iCode126_131;
            set => SetProperty(ref _iCode126_131, value);
        }

        private string _sName126_132;
        [DbColumn("sName126_132")]
        [DisplayName("sName126_132")]
        public string sName126_132
        {
            get => _sName126_132;
            set => SetProperty(ref _sName126_132, value);
        }

        private int? _iPlan126_133;
        [DbColumn("iPlan126_133")]
        [DisplayName("iPlan126_133")]
        public int? iPlan126_133
        {
            get => _iPlan126_133;
            set => SetProperty(ref _iPlan126_133, value);
        }

        private string _sScNo127_134;
        [DbColumn("sScNo127_134")]
        [DisplayName("sScNo127_134")]
        public string sScNo127_134
        {
            get => _sScNo127_134;
            set => SetProperty(ref _sScNo127_134, value);
        }

        private string _sScDv127_135;
        [DbColumn("sScDv127_135")]
        [DisplayName("sScDv127_135")]
        public string sScDv127_135
        {
            get => _sScDv127_135;
            set => SetProperty(ref _sScDv127_135, value);
        }

        private int? _iCode127_136;
        [DbColumn("iCode127_136")]
        [DisplayName("iCode127_136")]
        public int? iCode127_136
        {
            get => _iCode127_136;
            set => SetProperty(ref _iCode127_136, value);
        }

        private string _sName127_137;
        [DbColumn("sName127_137")]
        [DisplayName("sName127_137")]
        public string sName127_137
        {
            get => _sName127_137;
            set => SetProperty(ref _sName127_137, value);
        }

        private int? _iPlan127_138;
        [DbColumn("iPlan127_138")]
        [DisplayName("iPlan127_138")]
        public int? iPlan127_138
        {
            get => _iPlan127_138;
            set => SetProperty(ref _iPlan127_138, value);
        }

        private string _sScNo128_139;
        [DbColumn("sScNo128_139")]
        [DisplayName("sScNo128_139")]
        public string sScNo128_139
        {
            get => _sScNo128_139;
            set => SetProperty(ref _sScNo128_139, value);
        }

        private string _sScDv128_140;
        [DbColumn("sScDv128_140")]
        [DisplayName("sScDv128_140")]
        public string sScDv128_140
        {
            get => _sScDv128_140;
            set => SetProperty(ref _sScDv128_140, value);
        }

        private int? _iCode128_141;
        [DbColumn("iCode128_141")]
        [DisplayName("iCode128_141")]
        public int? iCode128_141
        {
            get => _iCode128_141;
            set => SetProperty(ref _iCode128_141, value);
        }

        private string _sName128_142;
        [DbColumn("sName128_142")]
        [DisplayName("sName128_142")]
        public string sName128_142
        {
            get => _sName128_142;
            set => SetProperty(ref _sName128_142, value);
        }

        private int? _iPlan128_143;
        [DbColumn("iPlan128_143")]
        [DisplayName("iPlan128_143")]
        public int? iPlan128_143
        {
            get => _iPlan128_143;
            set => SetProperty(ref _iPlan128_143, value);
        }

        private string _sScNo129_144;
        [DbColumn("sScNo129_144")]
        [DisplayName("sScNo129_144")]
        public string sScNo129_144
        {
            get => _sScNo129_144;
            set => SetProperty(ref _sScNo129_144, value);
        }

        private string _sScDv129_145;
        [DbColumn("sScDv129_145")]
        [DisplayName("sScDv129_145")]
        public string sScDv129_145
        {
            get => _sScDv129_145;
            set => SetProperty(ref _sScDv129_145, value);
        }

        private int? _iCode129_146;
        [DbColumn("iCode129_146")]
        [DisplayName("iCode129_146")]
        public int? iCode129_146
        {
            get => _iCode129_146;
            set => SetProperty(ref _iCode129_146, value);
        }

        private string _sName129_147;
        [DbColumn("sName129_147")]
        [DisplayName("sName129_147")]
        public string sName129_147
        {
            get => _sName129_147;
            set => SetProperty(ref _sName129_147, value);
        }

        private int? _iPlan129_148;
        [DbColumn("iPlan129_148")]
        [DisplayName("iPlan129_148")]
        public int? iPlan129_148
        {
            get => _iPlan129_148;
            set => SetProperty(ref _iPlan129_148, value);
        }

        private string _sScNo130_149;
        [DbColumn("sScNo130_149")]
        [DisplayName("sScNo130_149")]
        public string sScNo130_149
        {
            get => _sScNo130_149;
            set => SetProperty(ref _sScNo130_149, value);
        }

        private string _sScDv130_150;
        [DbColumn("sScDv130_150")]
        [DisplayName("sScDv130_150")]
        public string sScDv130_150
        {
            get => _sScDv130_150;
            set => SetProperty(ref _sScDv130_150, value);
        }

        private int? _iCode130_151;
        [DbColumn("iCode130_151")]
        [DisplayName("iCode130_151")]
        public int? iCode130_151
        {
            get => _iCode130_151;
            set => SetProperty(ref _iCode130_151, value);
        }

        private string _sName130_152;
        [DbColumn("sName130_152")]
        [DisplayName("sName130_152")]
        public string sName130_152
        {
            get => _sName130_152;
            set => SetProperty(ref _sName130_152, value);
        }

        private int? _iPlan130_153;
        [DbColumn("iPlan130_153")]
        [DisplayName("iPlan130_153")]
        public int? iPlan130_153
        {
            get => _iPlan130_153;
            set => SetProperty(ref _iPlan130_153, value);
        }

        private string _sScNo131_154;
        [DbColumn("sScNo131_154")]
        [DisplayName("sScNo131_154")]
        public string sScNo131_154
        {
            get => _sScNo131_154;
            set => SetProperty(ref _sScNo131_154, value);
        }

        private string _sScDv131_155;
        [DbColumn("sScDv131_155")]
        [DisplayName("sScDv131_155")]
        public string sScDv131_155
        {
            get => _sScDv131_155;
            set => SetProperty(ref _sScDv131_155, value);
        }

        private int? _iCode131_156;
        [DbColumn("iCode131_156")]
        [DisplayName("iCode131_156")]
        public int? iCode131_156
        {
            get => _iCode131_156;
            set => SetProperty(ref _iCode131_156, value);
        }

        private string _sName131_157;
        [DbColumn("sName131_157")]
        [DisplayName("sName131_157")]
        public string sName131_157
        {
            get => _sName131_157;
            set => SetProperty(ref _sName131_157, value);
        }

        private int? _iPlan131_158;
        [DbColumn("iPlan131_158")]
        [DisplayName("iPlan131_158")]
        public int? iPlan131_158
        {
            get => _iPlan131_158;
            set => SetProperty(ref _iPlan131_158, value);
        }

        private string _sScNo132_159;
        [DbColumn("sScNo132_159")]
        [DisplayName("sScNo132_159")]
        public string sScNo132_159
        {
            get => _sScNo132_159;
            set => SetProperty(ref _sScNo132_159, value);
        }

        private string _sScDv132_160;
        [DbColumn("sScDv132_160")]
        [DisplayName("sScDv132_160")]
        public string sScDv132_160
        {
            get => _sScDv132_160;
            set => SetProperty(ref _sScDv132_160, value);
        }

        private int? _iCode132_161;
        [DbColumn("iCode132_161")]
        [DisplayName("iCode132_161")]
        public int? iCode132_161
        {
            get => _iCode132_161;
            set => SetProperty(ref _iCode132_161, value);
        }

        private string _sName132_162;
        [DbColumn("sName132_162")]
        [DisplayName("sName132_162")]
        public string sName132_162
        {
            get => _sName132_162;
            set => SetProperty(ref _sName132_162, value);
        }

        private int? _iPlan132_163;
        [DbColumn("iPlan132_163")]
        [DisplayName("iPlan132_163")]
        public int? iPlan132_163
        {
            get => _iPlan132_163;
            set => SetProperty(ref _iPlan132_163, value);
        }

        private string _sScNo133_164;
        [DbColumn("sScNo133_164")]
        [DisplayName("sScNo133_164")]
        public string sScNo133_164
        {
            get => _sScNo133_164;
            set => SetProperty(ref _sScNo133_164, value);
        }

        private string _sScDv133_165;
        [DbColumn("sScDv133_165")]
        [DisplayName("sScDv133_165")]
        public string sScDv133_165
        {
            get => _sScDv133_165;
            set => SetProperty(ref _sScDv133_165, value);
        }

        private int? _iCode133_166;
        [DbColumn("iCode133_166")]
        [DisplayName("iCode133_166")]
        public int? iCode133_166
        {
            get => _iCode133_166;
            set => SetProperty(ref _iCode133_166, value);
        }

        private string _sName133_167;
        [DbColumn("sName133_167")]
        [DisplayName("sName133_167")]
        public string sName133_167
        {
            get => _sName133_167;
            set => SetProperty(ref _sName133_167, value);
        }

        private int? _iPlan133_168;
        [DbColumn("iPlan133_168")]
        [DisplayName("iPlan133_168")]
        public int? iPlan133_168
        {
            get => _iPlan133_168;
            set => SetProperty(ref _iPlan133_168, value);
        }

        private string _sScNo134_169;
        [DbColumn("sScNo134_169")]
        [DisplayName("sScNo134_169")]
        public string sScNo134_169
        {
            get => _sScNo134_169;
            set => SetProperty(ref _sScNo134_169, value);
        }

        private string _sScDv134_170;
        [DbColumn("sScDv134_170")]
        [DisplayName("sScDv134_170")]
        public string sScDv134_170
        {
            get => _sScDv134_170;
            set => SetProperty(ref _sScDv134_170, value);
        }

        private int? _iCode134_171;
        [DbColumn("iCode134_171")]
        [DisplayName("iCode134_171")]
        public int? iCode134_171
        {
            get => _iCode134_171;
            set => SetProperty(ref _iCode134_171, value);
        }

        private string _sName134_172;
        [DbColumn("sName134_172")]
        [DisplayName("sName134_172")]
        public string sName134_172
        {
            get => _sName134_172;
            set => SetProperty(ref _sName134_172, value);
        }

        private int? _iPlan134_173;
        [DbColumn("iPlan134_173")]
        [DisplayName("iPlan134_173")]
        public int? iPlan134_173
        {
            get => _iPlan134_173;
            set => SetProperty(ref _iPlan134_173, value);
        }

        private string _sScNo135_174;
        [DbColumn("sScNo135_174")]
        [DisplayName("sScNo135_174")]
        public string sScNo135_174
        {
            get => _sScNo135_174;
            set => SetProperty(ref _sScNo135_174, value);
        }

        private string _sScDv135_175;
        [DbColumn("sScDv135_175")]
        [DisplayName("sScDv135_175")]
        public string sScDv135_175
        {
            get => _sScDv135_175;
            set => SetProperty(ref _sScDv135_175, value);
        }

        private int? _iCode135_176;
        [DbColumn("iCode135_176")]
        [DisplayName("iCode135_176")]
        public int? iCode135_176
        {
            get => _iCode135_176;
            set => SetProperty(ref _iCode135_176, value);
        }

        private string _sName135_177;
        [DbColumn("sName135_177")]
        [DisplayName("sName135_177")]
        public string sName135_177
        {
            get => _sName135_177;
            set => SetProperty(ref _sName135_177, value);
        }

        private int? _iPlan135_178;
        [DbColumn("iPlan135_178")]
        [DisplayName("iPlan135_178")]
        public int? iPlan135_178
        {
            get => _iPlan135_178;
            set => SetProperty(ref _iPlan135_178, value);
        }

        private string _sScNo136_179;
        [DbColumn("sScNo136_179")]
        [DisplayName("sScNo136_179")]
        public string sScNo136_179
        {
            get => _sScNo136_179;
            set => SetProperty(ref _sScNo136_179, value);
        }

        private string _sScDv136_180;
        [DbColumn("sScDv136_180")]
        [DisplayName("sScDv136_180")]
        public string sScDv136_180
        {
            get => _sScDv136_180;
            set => SetProperty(ref _sScDv136_180, value);
        }

        private int? _iCode136_181;
        [DbColumn("iCode136_181")]
        [DisplayName("iCode136_181")]
        public int? iCode136_181
        {
            get => _iCode136_181;
            set => SetProperty(ref _iCode136_181, value);
        }

        private string _sName136_182;
        [DbColumn("sName136_182")]
        [DisplayName("sName136_182")]
        public string sName136_182
        {
            get => _sName136_182;
            set => SetProperty(ref _sName136_182, value);
        }

        private int? _iPlan136_183;
        [DbColumn("iPlan136_183")]
        [DisplayName("iPlan136_183")]
        public int? iPlan136_183
        {
            get => _iPlan136_183;
            set => SetProperty(ref _iPlan136_183, value);
        }

        private string _sScNo137_184;
        [DbColumn("sScNo137_184")]
        [DisplayName("sScNo137_184")]
        public string sScNo137_184
        {
            get => _sScNo137_184;
            set => SetProperty(ref _sScNo137_184, value);
        }

        private string _sScDv137_185;
        [DbColumn("sScDv137_185")]
        [DisplayName("sScDv137_185")]
        public string sScDv137_185
        {
            get => _sScDv137_185;
            set => SetProperty(ref _sScDv137_185, value);
        }

        private int? _iCode137_186;
        [DbColumn("iCode137_186")]
        [DisplayName("iCode137_186")]
        public int? iCode137_186
        {
            get => _iCode137_186;
            set => SetProperty(ref _iCode137_186, value);
        }

        private string _sName137_187;
        [DbColumn("sName137_187")]
        [DisplayName("sName137_187")]
        public string sName137_187
        {
            get => _sName137_187;
            set => SetProperty(ref _sName137_187, value);
        }

        private int? _iPlan137_188;
        [DbColumn("iPlan137_188")]
        [DisplayName("iPlan137_188")]
        public int? iPlan137_188
        {
            get => _iPlan137_188;
            set => SetProperty(ref _iPlan137_188, value);
        }

        private string _sScNo138_189;
        [DbColumn("sScNo138_189")]
        [DisplayName("sScNo138_189")]
        public string sScNo138_189
        {
            get => _sScNo138_189;
            set => SetProperty(ref _sScNo138_189, value);
        }

        private string _sScDv138_190;
        [DbColumn("sScDv138_190")]
        [DisplayName("sScDv138_190")]
        public string sScDv138_190
        {
            get => _sScDv138_190;
            set => SetProperty(ref _sScDv138_190, value);
        }

        private int? _iCode138_191;
        [DbColumn("iCode138_191")]
        [DisplayName("iCode138_191")]
        public int? iCode138_191
        {
            get => _iCode138_191;
            set => SetProperty(ref _iCode138_191, value);
        }

        private string _sName138_192;
        [DbColumn("sName138_192")]
        [DisplayName("sName138_192")]
        public string sName138_192
        {
            get => _sName138_192;
            set => SetProperty(ref _sName138_192, value);
        }

        private int? _iPlan138_193;
        [DbColumn("iPlan138_193")]
        [DisplayName("iPlan138_193")]
        public int? iPlan138_193
        {
            get => _iPlan138_193;
            set => SetProperty(ref _iPlan138_193, value);
        }

        private string _sScNo139_194;
        [DbColumn("sScNo139_194")]
        [DisplayName("sScNo139_194")]
        public string sScNo139_194
        {
            get => _sScNo139_194;
            set => SetProperty(ref _sScNo139_194, value);
        }

        private string _sScDv139_195;
        [DbColumn("sScDv139_195")]
        [DisplayName("sScDv139_195")]
        public string sScDv139_195
        {
            get => _sScDv139_195;
            set => SetProperty(ref _sScDv139_195, value);
        }

        private int? _iCode139_196;
        [DbColumn("iCode139_196")]
        [DisplayName("iCode139_196")]
        public int? iCode139_196
        {
            get => _iCode139_196;
            set => SetProperty(ref _iCode139_196, value);
        }

        private string _sName139_197;
        [DbColumn("sName139_197")]
        [DisplayName("sName139_197")]
        public string sName139_197
        {
            get => _sName139_197;
            set => SetProperty(ref _sName139_197, value);
        }

        private int? _iPlan139_198;
        [DbColumn("iPlan139_198")]
        [DisplayName("iPlan139_198")]
        public int? iPlan139_198
        {
            get => _iPlan139_198;
            set => SetProperty(ref _iPlan139_198, value);
        }

        private string _sScNo140_199;
        [DbColumn("sScNo140_199")]
        [DisplayName("sScNo140_199")]
        public string sScNo140_199
        {
            get => _sScNo140_199;
            set => SetProperty(ref _sScNo140_199, value);
        }

        private string _sScDv140_200;
        [DbColumn("sScDv140_200")]
        [DisplayName("sScDv140_200")]
        public string sScDv140_200
        {
            get => _sScDv140_200;
            set => SetProperty(ref _sScDv140_200, value);
        }

        private int? _iCode140_201;
        [DbColumn("iCode140_201")]
        [DisplayName("iCode140_201")]
        public int? iCode140_201
        {
            get => _iCode140_201;
            set => SetProperty(ref _iCode140_201, value);
        }

        private string _sName140_202;
        [DbColumn("sName140_202")]
        [DisplayName("sName140_202")]
        public string sName140_202
        {
            get => _sName140_202;
            set => SetProperty(ref _sName140_202, value);
        }

        private int? _iPlan140_203;
        [DbColumn("iPlan140_203")]
        [DisplayName("iPlan140_203")]
        public int? iPlan140_203
        {
            get => _iPlan140_203;
            set => SetProperty(ref _iPlan140_203, value);
        }

        private int? _iPuttot2_204;
        [DbColumn("iPuttot2_204")]
        [DisplayName("iPuttot2_204")]
        public int? iPuttot2_204
        {
            get => _iPuttot2_204;
            set => SetProperty(ref _iPuttot2_204, value);
        }

        private string _sScNo201_205;
        [DbColumn("sScNo201_205")]
        [DisplayName("sScNo201_205")]
        public string sScNo201_205
        {
            get => _sScNo201_205;
            set => SetProperty(ref _sScNo201_205, value);
        }

        private string _sScDv201_206;
        [DbColumn("sScDv201_206")]
        [DisplayName("sScDv201_206")]
        public string sScDv201_206
        {
            get => _sScDv201_206;
            set => SetProperty(ref _sScDv201_206, value);
        }

        private int? _iCode201_207;
        [DbColumn("iCode201_207")]
        [DisplayName("iCode201_207")]
        public int? iCode201_207
        {
            get => _iCode201_207;
            set => SetProperty(ref _iCode201_207, value);
        }

        private string _sName201_208;
        [DbColumn("sName201_208")]
        [DisplayName("sName201_208")]
        public string sName201_208
        {
            get => _sName201_208;
            set => SetProperty(ref _sName201_208, value);
        }

        private int? _iPlan201_209;
        [DbColumn("iPlan201_209")]
        [DisplayName("iPlan201_209")]
        public int? iPlan201_209
        {
            get => _iPlan201_209;
            set => SetProperty(ref _iPlan201_209, value);
        }

        private string _sScNo202_210;
        [DbColumn("sScNo202_210")]
        [DisplayName("sScNo202_210")]
        public string sScNo202_210
        {
            get => _sScNo202_210;
            set => SetProperty(ref _sScNo202_210, value);
        }

        private string _sScDv202_211;
        [DbColumn("sScDv202_211")]
        [DisplayName("sScDv202_211")]
        public string sScDv202_211
        {
            get => _sScDv202_211;
            set => SetProperty(ref _sScDv202_211, value);
        }

        private int? _iCode202_212;
        [DbColumn("iCode202_212")]
        [DisplayName("iCode202_212")]
        public int? iCode202_212
        {
            get => _iCode202_212;
            set => SetProperty(ref _iCode202_212, value);
        }

        private string _sName202_213;
        [DbColumn("sName202_213")]
        [DisplayName("sName202_213")]
        public string sName202_213
        {
            get => _sName202_213;
            set => SetProperty(ref _sName202_213, value);
        }

        private int? _iPlan202_214;
        [DbColumn("iPlan202_214")]
        [DisplayName("iPlan202_214")]
        public int? iPlan202_214
        {
            get => _iPlan202_214;
            set => SetProperty(ref _iPlan202_214, value);
        }

        private string _sScNo203_215;
        [DbColumn("sScNo203_215")]
        [DisplayName("sScNo203_215")]
        public string sScNo203_215
        {
            get => _sScNo203_215;
            set => SetProperty(ref _sScNo203_215, value);
        }

        private string _sScDv203_216;
        [DbColumn("sScDv203_216")]
        [DisplayName("sScDv203_216")]
        public string sScDv203_216
        {
            get => _sScDv203_216;
            set => SetProperty(ref _sScDv203_216, value);
        }

        private int? _iCode203_217;
        [DbColumn("iCode203_217")]
        [DisplayName("iCode203_217")]
        public int? iCode203_217
        {
            get => _iCode203_217;
            set => SetProperty(ref _iCode203_217, value);
        }

        private string _sName203_218;
        [DbColumn("sName203_218")]
        [DisplayName("sName203_218")]
        public string sName203_218
        {
            get => _sName203_218;
            set => SetProperty(ref _sName203_218, value);
        }

        private int? _iPlan203_219;
        [DbColumn("iPlan203_219")]
        [DisplayName("iPlan203_219")]
        public int? iPlan203_219
        {
            get => _iPlan203_219;
            set => SetProperty(ref _iPlan203_219, value);
        }

        private string _sScNo204_220;
        [DbColumn("sScNo204_220")]
        [DisplayName("sScNo204_220")]
        public string sScNo204_220
        {
            get => _sScNo204_220;
            set => SetProperty(ref _sScNo204_220, value);
        }

        private string _sScDv204_221;
        [DbColumn("sScDv204_221")]
        [DisplayName("sScDv204_221")]
        public string sScDv204_221
        {
            get => _sScDv204_221;
            set => SetProperty(ref _sScDv204_221, value);
        }

        private int? _iCode204_222;
        [DbColumn("iCode204_222")]
        [DisplayName("iCode204_222")]
        public int? iCode204_222
        {
            get => _iCode204_222;
            set => SetProperty(ref _iCode204_222, value);
        }

        private string _sName204_223;
        [DbColumn("sName204_223")]
        [DisplayName("sName204_223")]
        public string sName204_223
        {
            get => _sName204_223;
            set => SetProperty(ref _sName204_223, value);
        }

        private int? _iPlan204_224;
        [DbColumn("iPlan204_224")]
        [DisplayName("iPlan204_224")]
        public int? iPlan204_224
        {
            get => _iPlan204_224;
            set => SetProperty(ref _iPlan204_224, value);
        }

        private string _sScNo205_225;
        [DbColumn("sScNo205_225")]
        [DisplayName("sScNo205_225")]
        public string sScNo205_225
        {
            get => _sScNo205_225;
            set => SetProperty(ref _sScNo205_225, value);
        }

        private string _sScDv205_226;
        [DbColumn("sScDv205_226")]
        [DisplayName("sScDv205_226")]
        public string sScDv205_226
        {
            get => _sScDv205_226;
            set => SetProperty(ref _sScDv205_226, value);
        }

        private int? _iCode205_227;
        [DbColumn("iCode205_227")]
        [DisplayName("iCode205_227")]
        public int? iCode205_227
        {
            get => _iCode205_227;
            set => SetProperty(ref _iCode205_227, value);
        }

        private string _sName205_228;
        [DbColumn("sName205_228")]
        [DisplayName("sName205_228")]
        public string sName205_228
        {
            get => _sName205_228;
            set => SetProperty(ref _sName205_228, value);
        }

        private int? _iPlan205_229;
        [DbColumn("iPlan205_229")]
        [DisplayName("iPlan205_229")]
        public int? iPlan205_229
        {
            get => _iPlan205_229;
            set => SetProperty(ref _iPlan205_229, value);
        }

        private string _sScNo206_230;
        [DbColumn("sScNo206_230")]
        [DisplayName("sScNo206_230")]
        public string sScNo206_230
        {
            get => _sScNo206_230;
            set => SetProperty(ref _sScNo206_230, value);
        }

        private string _sScDv206_231;
        [DbColumn("sScDv206_231")]
        [DisplayName("sScDv206_231")]
        public string sScDv206_231
        {
            get => _sScDv206_231;
            set => SetProperty(ref _sScDv206_231, value);
        }

        private int? _iCode206_232;
        [DbColumn("iCode206_232")]
        [DisplayName("iCode206_232")]
        public int? iCode206_232
        {
            get => _iCode206_232;
            set => SetProperty(ref _iCode206_232, value);
        }

        private string _sName206_233;
        [DbColumn("sName206_233")]
        [DisplayName("sName206_233")]
        public string sName206_233
        {
            get => _sName206_233;
            set => SetProperty(ref _sName206_233, value);
        }

        private int? _iPlan206_234;
        [DbColumn("iPlan206_234")]
        [DisplayName("iPlan206_234")]
        public int? iPlan206_234
        {
            get => _iPlan206_234;
            set => SetProperty(ref _iPlan206_234, value);
        }

        private string _sScNo207_235;
        [DbColumn("sScNo207_235")]
        [DisplayName("sScNo207_235")]
        public string sScNo207_235
        {
            get => _sScNo207_235;
            set => SetProperty(ref _sScNo207_235, value);
        }

        private string _sScDv207_236;
        [DbColumn("sScDv207_236")]
        [DisplayName("sScDv207_236")]
        public string sScDv207_236
        {
            get => _sScDv207_236;
            set => SetProperty(ref _sScDv207_236, value);
        }

        private int? _iCode207_237;
        [DbColumn("iCode207_237")]
        [DisplayName("iCode207_237")]
        public int? iCode207_237
        {
            get => _iCode207_237;
            set => SetProperty(ref _iCode207_237, value);
        }

        private string _sName207_238;
        [DbColumn("sName207_238")]
        [DisplayName("sName207_238")]
        public string sName207_238
        {
            get => _sName207_238;
            set => SetProperty(ref _sName207_238, value);
        }

        private int? _iPlan207_239;
        [DbColumn("iPlan207_239")]
        [DisplayName("iPlan207_239")]
        public int? iPlan207_239
        {
            get => _iPlan207_239;
            set => SetProperty(ref _iPlan207_239, value);
        }

        private string _sScNo208_240;
        [DbColumn("sScNo208_240")]
        [DisplayName("sScNo208_240")]
        public string sScNo208_240
        {
            get => _sScNo208_240;
            set => SetProperty(ref _sScNo208_240, value);
        }

        private string _sScDv208_241;
        [DbColumn("sScDv208_241")]
        [DisplayName("sScDv208_241")]
        public string sScDv208_241
        {
            get => _sScDv208_241;
            set => SetProperty(ref _sScDv208_241, value);
        }

        private int? _iCode208_242;
        [DbColumn("iCode208_242")]
        [DisplayName("iCode208_242")]
        public int? iCode208_242
        {
            get => _iCode208_242;
            set => SetProperty(ref _iCode208_242, value);
        }

        private string _sName208_243;
        [DbColumn("sName208_243")]
        [DisplayName("sName208_243")]
        public string sName208_243
        {
            get => _sName208_243;
            set => SetProperty(ref _sName208_243, value);
        }

        private int? _iPlan208_244;
        [DbColumn("iPlan208_244")]
        [DisplayName("iPlan208_244")]
        public int? iPlan208_244
        {
            get => _iPlan208_244;
            set => SetProperty(ref _iPlan208_244, value);
        }

        private string _sScNo209_245;
        [DbColumn("sScNo209_245")]
        [DisplayName("sScNo209_245")]
        public string sScNo209_245
        {
            get => _sScNo209_245;
            set => SetProperty(ref _sScNo209_245, value);
        }

        private string _sScDv209_246;
        [DbColumn("sScDv209_246")]
        [DisplayName("sScDv209_246")]
        public string sScDv209_246
        {
            get => _sScDv209_246;
            set => SetProperty(ref _sScDv209_246, value);
        }

        private int? _iCode209_247;
        [DbColumn("iCode209_247")]
        [DisplayName("iCode209_247")]
        public int? iCode209_247
        {
            get => _iCode209_247;
            set => SetProperty(ref _iCode209_247, value);
        }

        private string _sName209_248;
        [DbColumn("sName209_248")]
        [DisplayName("sName209_248")]
        public string sName209_248
        {
            get => _sName209_248;
            set => SetProperty(ref _sName209_248, value);
        }

        private int? _iPlan209_249;
        [DbColumn("iPlan209_249")]
        [DisplayName("iPlan209_249")]
        public int? iPlan209_249
        {
            get => _iPlan209_249;
            set => SetProperty(ref _iPlan209_249, value);
        }

        private string _sScNo210_250;
        [DbColumn("sScNo210_250")]
        [DisplayName("sScNo210_250")]
        public string sScNo210_250
        {
            get => _sScNo210_250;
            set => SetProperty(ref _sScNo210_250, value);
        }

        private string _sScDv210_251;
        [DbColumn("sScDv210_251")]
        [DisplayName("sScDv210_251")]
        public string sScDv210_251
        {
            get => _sScDv210_251;
            set => SetProperty(ref _sScDv210_251, value);
        }

        private int? _iCode210_252;
        [DbColumn("iCode210_252")]
        [DisplayName("iCode210_252")]
        public int? iCode210_252
        {
            get => _iCode210_252;
            set => SetProperty(ref _iCode210_252, value);
        }

        private string _sName210_253;
        [DbColumn("sName210_253")]
        [DisplayName("sName210_253")]
        public string sName210_253
        {
            get => _sName210_253;
            set => SetProperty(ref _sName210_253, value);
        }

        private int? _iPlan210_254;
        [DbColumn("iPlan210_254")]
        [DisplayName("iPlan210_254")]
        public int? iPlan210_254
        {
            get => _iPlan210_254;
            set => SetProperty(ref _iPlan210_254, value);
        }

        private string _sScNo211_255;
        [DbColumn("sScNo211_255")]
        [DisplayName("sScNo211_255")]
        public string sScNo211_255
        {
            get => _sScNo211_255;
            set => SetProperty(ref _sScNo211_255, value);
        }

        private string _sScDv211_256;
        [DbColumn("sScDv211_256")]
        [DisplayName("sScDv211_256")]
        public string sScDv211_256
        {
            get => _sScDv211_256;
            set => SetProperty(ref _sScDv211_256, value);
        }

        private int? _iCode211_257;
        [DbColumn("iCode211_257")]
        [DisplayName("iCode211_257")]
        public int? iCode211_257
        {
            get => _iCode211_257;
            set => SetProperty(ref _iCode211_257, value);
        }

        private string _sName211_258;
        [DbColumn("sName211_258")]
        [DisplayName("sName211_258")]
        public string sName211_258
        {
            get => _sName211_258;
            set => SetProperty(ref _sName211_258, value);
        }

        private int? _iPlan211_259;
        [DbColumn("iPlan211_259")]
        [DisplayName("iPlan211_259")]
        public int? iPlan211_259
        {
            get => _iPlan211_259;
            set => SetProperty(ref _iPlan211_259, value);
        }

        private string _sScNo212_260;
        [DbColumn("sScNo212_260")]
        [DisplayName("sScNo212_260")]
        public string sScNo212_260
        {
            get => _sScNo212_260;
            set => SetProperty(ref _sScNo212_260, value);
        }

        private string _sScDv212_261;
        [DbColumn("sScDv212_261")]
        [DisplayName("sScDv212_261")]
        public string sScDv212_261
        {
            get => _sScDv212_261;
            set => SetProperty(ref _sScDv212_261, value);
        }

        private int? _iCode212_262;
        [DbColumn("iCode212_262")]
        [DisplayName("iCode212_262")]
        public int? iCode212_262
        {
            get => _iCode212_262;
            set => SetProperty(ref _iCode212_262, value);
        }

        private string _sName212_263;
        [DbColumn("sName212_263")]
        [DisplayName("sName212_263")]
        public string sName212_263
        {
            get => _sName212_263;
            set => SetProperty(ref _sName212_263, value);
        }

        private int? _iPlan212_264;
        [DbColumn("iPlan212_264")]
        [DisplayName("iPlan212_264")]
        public int? iPlan212_264
        {
            get => _iPlan212_264;
            set => SetProperty(ref _iPlan212_264, value);
        }

        private string _sScNo213_265;
        [DbColumn("sScNo213_265")]
        [DisplayName("sScNo213_265")]
        public string sScNo213_265
        {
            get => _sScNo213_265;
            set => SetProperty(ref _sScNo213_265, value);
        }

        private string _sScDv213_266;
        [DbColumn("sScDv213_266")]
        [DisplayName("sScDv213_266")]
        public string sScDv213_266
        {
            get => _sScDv213_266;
            set => SetProperty(ref _sScDv213_266, value);
        }

        private int? _iCode213_267;
        [DbColumn("iCode213_267")]
        [DisplayName("iCode213_267")]
        public int? iCode213_267
        {
            get => _iCode213_267;
            set => SetProperty(ref _iCode213_267, value);
        }

        private string _sName213_268;
        [DbColumn("sName213_268")]
        [DisplayName("sName213_268")]
        public string sName213_268
        {
            get => _sName213_268;
            set => SetProperty(ref _sName213_268, value);
        }

        private int? _iPlan213_269;
        [DbColumn("iPlan213_269")]
        [DisplayName("iPlan213_269")]
        public int? iPlan213_269
        {
            get => _iPlan213_269;
            set => SetProperty(ref _iPlan213_269, value);
        }

        private string _sScNo214_270;
        [DbColumn("sScNo214_270")]
        [DisplayName("sScNo214_270")]
        public string sScNo214_270
        {
            get => _sScNo214_270;
            set => SetProperty(ref _sScNo214_270, value);
        }

        private string _sScDv214_271;
        [DbColumn("sScDv214_271")]
        [DisplayName("sScDv214_271")]
        public string sScDv214_271
        {
            get => _sScDv214_271;
            set => SetProperty(ref _sScDv214_271, value);
        }

        private int? _iCode214_272;
        [DbColumn("iCode214_272")]
        [DisplayName("iCode214_272")]
        public int? iCode214_272
        {
            get => _iCode214_272;
            set => SetProperty(ref _iCode214_272, value);
        }

        private string _sName214_273;
        [DbColumn("sName214_273")]
        [DisplayName("sName214_273")]
        public string sName214_273
        {
            get => _sName214_273;
            set => SetProperty(ref _sName214_273, value);
        }

        private int? _iPlan214_274;
        [DbColumn("iPlan214_274")]
        [DisplayName("iPlan214_274")]
        public int? iPlan214_274
        {
            get => _iPlan214_274;
            set => SetProperty(ref _iPlan214_274, value);
        }

        private string _sScNo215_275;
        [DbColumn("sScNo215_275")]
        [DisplayName("sScNo215_275")]
        public string sScNo215_275
        {
            get => _sScNo215_275;
            set => SetProperty(ref _sScNo215_275, value);
        }

        private string _sScDv215_276;
        [DbColumn("sScDv215_276")]
        [DisplayName("sScDv215_276")]
        public string sScDv215_276
        {
            get => _sScDv215_276;
            set => SetProperty(ref _sScDv215_276, value);
        }

        private int? _iCode215_277;
        [DbColumn("iCode215_277")]
        [DisplayName("iCode215_277")]
        public int? iCode215_277
        {
            get => _iCode215_277;
            set => SetProperty(ref _iCode215_277, value);
        }

        private string _sName215_278;
        [DbColumn("sName215_278")]
        [DisplayName("sName215_278")]
        public string sName215_278
        {
            get => _sName215_278;
            set => SetProperty(ref _sName215_278, value);
        }

        private int? _iPlan215_279;
        [DbColumn("iPlan215_279")]
        [DisplayName("iPlan215_279")]
        public int? iPlan215_279
        {
            get => _iPlan215_279;
            set => SetProperty(ref _iPlan215_279, value);
        }

        private string _sScNo216_280;
        [DbColumn("sScNo216_280")]
        [DisplayName("sScNo216_280")]
        public string sScNo216_280
        {
            get => _sScNo216_280;
            set => SetProperty(ref _sScNo216_280, value);
        }

        private string _sScDv216_281;
        [DbColumn("sScDv216_281")]
        [DisplayName("sScDv216_281")]
        public string sScDv216_281
        {
            get => _sScDv216_281;
            set => SetProperty(ref _sScDv216_281, value);
        }

        private int? _iCode216_282;
        [DbColumn("iCode216_282")]
        [DisplayName("iCode216_282")]
        public int? iCode216_282
        {
            get => _iCode216_282;
            set => SetProperty(ref _iCode216_282, value);
        }

        private string _sName216_283;
        [DbColumn("sName216_283")]
        [DisplayName("sName216_283")]
        public string sName216_283
        {
            get => _sName216_283;
            set => SetProperty(ref _sName216_283, value);
        }

        private int? _iPlan216_284;
        [DbColumn("iPlan216_284")]
        [DisplayName("iPlan216_284")]
        public int? iPlan216_284
        {
            get => _iPlan216_284;
            set => SetProperty(ref _iPlan216_284, value);
        }

        private string _sScNo217_285;
        [DbColumn("sScNo217_285")]
        [DisplayName("sScNo217_285")]
        public string sScNo217_285
        {
            get => _sScNo217_285;
            set => SetProperty(ref _sScNo217_285, value);
        }

        private string _sScDv217_286;
        [DbColumn("sScDv217_286")]
        [DisplayName("sScDv217_286")]
        public string sScDv217_286
        {
            get => _sScDv217_286;
            set => SetProperty(ref _sScDv217_286, value);
        }

        private int? _iCode217_287;
        [DbColumn("iCode217_287")]
        [DisplayName("iCode217_287")]
        public int? iCode217_287
        {
            get => _iCode217_287;
            set => SetProperty(ref _iCode217_287, value);
        }

        private string _sName217_288;
        [DbColumn("sName217_288")]
        [DisplayName("sName217_288")]
        public string sName217_288
        {
            get => _sName217_288;
            set => SetProperty(ref _sName217_288, value);
        }

        private int? _iPlan217_289;
        [DbColumn("iPlan217_289")]
        [DisplayName("iPlan217_289")]
        public int? iPlan217_289
        {
            get => _iPlan217_289;
            set => SetProperty(ref _iPlan217_289, value);
        }

        private string _sScNo218_290;
        [DbColumn("sScNo218_290")]
        [DisplayName("sScNo218_290")]
        public string sScNo218_290
        {
            get => _sScNo218_290;
            set => SetProperty(ref _sScNo218_290, value);
        }

        private string _sScDv218_291;
        [DbColumn("sScDv218_291")]
        [DisplayName("sScDv218_291")]
        public string sScDv218_291
        {
            get => _sScDv218_291;
            set => SetProperty(ref _sScDv218_291, value);
        }

        private int? _iCode218_292;
        [DbColumn("iCode218_292")]
        [DisplayName("iCode218_292")]
        public int? iCode218_292
        {
            get => _iCode218_292;
            set => SetProperty(ref _iCode218_292, value);
        }

        private string _sName218_293;
        [DbColumn("sName218_293")]
        [DisplayName("sName218_293")]
        public string sName218_293
        {
            get => _sName218_293;
            set => SetProperty(ref _sName218_293, value);
        }

        private int? _iPlan218_294;
        [DbColumn("iPlan218_294")]
        [DisplayName("iPlan218_294")]
        public int? iPlan218_294
        {
            get => _iPlan218_294;
            set => SetProperty(ref _iPlan218_294, value);
        }

        private string _sScNo219_295;
        [DbColumn("sScNo219_295")]
        [DisplayName("sScNo219_295")]
        public string sScNo219_295
        {
            get => _sScNo219_295;
            set => SetProperty(ref _sScNo219_295, value);
        }

        private string _sScDv219_296;
        [DbColumn("sScDv219_296")]
        [DisplayName("sScDv219_296")]
        public string sScDv219_296
        {
            get => _sScDv219_296;
            set => SetProperty(ref _sScDv219_296, value);
        }

        private int? _iCode219_297;
        [DbColumn("iCode219_297")]
        [DisplayName("iCode219_297")]
        public int? iCode219_297
        {
            get => _iCode219_297;
            set => SetProperty(ref _iCode219_297, value);
        }

        private string _sName219_298;
        [DbColumn("sName219_298")]
        [DisplayName("sName219_298")]
        public string sName219_298
        {
            get => _sName219_298;
            set => SetProperty(ref _sName219_298, value);
        }

        private int? _iPlan219_299;
        [DbColumn("iPlan219_299")]
        [DisplayName("iPlan219_299")]
        public int? iPlan219_299
        {
            get => _iPlan219_299;
            set => SetProperty(ref _iPlan219_299, value);
        }

        private string _sScNo220_300;
        [DbColumn("sScNo220_300")]
        [DisplayName("sScNo220_300")]
        public string sScNo220_300
        {
            get => _sScNo220_300;
            set => SetProperty(ref _sScNo220_300, value);
        }

        private string _sScDv220_301;
        [DbColumn("sScDv220_301")]
        [DisplayName("sScDv220_301")]
        public string sScDv220_301
        {
            get => _sScDv220_301;
            set => SetProperty(ref _sScDv220_301, value);
        }

        private int? _iCode220_302;
        [DbColumn("iCode220_302")]
        [DisplayName("iCode220_302")]
        public int? iCode220_302
        {
            get => _iCode220_302;
            set => SetProperty(ref _iCode220_302, value);
        }

        private string _sName220_303;
        [DbColumn("sName220_303")]
        [DisplayName("sName220_303")]
        public string sName220_303
        {
            get => _sName220_303;
            set => SetProperty(ref _sName220_303, value);
        }

        private int? _iPlan220_304;
        [DbColumn("iPlan220_304")]
        [DisplayName("iPlan220_304")]
        public int? iPlan220_304
        {
            get => _iPlan220_304;
            set => SetProperty(ref _iPlan220_304, value);
        }

        private string _sScNo221_305;
        [DbColumn("sScNo221_305")]
        [DisplayName("sScNo221_305")]
        public string sScNo221_305
        {
            get => _sScNo221_305;
            set => SetProperty(ref _sScNo221_305, value);
        }

        private string _sScDv221_306;
        [DbColumn("sScDv221_306")]
        [DisplayName("sScDv221_306")]
        public string sScDv221_306
        {
            get => _sScDv221_306;
            set => SetProperty(ref _sScDv221_306, value);
        }

        private int? _iCode221_307;
        [DbColumn("iCode221_307")]
        [DisplayName("iCode221_307")]
        public int? iCode221_307
        {
            get => _iCode221_307;
            set => SetProperty(ref _iCode221_307, value);
        }

        private string _sName221_308;
        [DbColumn("sName221_308")]
        [DisplayName("sName221_308")]
        public string sName221_308
        {
            get => _sName221_308;
            set => SetProperty(ref _sName221_308, value);
        }

        private int? _iPlan221_309;
        [DbColumn("iPlan221_309")]
        [DisplayName("iPlan221_309")]
        public int? iPlan221_309
        {
            get => _iPlan221_309;
            set => SetProperty(ref _iPlan221_309, value);
        }

        private string _sScNo222_310;
        [DbColumn("sScNo222_310")]
        [DisplayName("sScNo222_310")]
        public string sScNo222_310
        {
            get => _sScNo222_310;
            set => SetProperty(ref _sScNo222_310, value);
        }

        private string _sScDv222_311;
        [DbColumn("sScDv222_311")]
        [DisplayName("sScDv222_311")]
        public string sScDv222_311
        {
            get => _sScDv222_311;
            set => SetProperty(ref _sScDv222_311, value);
        }

        private int? _iCode222_312;
        [DbColumn("iCode222_312")]
        [DisplayName("iCode222_312")]
        public int? iCode222_312
        {
            get => _iCode222_312;
            set => SetProperty(ref _iCode222_312, value);
        }

        private string _sName222_313;
        [DbColumn("sName222_313")]
        [DisplayName("sName222_313")]
        public string sName222_313
        {
            get => _sName222_313;
            set => SetProperty(ref _sName222_313, value);
        }

        private int? _iPlan222_314;
        [DbColumn("iPlan222_314")]
        [DisplayName("iPlan222_314")]
        public int? iPlan222_314
        {
            get => _iPlan222_314;
            set => SetProperty(ref _iPlan222_314, value);
        }

        private string _sScNo223_315;
        [DbColumn("sScNo223_315")]
        [DisplayName("sScNo223_315")]
        public string sScNo223_315
        {
            get => _sScNo223_315;
            set => SetProperty(ref _sScNo223_315, value);
        }

        private string _sScDv223_316;
        [DbColumn("sScDv223_316")]
        [DisplayName("sScDv223_316")]
        public string sScDv223_316
        {
            get => _sScDv223_316;
            set => SetProperty(ref _sScDv223_316, value);
        }

        private int? _iCode223_317;
        [DbColumn("iCode223_317")]
        [DisplayName("iCode223_317")]
        public int? iCode223_317
        {
            get => _iCode223_317;
            set => SetProperty(ref _iCode223_317, value);
        }

        private string _sName223_318;
        [DbColumn("sName223_318")]
        [DisplayName("sName223_318")]
        public string sName223_318
        {
            get => _sName223_318;
            set => SetProperty(ref _sName223_318, value);
        }

        private int? _iPlan223_319;
        [DbColumn("iPlan223_319")]
        [DisplayName("iPlan223_319")]
        public int? iPlan223_319
        {
            get => _iPlan223_319;
            set => SetProperty(ref _iPlan223_319, value);
        }

        private string _sScNo224_320;
        [DbColumn("sScNo224_320")]
        [DisplayName("sScNo224_320")]
        public string sScNo224_320
        {
            get => _sScNo224_320;
            set => SetProperty(ref _sScNo224_320, value);
        }

        private string _sScDv224_321;
        [DbColumn("sScDv224_321")]
        [DisplayName("sScDv224_321")]
        public string sScDv224_321
        {
            get => _sScDv224_321;
            set => SetProperty(ref _sScDv224_321, value);
        }

        private int? _iCode224_322;
        [DbColumn("iCode224_322")]
        [DisplayName("iCode224_322")]
        public int? iCode224_322
        {
            get => _iCode224_322;
            set => SetProperty(ref _iCode224_322, value);
        }

        private string _sName224_323;
        [DbColumn("sName224_323")]
        [DisplayName("sName224_323")]
        public string sName224_323
        {
            get => _sName224_323;
            set => SetProperty(ref _sName224_323, value);
        }

        private int? _iPlan224_324;
        [DbColumn("iPlan224_324")]
        [DisplayName("iPlan224_324")]
        public int? iPlan224_324
        {
            get => _iPlan224_324;
            set => SetProperty(ref _iPlan224_324, value);
        }

        private string _sScNo225_325;
        [DbColumn("sScNo225_325")]
        [DisplayName("sScNo225_325")]
        public string sScNo225_325
        {
            get => _sScNo225_325;
            set => SetProperty(ref _sScNo225_325, value);
        }

        private string _sScDv225_326;
        [DbColumn("sScDv225_326")]
        [DisplayName("sScDv225_326")]
        public string sScDv225_326
        {
            get => _sScDv225_326;
            set => SetProperty(ref _sScDv225_326, value);
        }

        private int? _iCode225_327;
        [DbColumn("iCode225_327")]
        [DisplayName("iCode225_327")]
        public int? iCode225_327
        {
            get => _iCode225_327;
            set => SetProperty(ref _iCode225_327, value);
        }

        private string _sName225_328;
        [DbColumn("sName225_328")]
        [DisplayName("sName225_328")]
        public string sName225_328
        {
            get => _sName225_328;
            set => SetProperty(ref _sName225_328, value);
        }

        private int? _iPlan225_329;
        [DbColumn("iPlan225_329")]
        [DisplayName("iPlan225_329")]
        public int? iPlan225_329
        {
            get => _iPlan225_329;
            set => SetProperty(ref _iPlan225_329, value);
        }

        private string _sScNo226_330;
        [DbColumn("sScNo226_330")]
        [DisplayName("sScNo226_330")]
        public string sScNo226_330
        {
            get => _sScNo226_330;
            set => SetProperty(ref _sScNo226_330, value);
        }

        private string _sScDv226_331;
        [DbColumn("sScDv226_331")]
        [DisplayName("sScDv226_331")]
        public string sScDv226_331
        {
            get => _sScDv226_331;
            set => SetProperty(ref _sScDv226_331, value);
        }

        private int? _iCode226_332;
        [DbColumn("iCode226_332")]
        [DisplayName("iCode226_332")]
        public int? iCode226_332
        {
            get => _iCode226_332;
            set => SetProperty(ref _iCode226_332, value);
        }

        private string _sName226_333;
        [DbColumn("sName226_333")]
        [DisplayName("sName226_333")]
        public string sName226_333
        {
            get => _sName226_333;
            set => SetProperty(ref _sName226_333, value);
        }

        private int? _iPlan226_334;
        [DbColumn("iPlan226_334")]
        [DisplayName("iPlan226_334")]
        public int? iPlan226_334
        {
            get => _iPlan226_334;
            set => SetProperty(ref _iPlan226_334, value);
        }

        private string _sScNo227_335;
        [DbColumn("sScNo227_335")]
        [DisplayName("sScNo227_335")]
        public string sScNo227_335
        {
            get => _sScNo227_335;
            set => SetProperty(ref _sScNo227_335, value);
        }

        private string _sScDv227_336;
        [DbColumn("sScDv227_336")]
        [DisplayName("sScDv227_336")]
        public string sScDv227_336
        {
            get => _sScDv227_336;
            set => SetProperty(ref _sScDv227_336, value);
        }

        private int? _iCode227_337;
        [DbColumn("iCode227_337")]
        [DisplayName("iCode227_337")]
        public int? iCode227_337
        {
            get => _iCode227_337;
            set => SetProperty(ref _iCode227_337, value);
        }

        private string _sName227_338;
        [DbColumn("sName227_338")]
        [DisplayName("sName227_338")]
        public string sName227_338
        {
            get => _sName227_338;
            set => SetProperty(ref _sName227_338, value);
        }

        private int? _iPlan227_339;
        [DbColumn("iPlan227_339")]
        [DisplayName("iPlan227_339")]
        public int? iPlan227_339
        {
            get => _iPlan227_339;
            set => SetProperty(ref _iPlan227_339, value);
        }

        private string _sScNo228_340;
        [DbColumn("sScNo228_340")]
        [DisplayName("sScNo228_340")]
        public string sScNo228_340
        {
            get => _sScNo228_340;
            set => SetProperty(ref _sScNo228_340, value);
        }

        private string _sScDv228_341;
        [DbColumn("sScDv228_341")]
        [DisplayName("sScDv228_341")]
        public string sScDv228_341
        {
            get => _sScDv228_341;
            set => SetProperty(ref _sScDv228_341, value);
        }

        private int? _iCode228_342;
        [DbColumn("iCode228_342")]
        [DisplayName("iCode228_342")]
        public int? iCode228_342
        {
            get => _iCode228_342;
            set => SetProperty(ref _iCode228_342, value);
        }

        private string _sName228_343;
        [DbColumn("sName228_343")]
        [DisplayName("sName228_343")]
        public string sName228_343
        {
            get => _sName228_343;
            set => SetProperty(ref _sName228_343, value);
        }

        private int? _iPlan228_344;
        [DbColumn("iPlan228_344")]
        [DisplayName("iPlan228_344")]
        public int? iPlan228_344
        {
            get => _iPlan228_344;
            set => SetProperty(ref _iPlan228_344, value);
        }

        private string _sScNo229_345;
        [DbColumn("sScNo229_345")]
        [DisplayName("sScNo229_345")]
        public string sScNo229_345
        {
            get => _sScNo229_345;
            set => SetProperty(ref _sScNo229_345, value);
        }

        private string _sScDv229_346;
        [DbColumn("sScDv229_346")]
        [DisplayName("sScDv229_346")]
        public string sScDv229_346
        {
            get => _sScDv229_346;
            set => SetProperty(ref _sScDv229_346, value);
        }

        private int? _iCode229_347;
        [DbColumn("iCode229_347")]
        [DisplayName("iCode229_347")]
        public int? iCode229_347
        {
            get => _iCode229_347;
            set => SetProperty(ref _iCode229_347, value);
        }

        private string _sName229_348;
        [DbColumn("sName229_348")]
        [DisplayName("sName229_348")]
        public string sName229_348
        {
            get => _sName229_348;
            set => SetProperty(ref _sName229_348, value);
        }

        private int? _iPlan229_349;
        [DbColumn("iPlan229_349")]
        [DisplayName("iPlan229_349")]
        public int? iPlan229_349
        {
            get => _iPlan229_349;
            set => SetProperty(ref _iPlan229_349, value);
        }

        private string _sScNo230_350;
        [DbColumn("sScNo230_350")]
        [DisplayName("sScNo230_350")]
        public string sScNo230_350
        {
            get => _sScNo230_350;
            set => SetProperty(ref _sScNo230_350, value);
        }

        private string _sScDv230_351;
        [DbColumn("sScDv230_351")]
        [DisplayName("sScDv230_351")]
        public string sScDv230_351
        {
            get => _sScDv230_351;
            set => SetProperty(ref _sScDv230_351, value);
        }

        private int? _iCode230_352;
        [DbColumn("iCode230_352")]
        [DisplayName("iCode230_352")]
        public int? iCode230_352
        {
            get => _iCode230_352;
            set => SetProperty(ref _iCode230_352, value);
        }

        private string _sName230_353;
        [DbColumn("sName230_353")]
        [DisplayName("sName230_353")]
        public string sName230_353
        {
            get => _sName230_353;
            set => SetProperty(ref _sName230_353, value);
        }

        private int? _iPlan230_354;
        [DbColumn("iPlan230_354")]
        [DisplayName("iPlan230_354")]
        public int? iPlan230_354
        {
            get => _iPlan230_354;
            set => SetProperty(ref _iPlan230_354, value);
        }

        private string _sScNo231_355;
        [DbColumn("sScNo231_355")]
        [DisplayName("sScNo231_355")]
        public string sScNo231_355
        {
            get => _sScNo231_355;
            set => SetProperty(ref _sScNo231_355, value);
        }

        private string _sScDv231_356;
        [DbColumn("sScDv231_356")]
        [DisplayName("sScDv231_356")]
        public string sScDv231_356
        {
            get => _sScDv231_356;
            set => SetProperty(ref _sScDv231_356, value);
        }

        private int? _iCode231_357;
        [DbColumn("iCode231_357")]
        [DisplayName("iCode231_357")]
        public int? iCode231_357
        {
            get => _iCode231_357;
            set => SetProperty(ref _iCode231_357, value);
        }

        private string _sName231_358;
        [DbColumn("sName231_358")]
        [DisplayName("sName231_358")]
        public string sName231_358
        {
            get => _sName231_358;
            set => SetProperty(ref _sName231_358, value);
        }

        private int? _iPlan231_359;
        [DbColumn("iPlan231_359")]
        [DisplayName("iPlan231_359")]
        public int? iPlan231_359
        {
            get => _iPlan231_359;
            set => SetProperty(ref _iPlan231_359, value);
        }

        private string _sScNo232_360;
        [DbColumn("sScNo232_360")]
        [DisplayName("sScNo232_360")]
        public string sScNo232_360
        {
            get => _sScNo232_360;
            set => SetProperty(ref _sScNo232_360, value);
        }

        private string _sScDv232_361;
        [DbColumn("sScDv232_361")]
        [DisplayName("sScDv232_361")]
        public string sScDv232_361
        {
            get => _sScDv232_361;
            set => SetProperty(ref _sScDv232_361, value);
        }

        private int? _iCode232_362;
        [DbColumn("iCode232_362")]
        [DisplayName("iCode232_362")]
        public int? iCode232_362
        {
            get => _iCode232_362;
            set => SetProperty(ref _iCode232_362, value);
        }

        private string _sName232_363;
        [DbColumn("sName232_363")]
        [DisplayName("sName232_363")]
        public string sName232_363
        {
            get => _sName232_363;
            set => SetProperty(ref _sName232_363, value);
        }

        private int? _iPlan232_364;
        [DbColumn("iPlan232_364")]
        [DisplayName("iPlan232_364")]
        public int? iPlan232_364
        {
            get => _iPlan232_364;
            set => SetProperty(ref _iPlan232_364, value);
        }

        private string _sScNo233_365;
        [DbColumn("sScNo233_365")]
        [DisplayName("sScNo233_365")]
        public string sScNo233_365
        {
            get => _sScNo233_365;
            set => SetProperty(ref _sScNo233_365, value);
        }

        private string _sScDv233_366;
        [DbColumn("sScDv233_366")]
        [DisplayName("sScDv233_366")]
        public string sScDv233_366
        {
            get => _sScDv233_366;
            set => SetProperty(ref _sScDv233_366, value);
        }

        private int? _iCode233_367;
        [DbColumn("iCode233_367")]
        [DisplayName("iCode233_367")]
        public int? iCode233_367
        {
            get => _iCode233_367;
            set => SetProperty(ref _iCode233_367, value);
        }

        private string _sName233_368;
        [DbColumn("sName233_368")]
        [DisplayName("sName233_368")]
        public string sName233_368
        {
            get => _sName233_368;
            set => SetProperty(ref _sName233_368, value);
        }

        private int? _iPlan233_369;
        [DbColumn("iPlan233_369")]
        [DisplayName("iPlan233_369")]
        public int? iPlan233_369
        {
            get => _iPlan233_369;
            set => SetProperty(ref _iPlan233_369, value);
        }

        private string _sScNo234_370;
        [DbColumn("sScNo234_370")]
        [DisplayName("sScNo234_370")]
        public string sScNo234_370
        {
            get => _sScNo234_370;
            set => SetProperty(ref _sScNo234_370, value);
        }

        private string _sScDv234_371;
        [DbColumn("sScDv234_371")]
        [DisplayName("sScDv234_371")]
        public string sScDv234_371
        {
            get => _sScDv234_371;
            set => SetProperty(ref _sScDv234_371, value);
        }

        private int? _iCode234_372;
        [DbColumn("iCode234_372")]
        [DisplayName("iCode234_372")]
        public int? iCode234_372
        {
            get => _iCode234_372;
            set => SetProperty(ref _iCode234_372, value);
        }

        private string _sName234_373;
        [DbColumn("sName234_373")]
        [DisplayName("sName234_373")]
        public string sName234_373
        {
            get => _sName234_373;
            set => SetProperty(ref _sName234_373, value);
        }

        private int? _iPlan234_374;
        [DbColumn("iPlan234_374")]
        [DisplayName("iPlan234_374")]
        public int? iPlan234_374
        {
            get => _iPlan234_374;
            set => SetProperty(ref _iPlan234_374, value);
        }

        private string _sScNo235_375;
        [DbColumn("sScNo235_375")]
        [DisplayName("sScNo235_375")]
        public string sScNo235_375
        {
            get => _sScNo235_375;
            set => SetProperty(ref _sScNo235_375, value);
        }

        private string _sScDv235_376;
        [DbColumn("sScDv235_376")]
        [DisplayName("sScDv235_376")]
        public string sScDv235_376
        {
            get => _sScDv235_376;
            set => SetProperty(ref _sScDv235_376, value);
        }

        private int? _iCode235_377;
        [DbColumn("iCode235_377")]
        [DisplayName("iCode235_377")]
        public int? iCode235_377
        {
            get => _iCode235_377;
            set => SetProperty(ref _iCode235_377, value);
        }

        private string _sName235_378;
        [DbColumn("sName235_378")]
        [DisplayName("sName235_378")]
        public string sName235_378
        {
            get => _sName235_378;
            set => SetProperty(ref _sName235_378, value);
        }

        private int? _iPlan235_379;
        [DbColumn("iPlan235_379")]
        [DisplayName("iPlan235_379")]
        public int? iPlan235_379
        {
            get => _iPlan235_379;
            set => SetProperty(ref _iPlan235_379, value);
        }

        private string _sScNo236_380;
        [DbColumn("sScNo236_380")]
        [DisplayName("sScNo236_380")]
        public string sScNo236_380
        {
            get => _sScNo236_380;
            set => SetProperty(ref _sScNo236_380, value);
        }

        private string _sScDv236_381;
        [DbColumn("sScDv236_381")]
        [DisplayName("sScDv236_381")]
        public string sScDv236_381
        {
            get => _sScDv236_381;
            set => SetProperty(ref _sScDv236_381, value);
        }

        private int? _iCode236_382;
        [DbColumn("iCode236_382")]
        [DisplayName("iCode236_382")]
        public int? iCode236_382
        {
            get => _iCode236_382;
            set => SetProperty(ref _iCode236_382, value);
        }

        private string _sName236_383;
        [DbColumn("sName236_383")]
        [DisplayName("sName236_383")]
        public string sName236_383
        {
            get => _sName236_383;
            set => SetProperty(ref _sName236_383, value);
        }

        private int? _iPlan236_384;
        [DbColumn("iPlan236_384")]
        [DisplayName("iPlan236_384")]
        public int? iPlan236_384
        {
            get => _iPlan236_384;
            set => SetProperty(ref _iPlan236_384, value);
        }

        private string _sScNo237_385;
        [DbColumn("sScNo237_385")]
        [DisplayName("sScNo237_385")]
        public string sScNo237_385
        {
            get => _sScNo237_385;
            set => SetProperty(ref _sScNo237_385, value);
        }

        private string _sScDv237_386;
        [DbColumn("sScDv237_386")]
        [DisplayName("sScDv237_386")]
        public string sScDv237_386
        {
            get => _sScDv237_386;
            set => SetProperty(ref _sScDv237_386, value);
        }

        private int? _iCode237_387;
        [DbColumn("iCode237_387")]
        [DisplayName("iCode237_387")]
        public int? iCode237_387
        {
            get => _iCode237_387;
            set => SetProperty(ref _iCode237_387, value);
        }

        private string _sName237_388;
        [DbColumn("sName237_388")]
        [DisplayName("sName237_388")]
        public string sName237_388
        {
            get => _sName237_388;
            set => SetProperty(ref _sName237_388, value);
        }

        private int? _iPlan237_389;
        [DbColumn("iPlan237_389")]
        [DisplayName("iPlan237_389")]
        public int? iPlan237_389
        {
            get => _iPlan237_389;
            set => SetProperty(ref _iPlan237_389, value);
        }

        private string _sScNo238_390;
        [DbColumn("sScNo238_390")]
        [DisplayName("sScNo238_390")]
        public string sScNo238_390
        {
            get => _sScNo238_390;
            set => SetProperty(ref _sScNo238_390, value);
        }

        private string _sScDv238_391;
        [DbColumn("sScDv238_391")]
        [DisplayName("sScDv238_391")]
        public string sScDv238_391
        {
            get => _sScDv238_391;
            set => SetProperty(ref _sScDv238_391, value);
        }

        private int? _iCode238_392;
        [DbColumn("iCode238_392")]
        [DisplayName("iCode238_392")]
        public int? iCode238_392
        {
            get => _iCode238_392;
            set => SetProperty(ref _iCode238_392, value);
        }

        private string _sName238_393;
        [DbColumn("sName238_393")]
        [DisplayName("sName238_393")]
        public string sName238_393
        {
            get => _sName238_393;
            set => SetProperty(ref _sName238_393, value);
        }

        private int? _iPlan238_394;
        [DbColumn("iPlan238_394")]
        [DisplayName("iPlan238_394")]
        public int? iPlan238_394
        {
            get => _iPlan238_394;
            set => SetProperty(ref _iPlan238_394, value);
        }

        private string _sScNo239_395;
        [DbColumn("sScNo239_395")]
        [DisplayName("sScNo239_395")]
        public string sScNo239_395
        {
            get => _sScNo239_395;
            set => SetProperty(ref _sScNo239_395, value);
        }

        private string _sScDv239_396;
        [DbColumn("sScDv239_396")]
        [DisplayName("sScDv239_396")]
        public string sScDv239_396
        {
            get => _sScDv239_396;
            set => SetProperty(ref _sScDv239_396, value);
        }

        private int? _iCode239_397;
        [DbColumn("iCode239_397")]
        [DisplayName("iCode239_397")]
        public int? iCode239_397
        {
            get => _iCode239_397;
            set => SetProperty(ref _iCode239_397, value);
        }

        private string _sName239_398;
        [DbColumn("sName239_398")]
        [DisplayName("sName239_398")]
        public string sName239_398
        {
            get => _sName239_398;
            set => SetProperty(ref _sName239_398, value);
        }

        private int? _iPlan239_399;
        [DbColumn("iPlan239_399")]
        [DisplayName("iPlan239_399")]
        public int? iPlan239_399
        {
            get => _iPlan239_399;
            set => SetProperty(ref _iPlan239_399, value);
        }

        private string _sScNo240_400;
        [DbColumn("sScNo240_400")]
        [DisplayName("sScNo240_400")]
        public string sScNo240_400
        {
            get => _sScNo240_400;
            set => SetProperty(ref _sScNo240_400, value);
        }

        private string _sScDv240_401;
        [DbColumn("sScDv240_401")]
        [DisplayName("sScDv240_401")]
        public string sScDv240_401
        {
            get => _sScDv240_401;
            set => SetProperty(ref _sScDv240_401, value);
        }

        private int? _iCode240_402;
        [DbColumn("iCode240_402")]
        [DisplayName("iCode240_402")]
        public int? iCode240_402
        {
            get => _iCode240_402;
            set => SetProperty(ref _iCode240_402, value);
        }

        private string _sName240_403;
        [DbColumn("sName240_403")]
        [DisplayName("sName240_403")]
        public string sName240_403
        {
            get => _sName240_403;
            set => SetProperty(ref _sName240_403, value);
        }

        private int? _iPlan240_404;
        [DbColumn("iPlan240_404")]
        [DisplayName("iPlan240_404")]
        public int? iPlan240_404
        {
            get => _iPlan240_404;
            set => SetProperty(ref _iPlan240_404, value);
        }

        private int? _iBasketCount1_405;
        [DbColumn("iBasketCount1_405")]
        [DisplayName("iBasketCount1_405")]
        public int? iBasketCount1_405
        {
            get => _iBasketCount1_405;
            set => SetProperty(ref _iBasketCount1_405, value);
        }

        private int? _iChuteCount1_406;
        [DbColumn("iChuteCount1_406")]
        [DisplayName("iChuteCount1_406")]
        public int? iChuteCount1_406
        {
            get => _iChuteCount1_406;
            set => SetProperty(ref _iChuteCount1_406, value);
        }

        private int? _iBasketCount2_407;
        [DbColumn("iBasketCount2_407")]
        [DisplayName("iBasketCount2_407")]
        public int? iBasketCount2_407
        {
            get => _iBasketCount2_407;
            set => SetProperty(ref _iBasketCount2_407, value);
        }

        private int? _iChuteCount2_408;
        [DbColumn("iChuteCount2_408")]
        [DisplayName("iChuteCount2_408")]
        public int? iChuteCount2_408
        {
            get => _iChuteCount2_408;
            set => SetProperty(ref _iChuteCount2_408, value);
        }

        private int? _iPower01_409;
        [DbColumn("iPower01_409")]
        [DisplayName("iPower01_409")]
        public int? iPower01_409
        {
            get => _iPower01_409;
            set => SetProperty(ref _iPower01_409, value);
        }

        private int? _iPower02_410;
        [DbColumn("iPower02_410")]
        [DisplayName("iPower02_410")]
        public int? iPower02_410
        {
            get => _iPower02_410;
            set => SetProperty(ref _iPower02_410, value);
        }

        private string _sContent_411;
        [DbColumn("sContent_411")]
        [DisplayName("sContent_411")]
        public string sContent_411
        {
            get => _sContent_411;
            set => SetProperty(ref _sContent_411, value);
        }

    }

}
