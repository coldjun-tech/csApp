﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace cnData
{
    /* ---------------------------------------------------------------------------------------------- *
     * 설명  : - 외부에서 제네릭 타입 T를 몰라도 UI 바인딩(DataSource) 및 항목 조작 가능하도록 Interface 로 구현
     *         - 외부에서 사용할 함수는 여기에서 정의
     * TO_DO : 
     * ---------------------------------------------------------------------------------------------- *
     *   일  자   | 개발자 | 작  업  내  용
     * ---------------------------------------------------------------------------------------------- *
     * 2026.11.24 |        | 초기개발
     * ---------------------------------------------------------------------------------------------- */
    public interface IBaseRepository<T> where T : class
    {   
        T DataRowToModel(DataRow aRow);
        void Insert(T item);
        void Update(T item);
        void Delete(T item);
    }

    /* ---------------------------------------------------------------------------------------------- *
     * 설명  : - MVVM 모델에서 추가로 Repository class 를 추가했음.
     *         - DataTable 에서 데이터를 List 로 만들고, 조회, 수정, 삭제, 저장 기능을 수행
     *         - 상위 class 는 기능을 명확히 설명하기 위해서 Repository 명칭을 그대로 사용
     *         - 하위 class 는 화면에서 사용시 편리하게 하기 위해서 Repository -> Repo 로 명칭을 수정
     * TO_DO : 
     * ---------------------------------------------------------------------------------------------- *
     *   일  자   | 개발자 | 작  업  내  용
     * ---------------------------------------------------------------------------------------------- *
     * 2026.11.24 |        | 초기개발
     * ---------------------------------------------------------------------------------------------- */
    public class TRepoInspData : IBaseRepository<TModel_InspData>
    {
        public TModel_InspData DataRowToModel(DataRow aRow)
        {
            return new TModel_InspData
            {
                OrderNo = aRow["OrderNo"].ToString(),
                OrderSeq = Convert.ToInt32(aRow["OrderSeq"]),
                CustCode = aRow["CustCode"].ToString(),
                ProcStat = aRow["ProcStat"].ToString(),

                ItemNo = aRow["ItemNo"].ToString(),
                Plant = aRow["Plant"].ToString(),
                Maker = aRow["Maker"].ToString(),
                SetPress = aRow["SetPress"].ToString(),
                BackPress = aRow["BackPress"].ToString(),
                CDS = aRow["CDS"].ToString(),
                Unit = aRow["Unit"].ToString(),
                Inlet = aRow["Inlet"].ToString(),
                Outlet = aRow["Outlet"].ToString(),
                Fluid = aRow["Fluid"].ToString(),
                Capct = aRow["Capct"].ToString(),
                CapctUnit = aRow["CapctUnit"].ToString(),
                Model = aRow["Model"].ToString(),
                Type = aRow["Type"].ToString(),
                Serial = aRow["Serial"].ToString(),
                TestFluid = aRow["TestFluid"].ToString(),
                ChkCap = aRow["ChkCap"].ToString(),
                ChkBonnet = aRow["ChkBonnet"].ToString(),
                ChkBody = aRow["ChkBody"].ToString(),
                ChkNozz = aRow["ChkNozz"].ToString(),
                ChkNozzSeat = aRow["ChkNozzSeat"].ToString(),
                ChkDisc = aRow["ChkDisc"].ToString(),
                ChkDiscSeat = aRow["ChkDiscSeat"].ToString(),
                ChkBellows = aRow["ChkBellows"].ToString(),
                ChkSpring = aRow["ChkSpring"].ToString(),
                ChkSpindle = aRow["ChkSpindle"].ToString(),
                ChkLowRing = aRow["ChkLowRing"].ToString(),
                ChkUppRing = aRow["ChkUppRing"].ToString(),
                PressVals1 = aRow["PressVals1"].ToString(),
                PressVals2 = aRow["PressVals2"].ToString()
            };
        }

        public void Insert(TModel_InspData aItem)
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Clear();
            sbQuery.Append("INSERT INTO tb_insp_data ( ");
            sbQuery.Append(" OrderNo, OrderSeq, TestDate, CustCode, ItemNo, Plant, Inlet, Outlet, Capct, CapctUnit");
            sbQuery.Append(", Fluid, Maker, Type, SetPress, BackPress, CDS, Unit, BodyMatl, DiscMatl");
            sbQuery.Append(", ChkCap, ChkBonnet, ChkBody, ChkNozz, ChkNozzSeat, ChkDisc, ChkDiscSeat, ChkBellows, ChkSpring, ChkSpindle, ChkLowRing, ChkUppRing");
            sbQuery.Append(", ProcStat, Model, Serial, TestFluid, TestRslt, PoppPress1, ClosPress1, PoppPress2, ClosPress2, InspRemk, PressVals1, PressVals2, PressChtImg");
            sbQuery.Append(" ) VALUES ( ");
            sbQuery.Append(" @OrderNo, @OrderSeq, @TestDate, @CustCode, @ItemNo, @Plant, @Inlet, @Outlet, @Capct, @CapctUnit");
            sbQuery.Append(", @Fluid, @Maker, @Type, @SetPress, @BackPress, @CDS, @Unit, @BodyMatl, @DiscMatl");
            sbQuery.Append(", @ChkCap, @ChkBonnet, @ChkBody, @ChkNozz, @ChkNozzSeat, @ChkDisc, @ChkDiscSeat, @ChkBellows, @ChkSpring, @ChkSpindle, @ChkLowRing, @ChkUppRing");
            sbQuery.Append(", @ProcStat, @Model, @Serial, @TestFluid, @TestRslt, @PoppPress1, @ClosPress1, @PoppPress2, @ClosPress2, @InspRemk, @PressVals1, @PressVals2, @PressChtImg );");

            TDataParam[] vParams = new TDataParam[] {
                new TDataParam("@OrderNo", MySqlDbType.String, aItem.OrderNo),
                new TDataParam("@OrderSeq", MySqlDbType.Int32, aItem.OrderSeq),
                new TDataParam("@ProcStat", MySqlDbType.String, aItem.ProcStat),
                new TDataParam("@TestDate", MySqlDbType.DateTime, aItem.TestDate),
                new TDataParam("@CustCode", MySqlDbType.String, aItem.CustCode),
                new TDataParam("@ItemNo", MySqlDbType.String, aItem.ItemNo),
                new TDataParam("@Plant", MySqlDbType.String, aItem.Plant),
                new TDataParam("@Inlet", MySqlDbType.String, aItem.Inlet),
                new TDataParam("@Outlet", MySqlDbType.String, aItem.Outlet),
                new TDataParam("@Capct", MySqlDbType.String, aItem.Capct),
                new TDataParam("@CapctUnit", MySqlDbType.String, aItem.CapctUnit),
                new TDataParam("@Fluid", MySqlDbType.String, aItem.Fluid),
                new TDataParam("@Maker", MySqlDbType.String, aItem.Maker),
                new TDataParam("@Model", MySqlDbType.String, aItem.Model),
                new TDataParam("@Serial", MySqlDbType.String, aItem.Serial),
                new TDataParam("@Type", MySqlDbType.String, aItem.Type),
                new TDataParam("@SetPress", MySqlDbType.String, aItem.SetPress),
                new TDataParam("@BackPress", MySqlDbType.String, aItem.BackPress),
                //new TDataParameter("@TestPress", MySqlDbType.String, edtest.EditValue),
                new TDataParam("@CDS", MySqlDbType.String, aItem.CDS),
                new TDataParam("@Unit", MySqlDbType.String, aItem.Unit),
                new TDataParam("@TestFluid", MySqlDbType.String, aItem.TestFluid),
                new TDataParam("@TestRslt", MySqlDbType.String, aItem.TestRslt),
                new TDataParam("@BodyMatl", MySqlDbType.String, aItem.BodyMatl),
                new TDataParam("@DiscMatl", MySqlDbType.String, aItem.DiscMatl),
                new TDataParam("@PoppPress1", MySqlDbType.String, aItem.PoppPress1),
                new TDataParam("@ClosPress1", MySqlDbType.String, aItem.ClosPress1),
                new TDataParam("@PoppPress2", MySqlDbType.String, aItem.PoppPress2),
                new TDataParam("@ClosPress2", MySqlDbType.String, aItem.ClosPress2),
                new TDataParam("@ChkCap", MySqlDbType.String, aItem.ChkCap),
                new TDataParam("@ChkBonnet", MySqlDbType.String, aItem.ChkBonnet),
                new TDataParam("@ChkBody", MySqlDbType.String, aItem.ChkBody),
                new TDataParam("@ChkNozz", MySqlDbType.String, aItem.ChkNozz),
                new TDataParam("@ChkNozzSeat", MySqlDbType.String, aItem.ChkNozzSeat),
                new TDataParam("@ChkDisc", MySqlDbType.String, aItem.ChkDisc),
                new TDataParam("@ChkDiscSeat", MySqlDbType.String, aItem.ChkDiscSeat),
                new TDataParam("@ChkBellows", MySqlDbType.String, aItem.ChkBellows),
                new TDataParam("@ChkSpring", MySqlDbType.String, aItem.ChkSpring),
                new TDataParam("@ChkSpindle", MySqlDbType.String, aItem.ChkSpindle),
                new TDataParam("@ChkLowRing", MySqlDbType.String, aItem.ChkLowRing),
                new TDataParam("@ChkUppRing", MySqlDbType.String, aItem.ChkUppRing),
                new TDataParam("@InspRemk", MySqlDbType.String, aItem.InspRemk),
                new TDataParam("@PressVals1", MySqlDbType.String, GetPressValues(aItem.PresValues1, aItem.PressVals1)),
                new TDataParam("@PressVals2", MySqlDbType.String, GetPressValues(aItem.PresValues2, aItem.PressVals2)),
                new TDataParam("@PressChtImg", MySqlDbType.Blob, aItem.PresChtImg)
            };

            TDataMySql.SetDataCommand(sbQuery.ToString(), vParams);
        }

        public void Delete(TModel_InspData aItem)
        {
            string sQuery = @"DELETE FROM tb_insp_data WHERE OrderNo = @OrderNo AND OrderSeq = @OrderSeq";

            TDataMySql.SetDataCommand(
                sQuery,
                new TDataParam("@OrderNo", MySqlDbType.VarChar, aItem.OrderNo),
                new TDataParam("@OrderSeq", MySqlDbType.Int32, aItem.OrderSeq)
            );
        }

        public void Update(TModel_InspData aItem)
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Clear();
            sbQuery.Append("UPDATE tb_insp_data SET ");
            sbQuery.Append("   ProcStat = @ProcStat");
            sbQuery.Append(", TestDate = @TestDate");
            sbQuery.Append(", CustCode = @CustCode");
            sbQuery.Append(", ItemNo = @ItemNo");
            sbQuery.Append(", Plant = @Plant");
            sbQuery.Append(", Inlet = @Inlet");
            sbQuery.Append(", Outlet = @Outlet");
            sbQuery.Append(", Capct = @Capct");
            sbQuery.Append(", CapctUnit = @CapctUnit");
            sbQuery.Append(", Fluid = @Fluid");
            sbQuery.Append(", Maker = @Maker");
            sbQuery.Append(", Model = @Model");
            sbQuery.Append(", Serial = @Serial");
            sbQuery.Append(", Type = @Type");
            sbQuery.Append(", SetPress = @SetPress");
            sbQuery.Append(", BackPress = @BackPress");
            sbQuery.Append(", CDS = @CDS");
            sbQuery.Append(", Unit = @Unit");
            sbQuery.Append(", TestFluid = @TestFluid");
            sbQuery.Append(", TestRslt = @TestRslt");
            sbQuery.Append(", BodyMatl = @BodyMatl");
            sbQuery.Append(", DiscMatl = @DiscMatl");
            sbQuery.Append(", PoppPress1 = @PoppPress1");
            sbQuery.Append(", ClosPress1 = @ClosPress1");
            sbQuery.Append(", PoppPress2 = @PoppPress2");
            sbQuery.Append(", ClosPress2 = @ClosPress2");
            sbQuery.Append(", ChkCap = @ChkCap");
            sbQuery.Append(", ChkBonnet = @ChkBonnet");
            sbQuery.Append(", ChkBody = @ChkBody");
            sbQuery.Append(", ChkNozz = @ChkNozz");
            sbQuery.Append(", ChkNozzSeat = @ChkNozzSeat");
            sbQuery.Append(", ChkDisc = @ChkDisc");
            sbQuery.Append(", ChkDiscSeat = @ChkDiscSeat");
            sbQuery.Append(", ChkBellows = @ChkBellows");
            sbQuery.Append(", ChkSpring = @ChkSpring");
            sbQuery.Append(", ChkSpindle = @ChkSpindle");
            sbQuery.Append(", ChkLowRing = @ChkLowRing");
            sbQuery.Append(", ChkUppRing = @ChkUppRing");
            sbQuery.Append(", InspRemk = @InspRemk");
            sbQuery.Append(", PressVals1 = @PressVals1");
            sbQuery.Append(", PressVals2 = @PressVals2");
            sbQuery.Append(", PressChtImg = @PressChtImg");
            sbQuery.Append(" WHERE OrderNo = @OrderNo");
            sbQuery.Append("   AND OrderSeq = @OrderSeq");

            TDataParam[] vParams = new TDataParam[] {
                new TDataParam("@OrderNo", MySqlDbType.String, aItem.OrderNo),
                new TDataParam("@OrderSeq", MySqlDbType.Int32, aItem.OrderSeq),
                new TDataParam("@ProcStat", MySqlDbType.String, aItem.ProcStat),
                new TDataParam("@TestDate", MySqlDbType.DateTime, aItem.TestDate),
                new TDataParam("@CustCode", MySqlDbType.String, aItem.CustCode),
                new TDataParam("@ItemNo", MySqlDbType.String, aItem.ItemNo),
                new TDataParam("@Plant", MySqlDbType.String, aItem.Plant),
                new TDataParam("@Inlet", MySqlDbType.String, aItem.Inlet),
                new TDataParam("@Outlet", MySqlDbType.String, aItem.Outlet),
                new TDataParam("@Capct", MySqlDbType.String, aItem.Capct),
                new TDataParam("@CapctUnit", MySqlDbType.String, aItem.CapctUnit),
                new TDataParam("@Fluid", MySqlDbType.String, aItem.Fluid),
                new TDataParam("@Maker", MySqlDbType.String, aItem.Maker),
                new TDataParam("@Model", MySqlDbType.String, aItem.Model),
                new TDataParam("@Serial", MySqlDbType.String, aItem.Serial),
                new TDataParam("@Type", MySqlDbType.String, aItem.Type),
                new TDataParam("@SetPress", MySqlDbType.String, aItem.SetPress),
                new TDataParam("@BackPress", MySqlDbType.String, aItem.BackPress),
                //new TDataParameter("@TestPress", MySqlDbType.String, edtest.EditValue),
                new TDataParam("@CDS", MySqlDbType.String, aItem.CDS),
                new TDataParam("@Unit", MySqlDbType.String, aItem.Unit),
                new TDataParam("@TestFluid", MySqlDbType.String, aItem.TestFluid),
                new TDataParam("@TestRslt", MySqlDbType.String, aItem.TestRslt),
                new TDataParam("@BodyMatl", MySqlDbType.String, aItem.BodyMatl),
                new TDataParam("@DiscMatl", MySqlDbType.String, aItem.DiscMatl),
                new TDataParam("@PoppPress1", MySqlDbType.String, aItem.PoppPress1),
                new TDataParam("@ClosPress1", MySqlDbType.String, aItem.ClosPress1),
                new TDataParam("@PoppPress2", MySqlDbType.String, aItem.PoppPress2),
                new TDataParam("@ClosPress2", MySqlDbType.String, aItem.ClosPress2),
                new TDataParam("@ChkCap", MySqlDbType.String, aItem.ChkCap),
                new TDataParam("@ChkBonnet", MySqlDbType.String, aItem.ChkBonnet),
                new TDataParam("@ChkBody", MySqlDbType.String, aItem.ChkBody),
                new TDataParam("@ChkNozz", MySqlDbType.String, aItem.ChkNozz),
                new TDataParam("@ChkNozzSeat", MySqlDbType.String, aItem.ChkNozzSeat),
                new TDataParam("@ChkDisc", MySqlDbType.String, aItem.ChkDisc),
                new TDataParam("@ChkDiscSeat", MySqlDbType.String, aItem.ChkDiscSeat),
                new TDataParam("@ChkBellows", MySqlDbType.String, aItem.ChkBellows),
                new TDataParam("@ChkSpring", MySqlDbType.String, aItem.ChkSpring),
                new TDataParam("@ChkSpindle", MySqlDbType.String, aItem.ChkSpindle),
                new TDataParam("@ChkLowRing", MySqlDbType.String, aItem.ChkLowRing),
                new TDataParam("@ChkUppRing", MySqlDbType.String, aItem.ChkUppRing),
                new TDataParam("@InspRemk", MySqlDbType.String, aItem.InspRemk),
                new TDataParam("@PressVals1", MySqlDbType.String, GetPressValues(aItem.PresValues1, aItem.PressVals1)),
                new TDataParam("@PressVals2", MySqlDbType.String, GetPressValues(aItem.PresValues2, aItem.PressVals2)),
                new TDataParam("@PressChtImg", MySqlDbType.Blob, aItem.PresChtImg)
            };

            TDataMySql.SetDataCommand(sbQuery.ToString(), vParams);
        }

        //private static void ExecuteSave(string asQuery, params TDataParam[] aParams)
        //{
        //    if (string.IsNullOrWhiteSpace(asQuery))
        //        throw new ArgumentException("실행할 SQL이 없습니다.", nameof(asQuery));

        //    if (aParams == null)
        //        throw new ArgumentNullException(nameof(aParams));

        //    // 원본 매개변수를 유지하면서 null을 DB NULL로 변환합니다.
        //    TDataParam[] parameters = aParams.Select(param =>
        //        new TDataParam(param.ParamName, param.ParamType,
        //            param.ParamValue ?? DBNull.Value)).ToArray();

        //    // DB 예외는 호출자에게 전달합니다.
        //    TDataMySql.SetDataCommand(asQuery, parameters);
        //}

        private static string GetPressValues(List<double> values, string stored)
        {
            return values != null && values.Count > 0 ?
                string.Join(",", values.Select(value => value.ToString(System.Globalization.CultureInfo.InvariantCulture))) : stored;
        }

    } // class TRepoInspData
}
