﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZstdSharp.Unsafe;

namespace cnData
{
    // UI에서 메시지 표시나 ErrorProvider 처리에 사용할 검증 결과
    public sealed class TDataValidationError
    {
        public string PropName { get; }
        public string ErrorMsg { get; }

        public TDataValidationError(string asPropName, string asErrorMsg)
        {
            PropName = asPropName;
            ErrorMsg = asErrorMsg;
        }
    }

    public sealed class TDataValidationResult
    {
        public IReadOnlyList<TDataValidationError> Errors { get; }
        public bool IsValid => Errors.Count == 0;
        public string Message => string.Join(Environment.NewLine, Errors.Select(error => error.ErrorMsg));

        public TDataValidationResult(IEnumerable<TDataValidationError> errors)
        {
            if (errors == null)
                throw new ArgumentNullException(nameof(errors));

            Errors = new List<TDataValidationError>(errors).AsReadOnly();
        }
    }

    /* ---------------------------------------------------------------------------------------------- *
     * 설명  : - MVVM 모델에서 ViewModel 역할
     *         - 화면 상태, 데이터검증 및 Repository 호출 흐름 관리
     * TO_DO : 
     * ---------------------------------------------------------------------------------------------- *
     *   일  자   | 개발자 | 작  업  내  용
     * ---------------------------------------------------------------------------------------------- *
     * 2026.11.24 |        | 초기개발
     * ---------------------------------------------------------------------------------------------- */
    public abstract class TBaseViewModel<T> where T : class
    {
        //public event PropertyChangedEventHandler PropertyChanged;

        //protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        //{
        //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        //}
        public bool IsInsert { get; protected set; }

        public BindingList<T> Items { get; } = new BindingList<T>();

        public TDataValidationResult ValidateInsert(T item) => Validate(item, true);
        public TDataValidationResult ValidateUpdate(T item) => Validate(item, false);

        private TDataValidationResult Validate(T item, bool isInsert)
        {
            var errors = new List<TDataValidationError>();
            if (item == null)
                errors.Add(new TDataValidationError(string.Empty, "검증할 데이터가 없습니다."));
            else
                ValidateCore(item, isInsert, errors);

            return new TDataValidationResult(errors);
        }
        // 공통 규칙과 추가/수정별 규칙은 하위 ViewModel에서 정의
        protected abstract void ValidateCore(T aItem, bool aIsInsert, List<TDataValidationError> aErrs);

        protected abstract T DataRowToModel(DataRow row);
        public void ToList(DataTable aDataTable)
        {
            Items.Clear();
            if (aDataTable == null || aDataTable.Rows.Count == 0)
                return;

            // UI 갱신 이벤트 일시 중지 (성능 최적화)
            Items.RaiseListChangedEvents = false;
            try
            {
                foreach (DataRow row in aDataTable.Rows)
                {
                    T model = DataRowToModel(row);
                    if (model != null)
                    {
                        Items.Add(model);
                    }
                }
            }
            finally
            {
                Items.RaiseListChangedEvents = true;
                Items.ResetBindings(); // UI에 일괄 반영
            }
        }

        //public async Task ToListAsync(DataTable aDataTable)
        //{
        //    if (aDataTable == null || aDataTable.Rows.Count == 0)
        //        return;

        //    // 원본 데이터와 분리하여 백그라운드에서 변환
        //    using (DataTable snapshot = aDataTable.Copy())
        //    {
        //        List<T> models = await Task.Run(() =>
        //            snapshot.Rows.Cast<DataRow>()
        //                .Select(DataRowToModel)
        //                .Where(model => model != null)
        //                .ToList());

        //        // UI 스레드에서 목록에 반영
        //        bool previous = Items.RaiseListChangedEvents;
        //        Items.RaiseListChangedEvents = false;

        //        try
        //        {
        //            foreach (T model in models)
        //                Items.Add(model);
        //        }
        //        finally
        //        {
        //            Items.RaiseListChangedEvents = previous;

        //            if (previous)
        //                Items.ResetBindings();
        //        }
        //    }
        //}

        public void Clear() => Items.Clear();

        public abstract void BeforeInsert();
        public abstract TDataValidationResult Insert(T item);
        public abstract TDataValidationResult Delete(T item);
        public abstract TDataValidationResult Update(T item);
    }

    public class TViewModel_InspData : TBaseViewModel<TModel_InspData>
    {
        private readonly TRepoInspData _repoInspData = new TRepoInspData();
        public TModel_InspData EditItem { get; private set; }

        protected override void ValidateCore(TModel_InspData aItem, bool aIsInsert, List<TDataValidationError> aErrs)
        {
            if (string.IsNullOrWhiteSpace(aItem.OrderNo))
                aErrs.Add(new TDataValidationError(nameof(aItem.OrderNo), "발주번호를 입력하세요."));

            // 현재 화면에서 사용하는 시작 순번(1)을 기준으로 검사
            if (aItem.OrderSeq < 1)
                aErrs.Add(new TDataValidationError(nameof(aItem.OrderSeq), "발주순번은 1 이상이어야 합니다."));

            //if (aIsInsert && aItem.Any(aItem => aItem.OrderNo == aItem.OrderNo && item.OrderSeq == aItem.OrderSeq))
            //    aErrs.Add(new TDataValidationError(nameof(aItem.OrderSeq), "동일한 발주번호와 발주순번이 목록에 있습니다."));

            if (aIsInsert)
            {
                //if (SelectedItem == null)
                //    aErrs.Add(new TDataValidationError(string.Empty, "수정할 데이터를 선택하세요."));
                //else if (aItem.OrderNo != SelectedItem.OrderNo || aItem.OrderSeq != SelectedItem.OrderSeq)
                //    aErrs.Add(new TDataValidationError(nameof(aItem.OrderNo), "기존 데이터의 발주번호와 발주순번은 변경할 수 없습니다."));
            }
            else
            {

            }
        }

        //IBaseRepository<TModel_InspData> repository = new TRepoInspData();
        //TModel_InspData model = repository.DataRowToModel(row);
        protected override TModel_InspData DataRowToModel(DataRow aRow)
        {
            IsInsert = false;
            return _repoInspData.DataRowToModel(aRow);
        }

        public override void BeforeInsert()
        {
            //MessageBox.Show("BeforeInsert");
            IsInsert = true;
            EditItem = new TModel_InspData
            {
                OrderNo = string.Empty,
                OrderSeq = 100,
                TestDate = DateTime.Today
            };
            //Items.Add(EditItem);
        }

        public override TDataValidationResult Insert(TModel_InspData item)
        {
            TDataValidationResult result = ValidateInsert(item);

            if (!result.IsValid) return result;

            _repoInspData.Insert(item);

            return result;
        }

        public override TDataValidationResult Delete(TModel_InspData item)
        {
            TDataValidationResult result = ValidateInsert(item);

            if (!result.IsValid) return result;

            _repoInspData.Delete(item);

            return result;
        }

        public override TDataValidationResult Update(TModel_InspData aItem)
        {
            TDataValidationResult result = ValidateInsert(aItem);

            if (!result.IsValid) return result;

            _repoInspData.Update(aItem);

            return result;
        }

    } // class TViewModel_InspData
}
