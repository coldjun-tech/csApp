using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Reflection;

using MySql.Data.MySqlClient;

namespace cnData
{
    public class TDataParam
    {
        public string ParamName { get; set; }
        public MySqlDbType ParamType { get; set; }
        public object ParamValue { get; set; }

        public TDataParam(string asParamName, MySqlDbType aParamType, object aParamValue)
        {
            ParamName = asParamName;
            ParamType = aParamType;
            ParamValue = aParamValue;
        }

        ~TDataParam()
        {
            //
        }
    }

    public static class TDataMySql
    {
        public static string _CONN_STR = "server=127.0.0.1;user=root;database=tdd_db;port=3306;password=1122qqww;allow user variables=true";

        static TDataMySql()
        {
            //
        }

        //public static DataTable SetData(string procedureName, params string[] args)
        //{
        //  DataTable vData = new DataTable();

        //  SqlTransaction tran = null;
        //  SqlConnection conn = null;

        //  try
        //  {
        //    conn = new SqlConnection(TDataMySql._CONN_STR);
        //    conn.Open();

        //    SqlCommand cmd = new SqlCommand();
        //    cmd.Connection = conn;
        //    cmd.CommandTimeout = 60 * 30;
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.CommandText = procedureName;
        //    SqlParameter sp;

        //    tran = conn.BeginTransaction();
        //    cmd.Transaction = tran;
        //    cmd.ExecuteNonQuery();
        //    tran.Commit();
        //    conn.Close();

        //    object obj = null;
        //    for (int i = 0; i < cmd.Parameters.Count; i++)
        //    {
        //      if (cmd.Parameters[i].Direction == ParameterDirection.Output)
        //      {
        //        obj = cmd.Parameters[i].Value;
        //        break;
        //      }
        //    }
        //    //DataTable.isError = false;
        //    //DataTable.ResultValue = UtilClass.toStr(obj);
        //  }
        //  catch (SqlException se)
        //  {
        //    //vdata.isError = true;
        //    //vdata.ResultValue = se.Message;

        //    if (tran != null)
        //    {
        //      tran.Rollback();
        //    }
        //    if (conn != null)
        //    {
        //      conn.Close();
        //    }
        //  }
        //  catch (Exception ex)
        //  {
        //    //vdata.isError = true;
        //    //vdata.ResultValue = ex.Message;

        //    if (tran != null)
        //    {
        //      tran.Rollback();
        //    }
        //    if (conn != null)
        //    {
        //      conn.Close();
        //    }
        //  }

        //  return vData;
        //}

        //public static DataTable SetDataTable(string procedureName, DataTable[] dataList, params string[] args)
        //{
        //  DataTable data = new DataTable();
        //  SqlTransaction tran = null;
        //  SqlConnection conn = null;

        //  try
        //  {
        //    conn = new SqlConnection(TDataMySql._CONN_STR);
        //    conn.Open();

        //    SqlCommand cmd = new SqlCommand();
        //    cmd.Connection = conn;
        //    cmd.CommandTimeout = 60 * 30;
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.CommandText = procedureName;
        //    SqlParameter sp;
        //    if (dataList != null && dataList.Length > 0)
        //    {
        //      for (int i = 0; i < dataList.Length; i++)
        //      {
        //        sp = new SqlParameter();
        //        sp.ParameterName = "@" + dataList[i].TableName;
        //        sp.Direction = ParameterDirection.Input;
        //        sp.Value = dataList[i];
        //        cmd.Parameters.Add(sp);
        //      }
        //    }

        //    tran = conn.BeginTransaction();
        //    cmd.Transaction = tran;
        //    cmd.ExecuteNonQuery();
        //    tran.Commit();
        //    conn.Close();

        //    object obj = null;

        //    for (int i = 0; i < cmd.Parameters.Count; i++)
        //    {
        //      if (cmd.Parameters[i].Direction == ParameterDirection.Output)
        //      {
        //        obj = cmd.Parameters[i].Value;
        //        break;
        //      }
        //    }
        //  }
        //  catch (SqlException se)
        //  {
        //    if (tran != null)
        //    {
        //      tran.Rollback();
        //    }
        //    if (conn != null)
        //    {
        //      conn.Close();
        //    }
        //  }
        //  catch (Exception ex)
        //  {
        //    if (tran != null)
        //    {
        //      tran.Rollback();
        //    }
        //    if (conn != null)
        //    {
        //      conn.Close();
        //    }
        //  }
        //  return data;
        //}

        public static DataTable GetDataTable(string asQuery, params TDataParam[] aParams)
        {
            DataTable datResult = new DataTable();

            using (MySqlConnection conn = new MySqlConnection(TDataMySql._CONN_STR))
            {
                try
                {
                    MySqlCommand cmd = new MySqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 60 * 30;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = asQuery;

                    foreach (TDataParam vParam in aParams)
                    {
                        cmd.Parameters.Add(vParam.ParamName, vParam.ParamType).Value = vParam.ParamValue;
                    }

                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataSet dataSet = new DataSet();
                    adapter.Fill(dataSet);
                    if (dataSet.Tables.Count < 1)
                    {
                        throw new Exception("���ǿ� �����ϴ� �����Ͱ� �����ϴ�.");
                    }
                    else
                    {
                        datResult = dataSet.Tables[0];
                    }
                    conn.Close();
                }
                catch (Exception ex)
                {
                    if (conn != null)
                    {
                        conn.Close();
                    }
                    //throw new Exception(ex.Message);
                    throw;
                }
                return datResult;
            }
        }

        public static DataTable GetDataTable(string asQuery, List<TDataParam> aParams)
        {
            DataTable datResult = new DataTable();

            using (MySqlConnection conn = new MySqlConnection(TDataMySql._CONN_STR))
            using (MySqlCommand cmd = new MySqlCommand())
            {
                try
                {
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 60;
                    cmd.CommandType = CommandType.Text;

                    // aParams�� null���� �����ϰ� Ȯ��
                    if (aParams != null && aParams.Count > 0)
                    {
                        bool isFirst = true;

                        foreach (TDataParam vParam in aParams)
                        {
                            if (isFirst)
                            {
                                asQuery += $" WHERE {vParam.ParamName} = @{vParam.ParamName}";
                                isFirst = false;
                            }
                            else
                            {
                                asQuery += $" AND {vParam.ParamName} = @{vParam.ParamName}";
                            }
                            cmd.Parameters.Add("@" + vParam.ParamName, vParam.ParamType).Value = vParam.ParamValue;
                        }
                    }
                    cmd.CommandText = asQuery;

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(cmd))
                    {
                        adapter.Fill(datResult);
                    }

                    if (datResult.Rows.Count == 0)
                    {
                        throw new Exception("���ǿ� �����ϴ� �����Ͱ� �����ϴ�.");
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
            }

            return datResult;
        }

        public static DataRow GetDataRow(string asQuery, params string[] args)
        {
            DataTable datResult = new DataTable();

            using (MySqlConnection conn = new MySqlConnection(TDataMySql._CONN_STR))
            using (MySqlCommand cmd = new MySqlCommand())
            {
                try
                {
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 60;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = asQuery;

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(cmd))
                    {
                        adapter.Fill(datResult);
                    }

                    if (datResult.Rows.Count == 0)
                    {
                        throw new Exception("���ǿ� �����ϴ� �����Ͱ� �����ϴ�.");
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
            }

            return datResult.Rows[0];
        }

        // Transaction �� ����ϴ� ��쿡 ����ϴ� �Լ�
        public static void SetDataCommand(MySqlConnection aConn, string asQuery, params TDataParam[] aParams)
        {
            using (MySqlCommand cmd = new MySqlCommand())
            {
                try
                {
                    cmd.Connection = aConn;
                    cmd.CommandTimeout = 60 * 30; // 30��
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = asQuery;

                    foreach (TDataParam vParam in aParams)
                    {
                        cmd.Parameters.Add(vParam.ParamName, vParam.ParamType).Value = vParam.ParamValue;
                    }

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }

        public static void SetDataCommand(string asQuery, params TDataParam[] aParams)
        {
            using (MySqlConnection conn = new MySqlConnection(TDataMySql._CONN_STR))
            using (MySqlCommand cmd = new MySqlCommand())
            {
                try
                {
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 60 * 30; // 30��
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = asQuery;

                    foreach (TDataParam vParam in aParams)
                    {
                        cmd.Parameters.Add(vParam.ParamName, vParam.ParamType).Value = vParam.ParamValue;
                    }
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }

        public static void SetDataCommand(string asQuery, List<TDataParam> aParams)
        {
            using (MySqlConnection conn = new MySqlConnection(TDataMySql._CONN_STR))
            using (MySqlCommand cmd = new MySqlCommand())
            {
                try
                {
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 60 * 30; // 30��
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = asQuery;

                    foreach (TDataParam vParam in aParams)
                    {
                        cmd.Parameters.Add(vParam.ParamName, vParam.ParamType).Value = vParam.ParamValue;
                    }

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }

        public static void SetDataCommand<T>(string asTableName, T aModel) where T : class
        {
            if (aModel == null) return;

            using (MySqlConnection conn = new MySqlConnection(TDataMySql._CONN_STR))
            using (MySqlCommand cmd = new MySqlCommand())
            {
                try
                {
                    PropertyInfo[] props = typeof(T).GetProperties();

                    string sColumns = string.Join(", ", props.Select(p => p.Name));
                    string sParams = string.Join(", ", props.Select(p => "@" + p.Name));
                    string autoQuery = $"INSERT INTO {asTableName} ({sColumns}) VALUES ({sParams})";

                    cmd.Connection = conn;
                    cmd.CommandTimeout = 60 * 30; // 30��
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = autoQuery;

                    foreach (PropertyInfo prop in props)
                    {
                        string paramName = "@" + prop.Name;
                        object paramValue = prop.GetValue(aModel) ?? DBNull.Value;

                        cmd.Parameters.AddWithValue(paramName, paramValue);
                    }

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }

        public static bool CompareMD5String(string asPlainStr, string asEncryptedStr)
        {
            MySqlConnection con = new MySqlConnection(TDataMySql._CONN_STR);
            MySqlCommand cmd = new MySqlCommand();

            try
            {
                cmd.Connection = con;
                cmd.CommandTimeout = 60;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT IF (MD5('" + asPlainStr + "') = '" + asEncryptedStr + "', 'Y', 'N') AS comp_result;";

                con.Open();

                object scarValue = cmd.ExecuteScalar();
                scarValue = cmd.ExecuteScalar();
                con.Close();

                return (scarValue.ToString() == "Y");
            }
            catch (Exception ex)
            {
                return false;
                throw;
            }

        }

        public static string GetMD5String(string asPlainStr)
        {
            string sResult = "";
            MySqlConnection con = new MySqlConnection(TDataMySql._CONN_STR);
            MySqlCommand cmd = new MySqlCommand();

            try
            {
                cmd.Connection = con;
                cmd.CommandTimeout = 60;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT MD5('" + asPlainStr + "');";

                con.Open();

                object scarValue = cmd.ExecuteScalar();
                sResult = scarValue.ToString();

                con.Close();
            }
            catch (Exception ex)
            {
                return "";
                throw;
            }
            return sResult;
        }

        //private static object SafeConvert(object value, Type targetType)
        //{
        //    if (value == null || value == DBNull.Value) return null;

        //    Type underlyingType = Nullable.GetUnderlyingType(targetType) ?? targetType;
        //    string strVal = value.ToString().Trim();

        //    // ���� Ÿ���ε� DB�� ����("")�� ����ִ� ��� 0���� ó��
        //    if (string.IsNullOrEmpty(strVal) && underlyingType != typeof(string))
        //    {
        //        return Activator.CreateInstance(underlyingType);
        //    }

        //    return Convert.ChangeType(value, underlyingType);
        //}

        //public static List<T> MapDataTableToList<T>(DataTable aDataTable) where T : new()
        //{
        //    List<T> resultList = new List<T>();

        //    // GetDataTable ���� �� �� DataTable�� �Ѿ���Ƿ� ��� ó��
        //    if (aDataTable == null || aDataTable.Rows.Count == 0) return resultList;

        //    //Type masterType = typeof(T);
        //    //PropertyInfo[] props = masterType.GetProperties();
        //    PropertyInfo[] props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
        //    var vMapInfo = new List<KeyValuePair<PropertyInfo, string>>();

        //    foreach (PropertyInfo prop in props)
        //    {
        //        if (!prop.CanWrite) continue;

        //        string colName = prop.Name;
        //        object[] colAttrs = prop.GetCustomAttributes(typeof(DbColumnAttribute), true);
        //        if (colAttrs != null && colAttrs.Length > 0)
        //        {
        //            colName = ((DbColumnAttribute)colAttrs[0]).ColumnName;
        //        }

        //        // DataTable�� ������ �����ϴ� �÷��� ���� ��� �߰�
        //        if (aDataTable.Columns.Contains(colName))
        //        {
        //            vMapInfo.Add(new KeyValuePair<PropertyInfo, string>(prop, colName));
        //        }
        //    }

        //    foreach (DataRow row in aDataTable.Rows)
        //    {
        //        T vItem = new T();
        //        foreach (var vMap in vMapInfo)
        //        {
        //            object val = row[vMap.Value];
        //            if (val != DBNull.Value)
        //            {
        //                vMap.Key.SetValue(vItem, SafeConvert(val, vMap.Key.PropertyType), null);
        //            }
        //        }
        //        resultList.Add(vItem);
        //    }

        //    return resultList;
        //}

        // Json ����ȭ
        //public static string DataToJsonStr(Dictionary<string, int> aDicData)
        //{
        //    return JsonConvert.SerializeObject(aDicData, Newtonsoft.Json.Formatting.Indented);
        //    //JsonSerializer.Deserialize<Dictionary<string, object>>(jsonString);
        //    //string jsonString = System.Text.Json.JsonSerializer.Serialize(myDictionary);
        //}

    } // public class TDataMySql
}