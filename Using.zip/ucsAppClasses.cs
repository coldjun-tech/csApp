﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using cnData;
using cnIniFiles;

namespace lsa
{
    // App Event delegate
    //public delegate void DelChildFormShow(object sender, int psChildIndex);
    //public delegate void DelStatusMessageSet(object sender, int piIndex, string psMessage);

    //public class TLookUpItemCode
    //{
    //    private RepositoryItemLookUpEdit LookUpItemCode;
    //    public DataTable ItemCodeTable;
    //    public List<TItemCode> ItemCodeList = new List<TItemCode>();

    //    public void SetItemCode(RepositoryItemLookUpEdit aLookUpEdit)
    //    {
    //        TItemCode vItem;

    //        ItemCodeTable = TDataMySql.GetDataTable("SELECT * FROM tb_item_code ORDER BY ItemCode", "");

    //        //vItem = new TSheetCode();
    //        //vItem.ItemCode = "-";
    //        //vItem.ItemName = "선택안함";
    //        //_dataItemCode.Add(vItem);
    //        foreach (DataRow vRow in ItemCodeTable.Rows)
    //        {
    //            vItem = new TItemCode();
    //            vItem.ItemCode = vRow["ItemCode"].ToString();
    //            switch (vRow["CatgCode"].ToString())
    //            {
    //                case "1":
    //                    vItem.CatgCode = "발주";
    //                    break;
    //                case "2":
    //                    vItem.CatgCode = "측정";
    //                    break;
    //                case "3":
    //                    vItem.CatgCode = "검사";
    //                    break;
    //                case "9":
    //                    vItem.CatgCode = "기타";
    //                    break;
    //                default:
    //                    //Console.WriteLine($"Measured value is {measurement}.");
    //                    break;
    //            }
    //            //vItem.CatgCode = vRow["CatgCode"].ToString();
    //            vItem.ItemName = vRow["ItemName"].ToString();
    //            ItemCodeList.Add(vItem);
    //        }
    //        aLookUpEdit.DataSource = ItemCodeList.ToList();
    //        aLookUpEdit.DisplayMember = "ItemName";
    //        aLookUpEdit.ValueMember = "ItemCode";

    //        LookUpItemCode = aLookUpEdit;
    //    }

    //    //public string GetItemCode()
    //    //{
    //    //    return LookUpItemCode.EditValue.ToString();
    //    //}
    //}

    //public class TLookUpCustCode
    //{
    //    private LookUpEdit LookUpItemCode;
    //    private List<TCustCode> _dataCustCode = new List<TCustCode>();

    //    public void SetCustCode(LookUpEdit aLookUpEdit, bool abNone = false)
    //    {
    //        TCustCode vItem;

    //        DataTable datItemCode = TDataMySql.GetDataTable("SELECT * FROM tb_cust_code ORDER BY CustCode", "");

    //        if (abNone)
    //        {
    //            vItem = new TCustCode();
    //            vItem.CustCode = "-";
    //            vItem.CustName = "선택안함";
    //            //vItem.ProcClas = "-";
    //            _dataCustCode.Add(vItem);
    //        }
    //        foreach (DataRow vRow in datItemCode.Rows)
    //        {
    //            vItem = new TCustCode();
    //            vItem.CustCode = vRow["CustCode"].ToString();
    //            vItem.CustName = vRow["CustName"].ToString();
    //            //vItem.ProcClas = vRow["ProcClas"].ToString();
    //            _dataCustCode.Add(vItem);
    //        }
    //        aLookUpEdit.Properties.DataSource = _dataCustCode.ToList();
    //        aLookUpEdit.Properties.DisplayMember = "CustName";
    //        aLookUpEdit.Properties.ValueMember = "CustCode";

    //        LookUpItemCode = aLookUpEdit;
    //    }

    //    public string GetItemCode()
    //    {
    //        return LookUpItemCode.EditValue.ToString();
    //    }
    //}

    //public class TLookUpOrderSheet
    //{
    //    private LookUpEdit LookUpItemCode;
    //    private List<TSheetItem> _dataOrderSheet = new List<TSheetItem>();

    //    public void SetOrderSheet(LookUpEdit aLookUpEdit, bool abNone = false)
    //    {
    //        TSheetItem vItem;

    //        DataTable datItemCode = TDataMySql.GetDataTable("SELECT s.*, c.CustName FROM tb_order_sheet s" +
    //                                                        "  LEFT JOIN tb_cust_code c on s.CustCode = c.CustCode" +
    //                                                        " ORDER BY s.CustCode", "");

    //        if (abNone)
    //        {
    //            //vItem = new TOrderItem();
    //            //vItem.CustCode = "-";
    //            //vItem.CustName = "선택안함";
    //            //vItem.ProcClas = "-";
    //            //_dataOrderSheet.Add(vItem);
    //        }
    //        foreach (DataRow vRow in datItemCode.Rows)
    //        {
    //            vItem = new TSheetItem();
    //            vItem.CustCode = vRow["CustCode"].ToString();
    //            vItem.CustName = vRow["CustName"].ToString();
    //            vItem.ColNdx = Convert.ToInt32(vRow["ColNdx"]);
    //            vItem.RowNdx = Convert.ToInt32(vRow["RowNdx"]);
    //            _dataOrderSheet.Add(vItem);
    //        }
    //        aLookUpEdit.Properties.DataSource = _dataOrderSheet.ToList();
    //        aLookUpEdit.Properties.DisplayMember = "CustName";
    //        aLookUpEdit.Properties.ValueMember = "CustCode";

    //        LookUpItemCode = aLookUpEdit;
    //    }

    //    public string GetCustCode()
    //    {
    //        return LookUpItemCode.EditValue.ToString();
    //    }

    //    public int GetRowNdx()
    //    {
    //        return (LookUpItemCode.Properties.GetDataSourceRowByKeyValue(LookUpItemCode.EditValue) as TSheetItem).RowNdx;
    //    }
    //}

    //public class TLookUpItemNo
    //{
    //    private ComboBoxEdit ComboBoxItemCode;

    //    public void SetItemNo(ComboBoxEdit aComboBoxEdit, bool abNone = false)
    //    {
    //        DataTable datItemCode = TDataMySql.GetDataTable("SELECT * FROM tb_insp_data GROUP BY ItemNo ORDER BY ItemNo", "");

    //        aComboBoxEdit.Properties.Items.Clear();
    //        aComboBoxEdit.Properties.Items.Add("-");
    //        foreach (DataRow vRow in datItemCode.Rows)
    //        {
    //            aComboBoxEdit.Properties.Items.Add(vRow["ItemNo"].ToString());
    //        }
    //        ComboBoxItemCode = aComboBoxEdit;
    //    }

    //    public string GetItemNo()
    //    {
    //        return ComboBoxItemCode.EditValue.ToString();
    //    }
    //}

    //public class TLookUpPlant
    //{
    //    private ComboBoxEdit ComboBoxItemCode;

    //    public void SetPlant(ComboBoxEdit aComboBoxEdit, bool abNone = false)
    //    {
    //        DataTable datItemCode = TDataMySql.GetDataTable("SELECT * FROM tb_insp_data GROUP BY Plant ORDER BY Plant", "");

    //        aComboBoxEdit.Properties.Items.Clear();
    //        aComboBoxEdit.Properties.Items.Add("-");
    //        foreach (DataRow vRow in datItemCode.Rows)
    //        {
    //            aComboBoxEdit.Properties.Items.Add(vRow["Plant"].ToString());
    //        }
    //        ComboBoxItemCode = aComboBoxEdit;
    //    }

    //    public string GetItemNo()
    //    {
    //        return ComboBoxItemCode.EditValue.ToString();
    //    }
    //}

    public class TOptionData
    {
        private TIniFile _iniFile = new TIniFile();
        
        public string PresPort { get; set; }
        public string PresAddr1 { get; set; }
        public string PresAddr2 { get; set; }
        public string PresAddr3 { get; set; }
        public string PresAddr4 { get; set; }
        public string ButtonAddr { get; set; }
        public string GagePort { get; set; }

        public string MachCode { get; set; }
        public string OrderDate { get; set; }
        public int OrderSeqNo { get; set; }
        public string InspDate { get; set; }
        public int InspSeqNo { get; set; }

        public string MeasType { get; set; }
        public int StartTime { get; set; }
        public int PoppTime { get; set; }
        public double PoppValue { get; set; }
        public int ClosSTime { get; set; }
        public double ClosSValue { get; set; }
        public int ClosETime { get; set; }
        public double ClosEValue { get; set; }
        public int LeakTime { get; set; }
        public double LeakValue { get; set; }

        private static readonly TOptionData _AppEvent = new TOptionData();
        public static TOptionData Instance { get { return _AppEvent; } }
        private TOptionData()
        {
            ReadOptionDatas();
        }

        public void ReadOptionDatas()
        {
            PresPort = _iniFile.ReadString("Devc", "PresPort");
            PresAddr1 = _iniFile.ReadString("Devc", "PresAddr1");
            PresAddr2 = _iniFile.ReadString("Devc", "PresAddr2");
            PresAddr3 = _iniFile.ReadString("Devc", "PresAddr3");
            PresAddr4 = _iniFile.ReadString("Devc", "PresAddr4");
            ButtonAddr = _iniFile.ReadString("Devc", "ButtonAddr");
            GagePort = _iniFile.ReadString("Devc", "GagePort");

            MachCode = _iniFile.ReadString("Data", "MachCode");
            OrderDate = _iniFile.ReadString("Data", "OrderDate");
            OrderSeqNo = Convert.ToInt32(_iniFile.ReadString("Data", "OrderSeqNo"));
            InspDate = _iniFile.ReadString("Data", "InspDate");
            InspSeqNo = Convert.ToInt32(_iniFile.ReadString("Data", "InspSeqNo"));

            MeasType = _iniFile.ReadString("Meas", "Type");
            StartTime = Convert.ToInt32(_iniFile.ReadString("Meas", "StartTime"));
            PoppTime = Convert.ToInt32(_iniFile.ReadString("Meas", "PoppTime"));
            PoppValue = Convert.ToDouble(_iniFile.ReadString("Meas", "PoppValue"));
            ClosSTime = Convert.ToInt32(_iniFile.ReadString("Meas", "ClosSTime"));
            ClosSValue = Convert.ToInt32(_iniFile.ReadString("Meas", "ClosSValue"));
            ClosETime = Convert.ToInt32(_iniFile.ReadString("Meas", "ClosETime"));
            ClosEValue = Convert.ToInt32(_iniFile.ReadString("Meas", "ClosEValue"));
            LeakTime = Convert.ToInt32(_iniFile.ReadString("Meas", "LeakTime"));
            LeakValue = Convert.ToInt32(_iniFile.ReadString("Meas", "LeakValue"));
        }

        public void WirteOptionDatas()
        {
            _iniFile.WriteString("Devc", "PresPort", PresPort);
            _iniFile.WriteString("Devc", "PresAddr1", PresAddr1);
            _iniFile.WriteString("Devc", "PresAddr2", PresAddr2);
            _iniFile.WriteString("Devc", "PresAddr3", PresAddr3);
            _iniFile.WriteString("Devc", "PresAddr4", PresAddr4);
            _iniFile.WriteString("Devc", "ButtonAddr", ButtonAddr);
            _iniFile.WriteString("Devc", "GagePort", GagePort);

            _iniFile.WriteString("Data", "MachCode", MachCode);
            _iniFile.WriteString("Data", "OrderDate", OrderDate);
            _iniFile.WriteString("Data", "OrderSeqNo", OrderSeqNo.ToString());
            _iniFile.WriteString("Data", "InspDate", InspDate);
            _iniFile.WriteString("Data", "InspSeqNo", InspSeqNo.ToString());

            _iniFile.WriteString("Meas", "Type", MeasType);
            _iniFile.WriteString("Meas", "StartTime", StartTime.ToString());
            _iniFile.WriteString("Meas", "PoppTime", PoppTime.ToString());
            _iniFile.WriteString("Meas", "PoppValue", PoppValue.ToString());
            _iniFile.WriteString("Meas", "ClosSTime", ClosSTime.ToString());
            _iniFile.WriteString("Meas", "ClosSValue", ClosSValue.ToString());
            _iniFile.WriteString("Meas", "ClosETime", ClosETime.ToString());
            _iniFile.WriteString("Meas", "ClosEValue", ClosEValue.ToString());
            _iniFile.WriteString("Meas", "LeakTime", LeakTime.ToString());
            _iniFile.WriteString("Meas", "LeakValue", LeakValue.ToString());
        }
    }

    public class TUserEventArgs : EventArgs
    {
        public TUserEventArgs(int aiLParam, params string[] aWParams) { LParam = aiLParam; WParams = aWParams; }
        public int LParam { get; }
        public string[] WParams { get; }
    }

    public class TLogViewEventArgs : EventArgs
    {
        public TLogViewEventArgs(string asLogStr, Color aLogColor) { LogStr = asLogStr; LogColor = aLogColor; }
        public string LogStr { get; }
        public Color LogColor { get; }
    }

    public class TProcEventArgs : EventArgs
    {
        public TProcEventArgs(int aiProcNo, string asProcStr, Color aStrColor) { ProcNo = aiProcNo; ProcStr = asProcStr; StrColor = aStrColor; }
        public int ProcNo { get; }
        public string ProcStr { get; }
        public Color StrColor { get; }
    }

    public class TShowChildEventArgs : EventArgs
    {
        public TShowChildEventArgs(Form aChildForm) { ChildForm = aChildForm; }
        public Form ChildForm { get; }
    }

    //public class TProfileRecvEventArgs : EventArgs
    //{
    //    public TProfileRecvEventArgs(int aiLParam, params string[] aWParams) { LParam = aiLParam; WParams = aWParams; }
    //    public int LParam { get; }
    //    public string[] WParams { get; }
    //}

    public class TAppEvent
    {
        // Singleton Pattern
        private static readonly TAppEvent _AppEvent = new TAppEvent();
        public static TAppEvent Instance { get { return _AppEvent; } }
        private TAppEvent() { }

        // App Events 선언
        public event EventHandler<TUserEventArgs> OnUserMessage;
        public event EventHandler<TUserEventArgs> OnOptionsChange;
        public event EventHandler<TUserEventArgs> OnMeasOptionsChange;
        public event EventHandler<TLogViewEventArgs> OnLogAppend;
        public event EventHandler<TProcEventArgs> OnProcExec;
        public event EventHandler<TShowChildEventArgs> OnChildFormShow;
        //public event EventHandler<TProfileRecvEventArgs> OnProfileRecv;

        public void Delay(int ms)
        {
            DateTime dateTimeNow = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, ms);
            DateTime dateTimeAdd = dateTimeNow.Add(duration);
            while (dateTimeAdd >= dateTimeNow)
            {
                System.Windows.Forms.Application.DoEvents();
                dateTimeNow = DateTime.Now;
            }
            //System.Threading.Thread.Sleep(20);
            return;
        }

        // App Events 구현
        //public void ShowChildForm(object sender, int aiChildIndex)
        //{
        //    this.ChildFormShowEvent(sender, aiChildIndex);
        //}

        //public void SetStatusMessage(object sender, int messageIndex, string messageStr)
        //{
        //    this.StatusMessageSetEvent(sender, messageIndex, messageStr);
        //}

        //public void onInspDataRefresh(object sender, params string[] aMsgParams)
        //{
        //    if (InvokeRequired)
        //    {
        //        Invoke(new InspDataRefreshEvent(onInspDataRefresh), new Object[] { sender, asRefreshMessage });
        //        return;
        //    }
        //}

        public void SendUserMessage(object sender, string asWParams)
        {
            this.OnUserMessage(sender, new TUserEventArgs(0, asWParams));
        }

        public void SetOptionsChange(object sender, int aiLParam, string asConnParam)
        {
            this.OnOptionsChange(sender, new TUserEventArgs(aiLParam, asConnParam));
        }

        public void SetMeasOptionsChange(object sender, int aiLParam, string asConnParam)
        {
            this.OnMeasOptionsChange(sender, new TUserEventArgs(aiLParam, asConnParam));
        }

        public void SetLogAppend(object sender, string asLogStr, Color aLogColor)
        {
            //this.OnLogAppend(sender, new TLogViewEventArgs(asLogStr, aLogColor));
            OnLogAppend?.Invoke(this, new TLogViewEventArgs(asLogStr, aLogColor));
        }

        public void SetProcExec(object sender, int aiProcNo, string asLogStr, Color aLogColor)
        {
            //this.OnLogAppend(sender, new TLogViewEventArgs(asLogStr, aLogColor));
            OnProcExec?.Invoke(this, new TProcEventArgs(aiProcNo, asLogStr, aLogColor));
        }

        //public void ShowChildForm(object sender, DevExpress.XtraEditors.XtraForm aChildForm)
        //{
        //    this.OnChildFormShow(sender, new TShowChildEventArgs(aChildForm));
        //}

        //public void RecvProfileData(object sender, string asWParams)
        //{
        //    //this.OnProfileRecv(sender, new TProfileRecvEventArgs(0, asWParams));
        //    //this.OnChildFormShow(sender, new TShowChildEventArgs(aChildForm));
        //}
    } // class TAppEvent
}
