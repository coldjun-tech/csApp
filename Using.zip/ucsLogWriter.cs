﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Windows.Forms;

namespace cnAppUtils
{
    public class TLogWriter
    {
        private string _RootDirName;

        // ls ( Line Style )
        public enum LogLineStyles { Star = 0, One = 1, Two = 2 };

        public TLogWriter(string logName)
        {
            // Root 폴더를 생성
            _RootDirName = Application.StartupPath + @"\" + logName;
            //_RootDirName = Properties.Settings.Default.LOG_DIR;
            Directory.CreateDirectory(_RootDirName);
        }

        /* ---------------------------------------------------------------------------------------------- *
         * DESCRIPTION  : TStringList 를 그냥 Sort 하면 문자열로 취급해서 실수형에 맞는 Sort 가 되지 않는다.
         *                따라서 Float 에 따른 Sort 를 해주는 함수
         *                ABS 로 Sorting 되며 작은 수가 앞쪽 Index 이다.
         * AGUMENT      : - pLineStyle  = Sorting 할 List 의 시작 Index
         * RETURN_VALUE : None
         * ---------------------------------------------------------------------------------------------- *
         *   일  자   | 개발자 | 작  업  내  용
         * ---------------------------------------------------------------------------------------------- *
         * 2013.03.02 | 박준호 | 초기개발
         * ---------------------------------------------------------------------------------------------- */
        public void WriteLine(LogLineStyles lineStyle)
        {
            switch ((int)lineStyle)
            {
                case 0:
                    WriteStr("********************************************************************************", false);
                    break;
                case 1:
                    WriteStr("--------------------------------------------------------------------------------", false);
                    break;
                case 2:
                    WriteStr("================================================================================", false);
                    break;
                default:
                    return;
            }
        }

        public void WriteStr(string logStr, bool isTimeStamp = false)
        {
            string sDirName, sFileName;

            try
            {
                // 일자별 폴더를 생성 
                sDirName = _RootDirName + @"\" + DateTime.Now.ToString("yyyy-MM-dd");
                Directory.CreateDirectory(sDirName);

                // 시간별 파일명을 생성
                sFileName = sDirName + @"\" + DateTime.Now.ToString("HH").PadLeft(2, '0') + ".txt";

                if (!File.Exists(sFileName))
                {
                    using (System.IO.StreamWriter swLog = new System.IO.StreamWriter(sFileName, true))
                    {
                        if (isTimeStamp)
                        {
                            logStr = "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + logStr;
                        }
                        swLog.WriteLine(logStr);
                    }
                }
                else
                {
                    using (System.IO.StreamWriter swLog = new System.IO.StreamWriter(sFileName, true))
                    {
                        if (isTimeStamp)
                        {
                            logStr = "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + logStr;
                        }
                        swLog.WriteLine(logStr);
                    }
                }
            }
            catch
            {
                //
            }
        }

        // 이미 지난 로그를 삭제한다.
        // 보유기간, 보존기간 Retention period
        public void DeleteLog(int aliveCount)
        {
            string[] arrDeleteDirNames = Directory.GetDirectories(_RootDirName);

            //foreach (string sDirName in arrDeleteDirNames)
            //{
                //WriteStr(sDirName);
            //}

            for (int i = (arrDeleteDirNames.Length - aliveCount - 1); i >= 0; i--)
            {
                //WriteStr("Delete-" + arrDeleteDirNames[i], false);
                //System.IO.DirectoryInfo diDelete = new System.IO.DirectoryInfo(arrDeleteDirNames[i]);
                //try
                //{
                //    diDelete.Delete(true);
                //}
                //catch (System.IO.IOException e)
                //{
                //    WriteLine(LogLineStyles.Star);
                //    WriteStr(e.Message);
                //    WriteLine(LogLineStyles.Star);
                //}
            }
        }

    } // class CsLogWriter
}
