﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cnIniFiles
{
    public class TIniFile
    {
        // CharSet = CharSet.Auto
        [DllImport("kernel32", CharSet = CharSet.None)] private static extern long WritePrivateProfileString(string lpAppName, string lpKeyName, string lpString, string lpFileName);
        [DllImport("kernel32", CharSet = CharSet.None)] private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpRetString, int nSize, string lpFileName);
        [DllImport("kernel32", CharSet = CharSet.None)] private static extern int GetPrivateProfileInt(string lpAppName, string lpKeyName, int lpDefault, string lpFileName);
        [DllImport("kernel32", CharSet = CharSet.None)] private static extern int GetPrivateProfileSection(string lpAppName, byte[] lpRetString, int nSize, string lpFileName);

        List<string> list = new List<string>();
        public Dictionary<string, string> IdentValues = new Dictionary<string, string>();

        public string ReadString(string asSection, string asKeyName)
        {
            StringBuilder sbRet = new StringBuilder();
            GetPrivateProfileString(asSection, asKeyName, "(NONE)", sbRet, 32, @".\" + Application.ProductName + ".ini");

            return sbRet.ToString();
        }

        public int ReadInteger(string asSection, string asKeyName)
        {
            StringBuilder sbRet = new StringBuilder();
            GetPrivateProfileString(asSection, asKeyName, "(NONE)", sbRet, 32, @".\" + Application.ProductName + ".ini");

            return Convert.ToInt32(sbRet.ToString());
        }

        public void ReadSection(string psSection, string psFileName)
        {
            byte[] returnValue = new byte[32768 * 2];
            //int byteCount = GetPrivateProfileSection(psSection, returnValue, 32768 * 2, @"D:\01_프로젝트\nfc-scm\test.ini");
            int byteCount = GetPrivateProfileSection(psSection, returnValue, 32768 * 2, psFileName);

            IdentValues.Clear();
            int pos = 0;
            while (true)
            {
                if (pos >= byteCount) { break; }

                int count = 0;
                while (true)
                {
                    if (returnValue[pos + count] == 0)
                    {
                        break;
                    }
                    count++;
                }

                //string txt = Encoding.Default.GetString(returnValue, pos, count);
                string sValue = Encoding.UTF8.GetString(returnValue, pos, count);

                int equalPos = sValue.IndexOf('=');
                if (equalPos == -1)
                {
                    IdentValues.Add(sValue, "");
                }
                else
                {
                    IdentValues.Add(sValue.Substring(0, equalPos), sValue.Substring(equalPos + 1));
                }

                pos += count + 1;
            }
        }

        public void WriteString(string asSection, string asKeyName, string asValue)
        {
            //WritePrivateProfileString(asSection, asKeyName, asValue, $"{Application.ProductName}.ini");
            WritePrivateProfileString(asSection, asKeyName, asValue, @".\" + Application.ProductName + ".ini");
        }

        private string _readIniValue(string asSection, string asKeyName, string asDefaultValue, string asFilePath)
        {
            StringBuilder sb = new StringBuilder(255);
            GetPrivateProfileString(asSection, asKeyName, asDefaultValue, sb, (int)sb.Capacity, asFilePath);
            return sb.ToString();
        }

        public void ReadFromFile<T>(T aItem, string asSection = "SERVER_CONFIG", string asFilePath = @"C:\login.ini") where T : class
        {
            if (aItem == null)
                throw new ArgumentNullException(nameof(aItem));

            Type type = typeof(T);
            PropertyInfo[] properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (PropertyInfo prop in properties)
            {
                // 쓰기 가능한 프로퍼티만 대상
                if (!prop.CanWrite)
                    continue;

                // INI 파일에서 프로퍼티 이름과 동일한 Key 이름으로 읽기 (기본값 빈 문자열)
                string rawValue = _readIniValue(asSection, prop.Name, string.Empty, asFilePath);

                if (string.IsNullOrEmpty(rawValue))
                    continue;

                try
                {
                    // 문자열 값을 해당 프로퍼티의 실제 타입(int, DateTime, bool 등)으로 변환
                    Type targetType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                    TypeConverter converter = TypeDescriptor.GetConverter(targetType);

                    if (converter != null && converter.CanConvertFrom(typeof(string)))
                    {
                        object convertedValue = converter.ConvertFromString(rawValue);
                        prop.SetValue(aItem, convertedValue);
                    }
                }
                catch (Exception ex)
                {
                    // 형식 변환 실패 시 기본값 유지 또는 로깅
                    Console.WriteLine($"[Error] '{prop.Name}' 변환 실패: {ex.Message}");
                }
            }
        }
    } // public class TIniFile
}
