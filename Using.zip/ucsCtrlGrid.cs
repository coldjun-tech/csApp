﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lsa.Using
{
    public class TCtrlGrid
    {
        public TCtrlGrid()
        {
            //ReadOptionDatas();
        }

    } // public class TCtrlGrid
}
