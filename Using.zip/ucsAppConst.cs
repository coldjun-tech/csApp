﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lsa
{
    public enum LOGGER_LEVEL
    {
        Info,
        Error,
        Debug
    }

    public class LogStruct
    {
        public LOGGER_LEVEL logLevel { get; set; }
        public string Message { get; set; }
        public LogStruct(LOGGER_LEVEL logLevel, string message)
        {
            this.logLevel = logLevel;
            Message = message;
        }
    }

    public class TLogViewItem
    {
        public TLogViewItem(Color aTextColor, string asTextStr)
        {
            ItemColor = aTextColor;
            Message = asTextStr;
        }
        public Color ItemColor { get; set; }
        public string Message { get; set; }
    }

    //public static class TStogInfo
    //{
    //  public static string StogId;
    //  public static string ZoneCd;
    //  public static string CtrlId;
    //  public static int StogPort;
    //  public static int StogUnit;
    //}

    //public class TServerItem
    //{
    //  public string ServerAddr { get; set; }
    //  public int ServerPort { get; set; }
    //  public int StogCount { get; set; }
    //  public int PickCount { get; set; }
    //  public DateTime StogDate { get; set; }
    //  public TTcpAsyncServer ServSock;
    //}
}