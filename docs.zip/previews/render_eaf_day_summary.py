"""Offline screenshot input using the day summary ASP's original markup and assets."""
from pathlib import Path
import re
import html
import base64

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'Web/Res/ResDay/ResE_day_1_jong.asp'
OUT = Path(__file__).resolve().parent
source = SOURCE.read_text(encoding='cp949')
names = ['생석회', '돌로마이트', '가탄재', 'Fe-Mn', 'Fe-Si', 'Al', '형석', '코크스', 'Si-Mn', '기타', '기타', '기타', '기타']
arrays = {
    'rs_anae': [18, 25, 8, 20, 4], 'rs_engtempe': [1620],
    'rs_anal': [16, 22, 10, 18, 5, 3, 1605],
    'rs_ayne': names, 'rs_name': names[:10],
    'rs_alye': [12000, 3600, 1800, 400, 300, 50, 0, 700, 100, 0, 0, 0, 0],
    'rs_alyl': [3000, 1200, 100, 400, 300, 50, 0, 0, 100, 0],
    'rs_enge': [1260000, 442.11, 51000, 17.89, 6000, 2.11, 21000, 7.37, 3000, 1.05, 1800],
    'rs_time': [5, 3, 20, 3, 16, 8, 4],
    'rs_timve': [61, 42, 2], 'rs_timxe': [68, 47, 4], 'rs_timne': [55, 38, 1],
    'rs_engl': [25500, 1200, 1100, 600],
    'rs_timvl': [35, 22, 13], 'rs_timxl': [42, 27, 15], 'rs_timnl': [29, 18, 11],
}
values = {
    'sch_date': '2026년11월20일', 'scri_cnt': 30, 'isctotal_011': 3000,
    'formatnumber(ton_che/10,1)': '95.0', 'formatnumber(ton_che,1)': '950.0',
    'formatnumber(per*100,2)': '95.00', 'ipassvol': 2800,
    'formatnumber(ipasstonch,2)': '93.33', 'formatnumber(iper*100,2)': '98.25',
    'scri_cntlf': 30, 'formatnumber(bton_ch/10,1)': '95.0',
    'formatnumber(bton_ch,1)': '950.0', 'formatnumber(aton_ch/10,1)': '94.5',
    'formatnumber(aton_ch,1)': '945.0', 'int(ieaftemp_ch)': '1585',
    'int(ilftemp_ch)': '1605', 'oxy_tote': 72000, 'lng_tote': 9000,
    'formatnumber(unt_carbone,2)': '0.63',
}
def sample(expr):
    key = re.sub(r'\s+', '', expr).lower()
    if key in values: return str(values[key])
    fmt = re.fullmatch(r'formatnumber\((.*),(\d+)\)', key)
    if fmt:
        v = sample(fmt.group(1))
        try: return f'{float(v):.{int(fmt.group(2))}f}'
        except ValueError: return v
    m = re.fullmatch(r'(rs_\w+)\((\d+)\)', key)
    if m:
        name, index = m.group(1), int(m.group(2))
        arr = arrays.get(name)
        if arr is not None and index < len(arr): return str(arr[index])
        if name.startswith('rs_engtemp'): return '1620'
        if name.startswith('rs_tim'): return str([35, 22, 13, 2][index % 4])
        if name.startswith('rs_eng'): return str([42000, 28, 12, 4][index % 4])
    if '-' in key and key.startswith('rs_tim'): return '59'
    if key == 'rs_engl(0)*10': return '255000'
    if key.startswith('rs_equipe'): return '120'
    if key.startswith('scri_cnt'): return '10'
    if key.startswith('ipassvol'): return '933'
    if key.startswith('formatnumber'): return '0.00'
    if key.startswith('flt_melt'): return '0.50'
    if key.startswith('flt_engy'): return '0.42'
    if key.startswith(('ipwrno', 'ieq')) and 'no' in key: return '1025'
    if key.startswith(('ipowrup', 'ieq')): return '18'
    return '0'

source = re.sub(r'<%=(.*?)%>', lambda m: html.escape(sample(m.group(1))), source, flags=re.S)
source = re.sub(r'<%.*?%>', '', source, flags=re.S)
source = re.sub(r'<!--.*?-->', '', source, flags=re.S)
source = source.replace('charset=euc-kr', 'charset=utf-8')
def asset(match):
    attr, quote, target = match.groups()
    path = (SOURCE.parent / target).resolve()
    if not path.is_file(): return match.group(0)
    mime = {'.jpg': 'image/jpeg', '.gif': 'image/gif', '.png': 'image/png'}.get(path.suffix.lower())
    if not mime: return match.group(0)
    return f'{attr}={quote}data:{mime};base64,{base64.b64encode(path.read_bytes()).decode()}{quote}'
source = re.sub(r'(src|background)=([\"\'])([^\"\']+)\2', asset, source, flags=re.I)
source = source.replace('</head>', '<style>.sample-note{position:fixed;bottom:0;left:0;right:0;padding:8px;background:#fff4cf;border-top:1px solid #b8a165;color:#53451e;font:12px Malgun Gothic,sans-serif;text-align:center;z-index:10}</style></head>')
source = source.replace('</body>', '<div class="sample-note">화면 구성 예시 — 원본 ASP 레이아웃 · DB 미연결 · 날짜와 수치는 예시입니다.</div></body>')
assert '<%' not in source
path = OUT / 'ResE_day_1_jong_sample.html'
path.write_text(source, encoding='utf-8')
print(path)
