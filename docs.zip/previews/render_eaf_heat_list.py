"""Build offline views from ResE_heat.asp's original HTML and image assets."""
from pathlib import Path
import re
import html
import base64

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'Web/Res/ResHeat/ResE_heat.asp'
OUT = Path(__file__).resolve().parent
raw = SOURCE.read_text(encoding='cp949')
raw = raw[raw.index('<html>'):raw.index('</html>') + len('</html>')]
raw = raw.replace('<!-- #include file="../../inc/copyright.inc" -->',
                  (ROOT / 'Web/inc/copyright.inc').read_text(encoding='cp949'))
row_match = re.search(r'<tr>\s*<td\b[^>]*><b><%=sRptDate%>.*?</tr>', raw, re.S | re.I)
assert row_match, 'Original result row not found'
row_template = row_match.group(0)
raw = raw[:row_match.start()] + '__RESULT_ROWS__' + raw[row_match.end():]
summary_start = raw.index('<% if typp=1 then%>')
summary_end = raw.index('<% end if%>', summary_start) + len('<% end if%>')
summary = raw[summary_start:summary_end]
raw = raw[:summary_start] + '__SUMMARY__' + raw[summary_end:]

def replace_values(text, values):
    return re.sub(r'<%=(.*?)%>', lambda m: html.escape(str(values.get(m.group(1).strip().lower(), ''))), text, flags=re.S)

def asset(match):
    attr, quote, target = match.groups()
    path = (SOURCE.parent / target).resolve()
    if not path.is_file(): return match.group(0)
    mime = {'.jpg': 'image/jpeg', '.gif': 'image/gif', '.png': 'image/png'}.get(path.suffix.lower())
    if not mime: return match.group(0)
    return f'{attr}={quote}data:{mime};base64,{base64.b64encode(path.read_bytes()).decode()}{quote}'

for mode in ('initial', 'sample'):
    if mode == 'sample':
        rows = []
        for i in range(8):
            hour = 8 + i
            heat = f'A{75021 + i}'
            values = {'srptdate': '11/18', 'sheatnum_001': heat,
                      'ssteelxx_005': ('SD400', 'SD500')[i % 2],
                      'hhmmsss': f'{hour:02}:50:00', 'hhmmsse': f'{hour:02}:54:00',
                      'itimjott_077': 54 + i % 4, 'itektotx_035': 48600 + i * 120,
                      'itekpwat_036': 42500 + i * 110, 'scomment_084': '',
                      'trim(sheatnum_001)': heat}
            rows.append(replace_values(row_template, values))
        contents = raw.replace('__RESULT_ROWS__', '\n'.join(rows)).replace('__SUMMARY__', summary)
        contents = replace_values(contents, {'stdtime': '11월 18일 07시 00분 ~ 11월 19일 07시 00분',
                                             'dsptime': '07 시 00 분', 'heatcount': 8})
        caption = '조회 결과 구성 예시 · 로그인된 사용자 화면 · DB 미연결 / 목록 수치는 예시입니다.'
    else:
        empty = '<tr><td colspan="10" align="center" bgcolor="#CCCCCC">데이터가 하나도 없습니다.</td></tr><tr><td colspan="10" align="center" bgcolor="#CCCCCC"><font color="#0000FF">검색날짜나 HEAT NO를 입력해주세요.</font></td></tr>'
        contents = raw.replace('__RESULT_ROWS__', empty).replace('__SUMMARY__', '')
        caption = '조회 결과가 없는 화면 구성 예시 · 로그인된 사용자 화면 · DB 미연결'
    contents = re.sub(r'<%.*?%>', '', contents, flags=re.S)
    contents = re.sub(r'<!--.*?-->', '', contents, flags=re.S)
    contents = re.sub(r'<script\b.*?</script>', '', contents, flags=re.S | re.I)
    contents = contents.replace('charset=euc-kr', 'charset=utf-8')
    contents = re.sub(r'(src|background)=([\"\'])([^\"\']+)\2', asset, contents, flags=re.I)
    contents = contents.replace('</head>', '<style>.sample-note{position:fixed;bottom:0;left:0;right:0;padding:8px;background:#fff4cf;border-top:1px solid #b8a165;color:#53451e;font:12px Malgun Gothic,sans-serif;text-align:center;z-index:10}</style></head>')
    contents = contents.replace('</body>', f'<div class="sample-note">{caption}</div></body>')
    assert '<%' not in contents
    path = OUT / f'ResE_heat_{mode}.html'
    path.write_text(contents, encoding='utf-8')
    print(path)
