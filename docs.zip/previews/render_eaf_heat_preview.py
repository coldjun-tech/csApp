"""Render the original ASP markup with explicitly illustrative data, without DB/Excel execution."""
from pathlib import Path
import base64
import html
import re

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'Web/Res/ResHeat/ResE_heat_pre.asp'
OUT = Path(__file__).resolve().parent
source = SOURCE.read_text(encoding='cp949')
# Keep the populated scrap branch, excluding the alternative empty table.
source = re.sub(r'(<%(?:(?!%>).)*if\s*\(Rs_scrap.BOF and Rs_scrap.EOF\)\s*then\s*%>).*?<%\s*Else\s*%>', '', source, flags=re.S | re.I)
source = re.sub(r'<!--.*?-->', '', source, flags=re.S)
values = {
    'sheat': 'A75021', 'sheatnum_001': 'A75021', 'yyyy': '2026', 'mmmm': '11',
    'dddd': '18', 'sclassno_058': '1', 'ronum': 'A', 'ssteelgp_005': 'SD400',
    'sefpattn_006': '12', 'sscrapno_007': '03', 'sheatnop_071': '75021',
    'itimjost_005': '5', 'itimin1x_006': '3', 'itimjom1_007': '20',
    'itimin2x_008': '3', 'itimjom2_009': '16', 'itimjorx_010': '8',
    'itimjout_011': '4', 'itimjsti_013': '2', 'itimjopw_012': '42',
    'itimjott_014': '61', 'istttotal': '2', 'istcod01_018': '101',
    'sstequp1_019': '전기', 'scontnt1_020': '점검', 'hhmm_occur1': '09:20',
    'isttmsd1_059': '2', 'irosacnt_003': '128', 'iladleno_039': '12',
    'ipolecnt_002': '245', 'iladlcnt_040': '36', 'iebtcntx_004': '82',
    'ipwrno01_062': '1025', 'ipowrup1_066': '18', 'ipwweih1_072': '2150',
    'irepairx_008': '120', 'inp_tot1': '65000', 'inp_tot2': '35000',
    'inp_total': '100000', 'formatnumber(imeltamt_006/10,1)': '95.0',
    'hhmmssE': '09:58:00', 'sfndheat': 'A75020', 'itmp1get_039': '1585',
    'itmp2get_042': '1602', 'itmp3get_045': '1610',
}
material_names = ['생석회', '돌로마이트', '가탄재', 'Fe-Mn', 'Fe-Si', 'Al', '형석', '코크스', 'Si-Mn', '기타']
def sample(expr):
    key = re.sub(r'\s+', '', expr).lower()
    if key in values:
        return values[key]
    if key.startswith('rs_scrap('):
        match = re.search(r'(icode|sname|iput_)(\d{3})', key)
        if match:
            kind, number = match.groups()
            slot = int(number) % 100
            charge = int(number) // 100
            if slot > 3:
                return ''
            if kind == 'icode': return str(100 + slot)
            if kind == 'sname': return ['중량고철', '경량고철', '선철'][slot - 1]
            return str(([30000, 25000, 10000] if charge == 1 else [15000, 12000, 8000])[slot - 1])
    if key.startswith('rs_aloy('):
        match = re.search(r'\((\d+)\)', key)
        return material_names[min((int(match.group(1)) - 8) // 6, 9)] if match else '-'
    if key.startswith('hhmm_'): return '09:35'
    if 'caltmp' in key: return '1600'
    if key.startswith('rs_anal') or key.startswith('int((rs_anal'): return '0'
    if key.startswith('formatnumber'): return '0.0'
    if key in ('m1', 'm2', 'r', 'total'): return '0'
    return '0' if key.startswith(('i', 'rs_aloy', 'fm', 'fpw', 'ftotal')) else '-'

source = re.sub(r'<%=(.*?)%>', lambda m: html.escape(sample(m.group(1))), source, flags=re.S)
source = re.sub(r'<%.*?%>', '', source, flags=re.S)
source = re.sub(r'<script\b.*?</script>', '', source, flags=re.S | re.I)
source = source.replace('charset=euc-kr', 'charset=utf-8')
def asset(match):
    attr, quote, target = match.groups()
    path = (SOURCE.parent / target).resolve()
    if not path.is_file(): return match.group(0)
    mime = {'.jpg': 'image/jpeg', '.gif': 'image/gif', '.png': 'image/png'}.get(path.suffix.lower())
    if not mime: return match.group(0)
    return attr + '=' + quote + 'data:' + mime + ';base64,' + base64.b64encode(path.read_bytes()).decode() + quote
source = re.sub(r'(src|background)=([\"\'])([^\"\']+)\2', asset, source, flags=re.I)
source = source.replace('</head>', '<style>body{margin:5px;} .sample-note{position:fixed;bottom:0;left:0;right:0;padding:8px;background:#fff4cf;border-top:1px solid #b8a165;color:#53451e;font:12px Malgun Gothic,sans-serif;text-align:center;z-index:10}</style></head>')
source = source.replace('</body>', '<div class="sample-note">화면 구성 예시 — 원본 ASP 레이아웃 · DB 미연결 · 표시 데이터는 예시입니다.</div></body>')
assert '<%' not in source
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'ResE_heat_pre_sample.html').write_text(source, encoding='utf-8')
print(OUT / 'ResE_heat_pre_sample.html')
